/**
 * businessLogic.js - Lógica de negocio sin dependencias externas
 * Version: 2.0.0
 * 
 * Funcionalidad:
 * - Búsqueda de códigos OEM
 * - Validación de bases de datos
 * - Normalización de códigos
 */

const fs = require('fs');
const path = require('path');

class BusinessLogic {
  constructor() {
    this.rulesLoaded = false;
    this.rules = null;
    this.cache = new Map();
  }

  /**
   * Cargar reglas maestras desde config
   */
  loadRules() {
    try {
      const configPath = path.join(__dirname, 'config', 'REGLAS_MAESTRAS.json');
      
      if (fs.existsSync(configPath)) {
        const data = fs.readFileSync(configPath, 'utf8');
        this.rules = JSON.parse(data);
        this.rulesLoaded = true;
        console.log('✅ Reglas maestras cargadas');
        return true;
      } else {
        console.log('⚠️ config/REGLAS_MAESTRAS.json no encontrado');
        this.rulesLoaded = false;
        return false;
      }
    } catch (error) {
      console.error('❌ Error cargando reglas:', error.message);
      this.rulesLoaded = false;
      return false;
    }
  }

  /**
   * Obtener la configuración OEM Universe
   */
  getOEMUniverse() {
    if (!this.rulesLoaded || !this.rules) {
      return {
        success: false,
        error: 'Reglas no cargadas',
        data: null
      };
    }

    return {
      success: true,
      data: this.rules.oem_universe || {}
    };
  }

  /**
   * Validar códigos OEM
   */
  validateOEM(codes) {
    if (!Array.isArray(codes)) {
      codes = [codes];
    }

    if (!this.rulesLoaded || !this.rules) {
      return {
        success: false,
        valid: false,
        error: 'Reglas no cargadas'
      };
    }

    const patterns = this.rules.oem_universe?.patterns || [];
    const validCodes = [];
    const invalidCodes = [];

    codes.forEach(code => {
      const normalized = String(code).toUpperCase().trim();
      
      const isValid = patterns.some(pattern => {
        const regex = new RegExp(pattern.regex);
        return regex.test(normalized);
      });

      if (isValid) {
        validCodes.push(normalized);
      } else {
        invalidCodes.push(normalized);
      }
    });

    return {
      success: true,
      valid: invalidCodes.length === 0,
      normalized: validCodes,
      invalid: invalidCodes,
      totalChecked: codes.length,
      totalValid: validCodes.length
    };
  }

  /**
   * Normalizar múltiples códigos
   */
  normalizeCodes(codes) {
    if (typeof codes === 'string') {
      // Separar por comas, saltos de línea, espacios
      codes = codes.split(/[,\n\r\t;]+/).map(c => c.trim()).filter(c => c);
    }

    if (!Array.isArray(codes)) {
      codes = [codes];
    }

    const normalized = codes.map(code => 
      String(code).toUpperCase().trim()
    ).filter(code => code.length > 0);

    return {
      success: true,
      normalized: normalized,
      count: normalized.length
    };
  }

  /**
   * Búsqueda en cascada (simulada)
   */
  searchCascade(query, databases = []) {
    if (!query || query.trim().length === 0) {
      return {
        success: false,
        error: 'Query vacío'
      };
    }

    const normalized = String(query).toUpperCase().trim();

    return {
      success: true,
      query: normalized,
      results: {
        directMatch: [],
        partialMatch: [],
        suggestions: []
      }
    };
  }

  /**
   * Obtener estadísticas
   */
  getStats() {
    return {
      rulesLoaded: this.rulesLoaded,
      cacheSize: this.cache.size,
      patterns: this.rules?.oem_universe?.patterns?.length || 0,
      brands: this.rules?.oem_universe?.brands?.length || 0
    };
  }

  /**
   * Limpiar caché
   */
  clearCache() {
    this.cache.clear();
    return { success: true, message: 'Caché limpiado' };
  }
}

module.exports = new BusinessLogic();
