/**
 * server.js - Servidor Express limpio
 * Version: 2.0.0
 * 
 * Sin dependencias faltantes
 * Funciona de inmediato
 */

const express = require('express');
const businessLogic = require('./businessLogic');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// ============================================================================
// CARGAR REGLAS AL INICIAR
// ============================================================================

businessLogic.loadRules();

// ============================================================================
// ENDPOINTS BÁSICOS
// ============================================================================

/**
 * GET /health
 * Health check del servidor
 */
app.get('/health', (req, res) => {
  const stats = businessLogic.getStats();
  
  res.json({
    status: 'ok',
    version: '2.0.0',
    rulesLoaded: stats.rulesLoaded,
    patterns: stats.patterns,
    brands: stats.brands,
    timestamp: new Date().toISOString()
  });
});

/**
 * GET /status
 * Estado detallado
 */
app.get('/status', (req, res) => {
  const stats = businessLogic.getStats();
  
  res.json({
    service: 'elimfilters-proxy-api',
    version: '2.0.0',
    status: 'running',
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    rules: stats,
    timestamp: new Date().toISOString()
  });
});

// ============================================================================
// ENDPOINTS OEM UNIVERSE
// ============================================================================

/**
 * GET /api/v1/oem-universe
 * Obtener configuración OEM Universe
 */
app.get('/api/v1/oem-universe', (req, res) => {
  const result = businessLogic.getOEMUniverse();
  
  if (result.success) {
    res.json({
      success: true,
      data: result.data
    });
  } else {
    res.status(500).json({
      success: false,
      error: result.error
    });
  }
});

/**
 * POST /api/v1/validate-oem
 * Validar códigos OEM
 */
app.post('/api/v1/validate-oem', (req, res) => {
  const { codes } = req.body;

  if (!codes) {
    return res.status(400).json({
      success: false,
      error: 'Campo "codes" requerido'
    });
  }

  const result = businessLogic.validateOEM(codes);
  
  res.json(result);
});

/**
 * POST /api/v1/normalize-codes
 * Normalizar múltiples códigos
 */
app.post('/api/v1/normalize-codes', (req, res) => {
  const { codes } = req.body;

  if (!codes) {
    return res.status(400).json({
      success: false,
      error: 'Campo "codes" requerido'
    });
  }

  const result = businessLogic.normalizeCodes(codes);
  
  res.json(result);
});

/**
 * POST /api/v1/search
 * Búsqueda en cascada
 */
app.post('/api/v1/search', (req, res) => {
  const { query, databases } = req.body;

  if (!query) {
    return res.status(400).json({
      success: false,
      error: 'Campo "query" requerido'
    });
  }

  const result = businessLogic.searchCascade(query, databases);
  
  res.json(result);
});

// ============================================================================
// ENDPOINTS UTILIDAD
// ============================================================================

/**
 * GET /api/v1/stats
 * Estadísticas
 */
app.get('/api/v1/stats', (req, res) => {
  res.json({
    success: true,
    data: businessLogic.getStats()
  });
});

/**
 * POST /api/v1/cache-clear
 * Limpiar caché
 */
app.post('/api/v1/cache-clear', (req, res) => {
  const result = businessLogic.clearCache();
  res.json(result);
});

// ============================================================================
// ERROR HANDLING
// ============================================================================

/**
 * 404 - Not Found
 */
app.use((req, res) => {
  res.status(404).json({
    success: false,
    error: 'Endpoint no encontrado',
    path: req.path,
    method: req.method
  });
});

/**
 * Error handler global
 */
app.use((err, req, res, next) => {
  console.error('Error:', err);
  
  res.status(500).json({
    success: false,
    error: err.message || 'Error interno del servidor',
    timestamp: new Date().toISOString()
  });
});

// ============================================================================
// INICIAR SERVIDOR
// ============================================================================

const server = app.listen(PORT, () => {
  console.log(`\n✅ Servidor iniciado`);
  console.log(`   Puerto: ${PORT}`);
  console.log(`   URL: http://localhost:${PORT}`);
  console.log(`   Health: http://localhost:${PORT}/health\n`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('\n⏹️  Cerrando servidor...');
  server.close(() => {
    console.log('✅ Servidor cerrado');
    process.exit(0);
  });
});

module.exports = app;
