# ✅ ELIMFILTERS PROXY API v2.0.0

## Contenido

- `businessLogic.js` - Lógica de negocio
- `server.js` - Servidor Express
- `config/REGLAS_MAESTRAS.json` - Configuración OEM

## Instalación

1. Extrae este ZIP en tu repo
2. Copia los archivos:
   ```bash
   mkdir -p config
   cp businessLogic.js .
   cp server.js .
   cp config/REGLAS_MAESTRAS.json config/
   ```

3. Git:
   ```bash
   git add businessLogic.js server.js config/
   git commit -m "fix: Clean working version v2.0.0"
   git push
   ```

4. Espera 2-3 min en Railway

## Endpoints

- `GET /health` - Health check
- `GET /status` - Estado detallado
- `GET /api/v1/oem-universe` - Obtener configuración
- `POST /api/v1/validate-oem` - Validar códigos
- `POST /api/v1/normalize-codes` - Normalizar códigos
- `GET /api/v1/stats` - Estadísticas

## Test

```bash
curl https://tu-railway-url/health
```

Debe retornar: `"status": "ok"`
