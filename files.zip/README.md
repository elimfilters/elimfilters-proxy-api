# 🚀 ELIMFILTERS SKU Generator API v2.0

[![GitHub](https://img.shields.io/badge/GitHub-elimfilters%2Felimfilters--proxy--api-blue?logo=github)](https://github.com/elimfilters/elimfilters-proxy-api)
[![Railway](https://img.shields.io/badge/Deployment-Railway-0B0D0E?logo=railway)](https://railway.app)
[![Node.js](https://img.shields.io/badge/Node.js-18+-green?logo=node.js)](https://nodejs.org)
[![License](https://img.shields.io/badge/License-MIT-yellow)](LICENSE)

## 📋 Descripción

API empresarial para la generación automática de SKUs de filtros ELIMFILTERS, integrada con n8n y Google Sheets. Implementa las **REGLA #1**, **REGLA #2** y **REGLA #3** para clasificación de duty, tipos de filtro y generación de códigos prioritarios.

### ✨ Características

- ✅ **REGLA #1**: Identificación automática de Duty (HD/LD) basada en OEM
- ✅ **REGLA #2**: Mapeo automático de Tipos de Filtro a Prefijos ELIMINFILTERS
- ✅ **REGLA #3**: Búsqueda de código prioritario (Donaldson/FRAM) + generación de SKU
- ✅ Validación rigurosa de motores (solo filtros de motor)
- ✅ Integración con n8n para búsqueda de información
- ✅ Conexión con Google Sheets Master Data
- ✅ API REST con autenticación
- ✅ Despliegue automático en Railway
- ✅ Caché y optimización de rendimiento
- ✅ Rate limiting y CORS configurables

---

## 🏗️ Arquitectura

```
┌─────────────────────────────────────────────────────────────┐
│                    Client Application                        │
└────────────┬────────────────────────────────┬────────────────┘
             │                                │
     ┌───────▼────────┐              ┌───────▼────────┐
     │  REST API      │              │   Webhook      │
     │  POST /sku     │              │  (n8n)         │
     └────────┬───────┘              └────────┬───────┘
              │                               │
     ┌────────▼───────────────────────────────▼────────┐
     │     ELIMFILTERS SKU Generator API (Railway)     │
     ├──────────────────────────────────────────────────┤
     │                                                  │
     │  ┌─────────────────────────────────────────┐   │
     │  │  Request Validation & Normalization     │   │
     │  └──────────────────┬──────────────────────┘   │
     │                     │                          │
     │  ┌──────────────────▼──────────────────────┐   │
     │  │  REGLA #1: Resolver Duty (HD/LD)       │   │
     │  │  • OEM Classification                  │   │
     │  │  • Motor Type Detection                │   │
     │  └──────────────────┬──────────────────────┘   │
     │                     │                          │
     │  ┌──────────────────▼──────────────────────┐   │
     │  │  REGLA #2: Filter Type Mapping         │   │
     │  │  • Type → Prefix (EA1, EL8, EF9, etc.) │   │
     │  │  • Validation Type+Duty                │   │
     │  └──────────────────┬──────────────────────┘   │
     │                     │                          │
     │  ┌──────────────────▼──────────────────────┐   │
     │  │  REGLA #3: Priority Code Search        │   │
     │  │  • Donaldson (HD) / FRAM (LD)          │   │
     │  │  • Extract Last 4 Digits               │   │
     │  │  • Generate SKU: [PREFIX] + [4 DIGITS] │   │
     │  └──────────────────┬──────────────────────┘   │
     │                     │                          │
     │  ┌──────────────────▼──────────────────────┐   │
     │  │  Response Formatting & Caching         │   │
     │  └──────────────────┬──────────────────────┘   │
     └─────────────────────┼──────────────────────────┘
                           │
         ┌─────────────────┼──────────────────┐
         │                 │                  │
    ┌────▼────┐    ┌──────▼──────┐   ┌──────▼──────┐
    │ n8n API │    │Google Sheets│   │ Redis Cache │
    │(n8n)    │    │  (Master)   │   │ (Optional)  │
    └─────────┘    └─────────────┘   └─────────────┘
```

---

## 🚀 Quick Start

### Requisitos

- Node.js >= 18.0.0
- npm >= 9.0.0
- Docker (para despliegue local)
- Railway CLI (para despliegue en Railway)

### Instalación Local

```bash
# 1. Clonar repositorio
git clone https://github.com/elimfilters/elimfilters-proxy-api.git
cd elimfilters-proxy-api

# 2. Instalar dependencias
npm install

# 3. Configurar variables de entorno
cp .env.example .env
# Editar .env con tus credenciales

# 4. Ejecutar en desarrollo
npm run dev

# 5. Ejecutar tests
npm test
```

### Despliegue en Railway

```bash
# 1. Instalar Railway CLI
npm i -g @railway/cli

# 2. Login en Railway
railway login

# 3. Crear proyecto
railway init

# 4. Conectar GitHub
railway connect

# 5. Desplegar
railway up
```

---

## 📚 Documentación de Reglas

### REGLA #1: Clasificación de DUTY

**Objetivo**: Identificar si un filtro es **HD (Heavy Duty)** o **LD (Light Duty)**

#### Criterios:
- **HD (Heavy Duty)**: Motores Diesel + OEMs comerciales/industriales
  - Caterpillar, Komatsu, John Deere, Kubota, Mack, Peterbilt, Volvo, Isuzu, Cummins, etc.
- **LD (Light Duty)**: Motores Gasolina + OEMs vehículos livianos
  - Toyota, Nissan, Honda, BMW, Audi, Lexus, Volkswagen, Chevrolet, Ford, etc.

#### Implementación:
Ver `src/utils/dutyResolver.js`

```javascript
const { resolveDuty } = require('./utils/dutyResolver');

const duty = resolveDuty({
  motorManufacturer: 'Caterpillar',
  equipmentType: 'Excavator',
  motorType: 'Diesel'
}); // Retorna: 'HD'
```

---

### REGLA #2: Mapeo de Tipos a Prefijos

**Objetivo**: Asignar un prefijo ELIMINFILTERS único según el tipo de filtro

#### Tipos Soportados:

| Tipo | Prefijo | Duty | Descripción |
|------|---------|------|-------------|
| OIL | EL8 | HD-LD | Filtro de Aceite |
| FUEL | EF9 | HD-LD | Filtro de Combustible |
| AIR | EA1 | HD-LD | Filtro de Aire |
| CABIN_FILTER | EC1 | HD-LD | Filtro de Cabina |
| SEPARATOR_FUEL | ES9 | HD | Separador de Combustible |
| HYDRAULIC | EH6 | HD | Filtro Hidráulico |
| COOLANT | EW7 | HD | Filtro de Refrigerante |
| AIR_DRYER | ED4 | HD | Secador de Aire |
| TURBINE_SERIES | ET9 | HD | Turbina/Portafiltro |
| KIT_DIESEL | EK5 | HD | Kit Diesel |
| KIT_GASOLINA | EK3 | LD | Kit Gasolina |
| HOUSING | EB1 | HD | Carcasa para Filtros |

#### Implementación:
Ver `src/utils/typeMapper.js`

```javascript
const { getPrefix } = require('./utils/typeMapper');

const prefix = getPrefix('HYDRAULIC'); // Retorna: 'EH6'
```

---

### REGLA #3: Generación de SKU

**Objetivo**: Generar SKU con formato [PREFIJO] + [4 DÍGITOS]

#### Proceso:
1. **Búsqueda de Código Prioritario**
   - HD: Buscar código Donaldson (prefijo P)
   - LD: Buscar código FRAM (prefijos PH, CA, CH)
   - Fallback: Usar OEM más comercial

2. **Extracción de Dígitos**
   - Extraer últimos 4 dígitos del código encontrado
   - Validar que no sean todos ceros

3. **Construcción de SKU**
   - Formato: [PREFIJO (3 caracteres)] + [4 DÍGITOS]
   - Ejemplo: EH64378 (Hidráulico + 4378)
   - Validación: Exactamente 7 caracteres alpanuméricos

#### Implementación:
Ver `src/utils/skuGenerator.js`

```javascript
const { generateSKU } = require('./utils/skuGenerator');

const result = generateSKU({
  code: 'P164378',
  filterType: 'HYDRAULIC',
  duty: 'HD'
});
// Retorna:
// {
//   SKU: 'EH64378',
//   prefix: 'EH6',
//   digits: '4378',
//   duty: 'HD',
//   filterType: 'HYDRAULIC',
//   validated: true
// }
```

---

## 🔌 Endpoints API

### POST /api/sku/generate

Genera un SKU nuevo

```bash
curl -X POST http://localhost:3000/api/sku/generate \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "code": "P164378",
    "filterType": "HYDRAULIC",
    "motorManufacturer": "Caterpillar",
    "motorType": "Diesel",
    "oemCodes": ["P164378", "85000381"]
  }'
```

### GET /api/sku/validate/:sku

Valida un SKU existente

```bash
curl http://localhost:3000/api/sku/validate/EH64378 \
  -H "Authorization: Bearer YOUR_API_KEY"
```

### GET /api/health

Health check del servicio

```bash
curl http://localhost:3000/api/health
```

---

## 🔐 Seguridad

- ✅ CORS configurado
- ✅ Helmet para headers de seguridad
- ✅ Rate limiting
- ✅ Validación de entrada con Joi
- ✅ Autenticación por API Key
- ✅ Logging de auditoría
- ✅ Manejo seguro de errores

---

## 📦 Variables de Entorno

Ver `.env.example` para la lista completa

```bash
NODE_ENV=production
PORT=3000
N8N_WEBHOOK_URL=https://...
GOOGLE_SHEETS_ID=...
API_KEY=...
```

---

## 🧪 Tests

```bash
# Ejecutar todos los tests
npm test

# Watch mode
npm run test:watch

# Con cobertura
npm test -- --coverage
```

---

## 📊 Monitoreo

- Logs estructurados con Winston
- Health checks automáticos
- Métricas de rendimiento
- Alertas de errores

---

## 🤝 Contribuir

1. Fork el repositorio
2. Crear rama feature (`git checkout -b feature/AmazingFeature`)
3. Commit cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abrir Pull Request

---

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver archivo [LICENSE](LICENSE) para detalles.

---

## 👥 Soporte

- 📧 Email: support@elimfilters.com
- 🐛 Issues: [GitHub Issues](https://github.com/elimfilters/elimfilters-proxy-api/issues)
- 💬 Discussions: [GitHub Discussions](https://github.com/elimfilters/elimfilters-proxy-api/discussions)

---

**Versión**: 2.0.0  
**Última actualización**: Octubre 2025  
**Estado**: ✅ Production Ready
