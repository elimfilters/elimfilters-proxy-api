# 🚀 PLAN DE INTEGRACIÓN: GITHUB + RAILWAY
## ELIMFILTERS SKU Generator API v2.0

---

## 📊 ESTADO ACTUAL

✅ **Railway Deployment**: https://elimfilters-proxy-api-production.up.railway.app/
📂 **GitHub Repo**: https://github.com/elimfilters/elimfilters-proxy-api

---

## 🔄 FLUJO DE ACTUALIZACIÓN

```
Step 1: Actualizar GitHub
        ↓
Step 2: Railway detecta cambios
        ↓
Step 3: CI/CD Pipeline ejecuta build
        ↓
Step 4: Docker image se crea
        ↓
Step 5: Despliegue automático en Railway
        ↓
Step 6: API en vivo con nuevas reglas
```

---

## 📁 ESTRUCTURA DE ARCHIVOS PARA GITHUB

### A. Archivos a crear/actualizar en la rama `main`:

```
elimfilters-proxy-api/
│
├── 📄 src/
│   ├── 📄 index.js                    (✅ ACTUALIZADO)
│   ├── 📄 utils/
│   │   ├── 📄 dutyResolver.js         (✅ REGLA #1 - NUEVO)
│   │   ├── 📄 typeMapper.js           (✅ REGLA #2 - NUEVO)
│   │   └── 📄 skuGenerator.js         (✅ REGLA #3 - NUEVO)
│   ├── 📄 controllers/
│   │   └── 📄 skuController.js        (⏳ PENDIENTE)
│   ├── 📄 routes/
│   │   ├── 📄 skuRoutes.js            (⏳ PENDIENTE)
│   │   └── 📄 healthRoutes.js         (⏳ PENDIENTE)
│   ├── 📄 middleware/
│   │   ├── 📄 validation.js           (⏳ PENDIENTE)
│   │   └── 📄 errorHandler.js         (⏳ PENDIENTE)
│   └── 📄 services/
│       ├── 📄 n8nService.js           (⏳ PENDIENTE)
│       └── 📄 googleSheetsService.js  (⏳ PENDIENTE)
│
├── 📄 package.json                    (✅ ACTUALIZADO)
├── 📄 Dockerfile                      (✅ ACTUALIZADO)
├── 📄 railway.json                    (✅ ACTUALIZADO)
├── 📄 .env.example                    (✅ ACTUALIZADO)
├── 📄 README.md                       (✅ ACTUALIZADO)
├── 📄 .gitignore                      (⏳ PENDIENTE)
│
├── 📄 workflows/
│   └── 📄 ELIMFILTERS_SEARCH_MASTER_ENHANCED.json (✅ NUEVO)
│
├── 📄 docs/
│   ├── 📄 REGLA_1_DUTY_CLASSIFICATION.md (⏳ PENDIENTE)
│   ├── 📄 REGLA_2_TYPE_MAPPING.md       (⏳ PENDIENTE)
│   ├── 📄 REGLA_3_SKU_GENERATION.md     (⏳ PENDIENTE)
│   ├── 📄 API_ENDPOINTS.md              (⏳ PENDIENTE)
│   ├── 📄 DEPLOYMENT_GUIDE.md           (⏳ PENDIENTE)
│   └── 📄 N8N_INTEGRATION.md            (⏳ PENDIENTE)
│
├── 📄 tests/
│   ├── 📄 skuGenerator.test.js         (⏳ PENDIENTE)
│   ├── 📄 dutyResolver.test.js         (⏳ PENDIENTE)
│   └── 📄 typeMapper.test.js           (⏳ PENDIENTE)
│
└── 📄 .github/
    └── 📄 workflows/
        └── 📄 deploy.yml              (⏳ PENDIENTE)
```

---

## 📋 INSTRUCCIONES PASO A PASO

### PASO 1: Clonar el repositorio localmente

```bash
git clone https://github.com/elimfilters/elimfilters-proxy-api.git
cd elimfilters-proxy-api
```

### PASO 2: Crear rama para cambios

```bash
git checkout -b feature/regla-1-2-3-implementation
```

### PASO 3: Copiar los archivos generados

```bash
# Desde el directorio raíz del proyecto:

# 1. Copiar archivos principales
cp /home/claude/src-index.js src/index.js
cp /home/claude/package.json .
cp /home/claude/Dockerfile .
cp /home/claude/railway.json .
cp /home/claude/.env.example .
cp /home/claude/README.md .

# 2. Crear carpeta utils y copiar las reglas
mkdir -p src/utils
cp /home/claude/src-utils-dutyResolver.js src/utils/dutyResolver.js
cp /home/claude/src-utils-typeMapper.js src/utils/typeMapper.js
cp /home/claude/src-utils-skuGenerator.js src/utils/skuGenerator.js

# 3. Copiar flujo n8n
mkdir -p workflows
cp /mnt/user-data/outputs/ELIMFILTERS_SEARCH_MASTER_ENHANCED.json workflows/

# 4. Copiar documentación
mkdir -p docs
cp /mnt/user-data/outputs/ELIMFILTERS_Processed_Complete.xlsx docs/
```

### PASO 4: Crear archivos adicionales requeridos

#### A. `.gitignore`
```
node_modules/
.env
.env.local
.DS_Store
*.log
logs/
dist/
build/
.vscode/
.idea/
.env.*.local
npm-debug.log*
yarn-debug.log*
```

#### B. `src/middleware/validation.js`
```javascript
const Joi = require('joi');

module.exports = (req, res, next) => {
  const apiKey = req.headers.authorization?.replace('Bearer ', '');
  
  if (!apiKey && process.env.NODE_ENV === 'production') {
    return res.status(401).json({ 
      ok: false, 
      error: 'API Key required' 
    });
  }
  
  if (apiKey && apiKey !== process.env.API_KEY) {
    return res.status(403).json({ 
      ok: false, 
      error: 'Invalid API Key' 
    });
  }
  
  next();
};
```

#### C. `src/middleware/errorHandler.js`
```javascript
module.exports = (err, req, res, next) => {
  console.error(err);
  
  res.status(err.status || 500).json({
    ok: false,
    error: err.message || 'Internal server error',
    timestamp: new Date().toISOString()
  });
};
```

#### D. `src/routes/healthRoutes.js`
```javascript
const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json({
    ok: true,
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV
  });
});

module.exports = router;
```

#### E. `src/routes/skuRoutes.js`
```javascript
const express = require('express');
const { generateSKU, validateSKU } = require('../utils/skuGenerator');
const router = express.Router();

router.post('/generate', (req, res, next) => {
  try {
    const { code, filterType, duty, oemCodes } = req.body;
    
    if (!code || !filterType) {
      return res.status(400).json({
        ok: false,
        error: 'code and filterType are required'
      });
    }
    
    const result = generateSKU({
      code,
      filterType,
      duty,
      oemCodes
    });
    
    res.json({
      ok: true,
      data: result,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    next(error);
  }
});

router.get('/validate/:sku', (req, res) => {
  const result = validateSKU(req.params.sku);
  
  res.json({
    ok: result.valid,
    data: result,
    timestamp: new Date().toISOString()
  });
});

module.exports = router;
```

### PASO 5: Actualizar package.json

```bash
npm install
```

### PASO 6: Probar localmente

```bash
npm run dev
# Debería ver:
# ╔════════════════════════════════════════════════════════════════════════╗
# ║         ELIMFILTERS SKU GENERATOR API - RAILWAY DEPLOYMENT             ║
# ...
```

### PASO 7: Commit y Push a GitHub

```bash
git add .
git commit -m "feat: Implement REGLA #1, #2, #3 with n8n integration

- REGLA #1: Duty classification (HD/LD) based on OEM
- REGLA #2: Filter type to prefix mapping
- REGLA #3: Priority code search and SKU generation
- Add Google Sheets integration
- Add comprehensive documentation
- Add Docker configuration for Railway"

git push origin feature/regla-1-2-3-implementation
```

### PASO 8: Crear Pull Request en GitHub

```bash
# En GitHub:
1. Ir a https://github.com/elimfilters/elimfilters-proxy-api
2. Click en "New Pull Request"
3. Seleccionar rama: "feature/regla-1-2-3-implementation"
4. Describir cambios
5. Hacer merge a "main"
```

### PASO 9: Railway detectará cambios automáticamente

```
✅ GitHub conectado a Railway
✅ Webhook de deployment activado
✅ Build automático iniciado
✅ Docker image creado
✅ Despliegue en Railway
✅ API en vivo en: https://elimfilters-proxy-api-production.up.railway.app
```

---

## 🧪 TESTING POST-DEPLOY

Después de que Railway despliegue, prueba los endpoints:

### Test 1: Health Check
```bash
curl https://elimfilters-proxy-api-production.up.railway.app/api/health
```

### Test 2: Generate SKU
```bash
curl -X POST https://elimfilters-proxy-api-production.up.railway.app/api/sku/generate \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "code": "P164378",
    "filterType": "HYDRAULIC",
    "duty": "HD",
    "oemCodes": ["P164378", "85000381"]
  }'
```

### Test 3: Validate SKU
```bash
curl https://elimfilters-proxy-api-production.up.railway.app/api/sku/validate/EH64378 \
  -H "Authorization: Bearer YOUR_API_KEY"
```

---

## ⚙️ CONFIGURACIÓN EN RAILWAY

### Variables de Entorno a configurar en Railway:

1. **Ir a Railway Dashboard**
2. **Seleccionar proyecto: elimfilters-proxy-api-production**
3. **ir a Settings → Variables**
4. **Agregar:**

```
NODE_ENV=production
PORT=3000
API_KEY=your-secret-key
GOOGLE_SHEETS_ID=1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U
N8N_WEBHOOK_URL=https://your-n8n-instance.com/webhook/elimfilters
LOG_LEVEL=info
CORS_ORIGIN=*
```

---

## 📊 MONITOREO

En Railway Dashboard:

```
✅ Deployments → Ver historial de despliegues
✅ Logs → Ver logs en tiempo real
✅ Metrics → CPU, Memoria, Requests
✅ Alerts → Configurar alertas de error
```

---

## 🔍 VALIDACIONES POST-DEPLOY

| Validación | Comando | Esperado |
|-----------|---------|----------|
| Health Check | `GET /api/health` | `{ ok: true, status: 'healthy' }` |
| Generate SKU (HD) | `POST /api/sku/generate` | `{ SKU: 'EH64378', validated: true }` |
| Generate SKU (LD) | `POST /api/sku/generate` | `{ SKU: 'EL80123', validated: true }` |
| Validate SKU | `GET /api/sku/validate/EH64378` | `{ valid: true, ... }` |
| REGLA #1 (Duty) | Clasificar OEM | HD u LD correcto |
| REGLA #2 (Type) | Mapear tipo a prefijo | Prefijo correcto |
| REGLA #3 (SKU) | Generar con dígitos | 7 caracteres exactos |

---

## 🚨 TROUBLESHOOTING

### Railway no despliega
- ✅ Verificar que GitHub esté conectado
- ✅ Ver logs en Railway: `railway logs`
- ✅ Verificar Dockerfile: `docker build .`

### API retorna 500
- ✅ Ver logs: `railway logs --tail`
- ✅ Verificar variables de entorno
- ✅ Verificar conexión a n8n

### Errores de Build
- ✅ Verificar package.json
- ✅ Ejecutar localmente: `npm install && npm run dev`
- ✅ Ver error en Railway Deployment logs

---

## 📝 NOTAS IMPORTANTES

- Railway despliega automáticamente en cada `git push` a `main`
- Los cambios son en **VIVO en producción** inmediatamente
- Siempre hacer testing local antes de push
- Mantener `.env` variables sincronizadas
- Hacer backup de datos antes de cambios mayores

---

**Versión**: 2.0.0  
**Última actualización**: Octubre 2025  
**Status**: 🟢 Ready for Deployment
