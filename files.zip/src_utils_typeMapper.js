// src/utils/typeMapper.js
/**
 * REGLA #2: Mapeo de Tipos de Filtro a Prefijos ELIMINFILTERS
 * Asigna prefijo único según tipo de filtro y duty
 */

const FILTER_TYPES_MAP = {
  // MULTIUSOS (HD-LD)
  'OIL': {
    prefix: 'EL8',
    name: 'Filtro de Aceite',
    duty: ['HD', 'LD'],
    patterns: ['oil', 'lube', 'lubricant', 'aceite'],
    description: 'Engine Oil Filter - Lubricant filtration'
  },
  'FUEL': {
    prefix: 'EF9',
    name: 'Filtro de Combustible',
    duty: ['HD', 'LD'],
    patterns: ['fuel', 'gasolina', 'diesel', 'combustible'],
    description: 'Fuel Filter - Engine fuel filtration'
  },
  'AIR': {
    prefix: 'EA1',
    name: 'Filtro de Aire',
    duty: ['HD', 'LD'],
    patterns: ['air', 'aire', 'intake', 'aspiracion'],
    description: 'Air Filter - Standard, Radial Seal, Round, Axial Seal'
  },
  'AIR_RADIAL_SEAL': {
    prefix: 'EA1',
    name: 'Filtro de Aire - Radial Seal',
    duty: ['HD', 'LD'],
    patterns: ['radial seal', 'radial', 'radialseal'],
    description: 'Air Filter with Radial Seal design'
  },
  'AIR_ROUND': {
    prefix: 'EA1',
    name: 'Filtro de Aire - Round',
    duty: ['HD', 'LD'],
    patterns: ['round air', 'round filter', 'round'],
    description: 'Cylindrical Air Filter'
  },
  'AIR_AXIAL_SEAL': {
    prefix: 'EA1',
    name: 'Filtro de Aire - Axial Seal',
    duty: ['HD', 'LD'],
    patterns: ['axial seal', 'axial', 'axialseal'],
    description: 'Air Filter with Axial Seal design'
  },
  'CABIN_FILTER': {
    prefix: 'EC1',
    name: 'Filtro de Cabina',
    duty: ['HD', 'LD'],
    patterns: ['cabin', 'cabina', 'interior', 'pollen'],
    description: 'Cabin Air Filter - Dust and pollen control'
  },

  // SOLO HEAVY DUTY
  'SEPARATOR_FUEL': {
    prefix: 'ES9',
    name: 'Separador de Combustible',
    duty: ['HD'],
    patterns: ['separator', 'separador', 'fuel water', 'water separator'],
    description: 'Fuel-Water Separator - HD only'
  },
  'HYDRAULIC': {
    prefix: 'EH6',
    name: 'Filtro Hidráulico',
    duty: ['HD'],
    patterns: ['hydraulic', 'hidraulico', 'hydraulics'],
    description: 'Hydraulic Fluid Filter - Heavy equipment'
  },
  'COOLANT': {
    prefix: 'EW7',
    name: 'Filtro de Refrigerante',
    duty: ['HD'],
    patterns: ['coolant', 'refrigerante', 'coolant filter', 'water filter'],
    description: 'Engine Coolant Filter - HD only'
  },
  'AIR_DRYER': {
    prefix: 'ED4',
    name: 'Secador de Aire',
    duty: ['HD'],
    patterns: ['air dryer', 'desiccant', 'dryer', 'secador aire'],
    description: 'Air Dryer Cartridge - Compressed air drying'
  },
  'TURBINE_SERIES': {
    prefix: 'ET9',
    name: 'Turbina/Portafiltro',
    duty: ['HD'],
    patterns: ['turbine', 'portafiltro', 'turbo', 'port filter'],
    description: 'Turbine/Port Filter Series - HD only'
  },
  'KIT_DIESEL': {
    prefix: 'EK5',
    name: 'Kit Diesel',
    duty: ['HD'],
    patterns: ['kit diesel', 'kit', 'diesel kit'],
    description: 'Diesel Engine Filter Kit - HD only'
  },
  'KIT_GASOLINA': {
    prefix: 'EK3',
    name: 'Kit Gasolina',
    duty: ['LD'],
    patterns: ['kit gasolina', 'kit gasoline', 'gasoline kit'],
    description: 'Gasoline Engine Filter Kit - LD only'
  },
  'HOUSING': {
    prefix: 'EB1',
    name: 'Carcasa para Filtros',
    duty: ['HD'],
    patterns: ['housing', 'carcasa', 'case', 'head'],
    description: 'Air Filter Housing - HD only'
  }
};

/**
 * Mapea un tipo de filtro a su prefijo correspondiente
 * @param {string} filterType - Tipo de filtro
 * @returns {Object} { prefix, name, duty, description }
 */
function mapTypeToPrefix(filterType) {
  const typeUpper = String(filterType || '').toUpperCase().replace(/[-_\s]/g, '_');
  
  if (FILTER_TYPES_MAP[typeUpper]) {
    return FILTER_TYPES_MAP[typeUpper];
  }
  
  // Buscar por pattern si no hay coincidencia directa
  const searchText = typeUpper.toLowerCase();
  for (const [key, config] of Object.entries(FILTER_TYPES_MAP)) {
    if (config.patterns.some(p => searchText.includes(p))) {
      return config;
    }
  }
  
  // Default: Air filter
  return FILTER_TYPES_MAP['AIR'];
}

/**
 * Obtiene el prefijo de un tipo de filtro
 * @param {string} filterType - Tipo de filtro
 * @returns {string} Prefijo (ej: 'EA1', 'EL8')
 */
function getPrefix(filterType) {
  return mapTypeToPrefix(filterType).prefix;
}

/**
 * Valida que el tipo sea compatible con el duty
 * @param {string} filterType - Tipo de filtro
 * @param {string} duty - 'HD' o 'LD'
 * @returns {boolean}
 */
function isValidForDuty(filterType, duty) {
  const config = mapTypeToPrefix(filterType);
  return config.duty.includes(duty);
}

/**
 * Obtiene todos los tipos de filtro válidos para un duty
 * @param {string} duty - 'HD' o 'LD'
 * @returns {Array}
 */
function getTypesForDuty(duty) {
  return Object.entries(FILTER_TYPES_MAP)
    .filter(([_, config]) => config.duty.includes(duty))
    .map(([key, config]) => ({
      key,
      name: config.name,
      prefix: config.prefix,
      description: config.description
    }));
}

/**
 * Detecta el tipo de filtro basado en patrón de código
 * @param {string} code - Código del filtro
 * @returns {string} Tipo detectado
 */
function detectTypeFromCode(code) {
  const codeUpper = String(code || '').toUpperCase();
  
  // Heurística: buscar patrones conocidos
  for (const [type, config] of Object.entries(FILTER_TYPES_MAP)) {
    if (config.patterns.some(p => codeUpper.includes(p))) {
      return type;
    }
  }
  
  return 'AIR'; // Default
}

module.exports = {
  mapTypeToPrefix,
  getPrefix,
  isValidForDuty,
  getTypesForDuty,
  detectTypeFromCode,
  FILTER_TYPES_MAP
};
