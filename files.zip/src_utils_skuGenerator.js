// src/utils/skuGenerator.js
/**
 * REGLA #3: Generador de SKU con búsqueda de código prioritario
 * 1. Buscar Donaldson (HD) o FRAM (LD)
 * 2. Extraer últimos 4 dígitos
 * 3. Construir SKU: [PREFIJO] + [4 DÍGITOS]
 */

const dutyResolver = require('./dutyResolver');
const typeMapper = require('./typeMapper');

/**
 * Manfacturantes prioritarios por duty
 */
const PRIORITY_MANUFACTURERS = {
  'HD': ['Donaldson', 'P'], // Búsqueda con prefijo P
  'LD': ['FRAM', 'PH', 'CA', 'CH'] // Búsqueda con prefijos PH, CA, CH
};

/**
 * Extrae los últimos 4 dígitos de un código
 * @param {string} code - Código del filtro
 * @returns {string} Últimos 4 dígitos (padded con ceros si es necesario)
 */
function extractLast4Digits(code) {
  const digitsOnly = String(code || '').replace(/[^0-9]/g, '');
  
  if (!digitsOnly) {
    throw new Error('No digits found in code');
  }
  
  return digitsOnly.slice(-4).padStart(4, '0');
}

/**
 * Valida que los dígitos sean válidos (no todos ceros)
 * @param {string} digits - 4 dígitos
 * @returns {boolean}
 */
function areDigitsValid(digits) {
  return digits !== '0000' && digits.length === 4;
}

/**
 * Busca el código prioritario (Donaldson para HD, FRAM para LD)
 * @param {string} code - Código del filtro
 * @param {string} duty - 'HD' o 'LD'
 * @param {Array} oemCodes - Códigos OEM adicionales (opcional)
 * @returns {Object} { foundCode, manufacturer, digits, isPriority }
 */
function searchPriorityCode(code, duty, oemCodes = []) {
  const priority = PRIORITY_MANUFACTURERS[duty];
  const allCodes = [code, ...oemCodes];
  const codeUpper = String(code).toUpperCase();
  
  // Buscar prefijo prioritario (P para HD, PH/CA/CH para LD)
  for (const prefixPattern of priority.slice(1)) {
    for (const checkCode of allCodes) {
      const checkUpper = String(checkCode).toUpperCase();
      if (checkUpper.startsWith(prefixPattern)) {
        try {
          const digits = extractLast4Digits(checkCode);
          if (areDigitsValid(digits)) {
            return {
              foundCode: checkCode,
              manufacturer: priority[0],
              digits: digits,
              isPriority: true,
              source: 'PRIORITY_SEARCH'
            };
          }
        } catch (e) {
          // Continuar buscando
        }
      }
    }
  }
  
  // Si no encuentra código prioritario, usar el código original
  try {
    const digits = extractLast4Digits(code);
    if (areDigitsValid(digits)) {
      return {
        foundCode: code,
        manufacturer: 'OEM_COMMERCIAL',
        digits: digits,
        isPriority: false,
        source: 'FALLBACK'
      };
    }
  } catch (e) {
    throw new Error(`Invalid code format: ${code}`);
  }
  
  throw new Error(`Cannot extract valid digits from ${code}`);
}

/**
 * Genera el SKU completo
 * @param {Object} options - Opciones de generación
 * @param {string} options.code - Código del filtro
 * @param {string} options.filterType - Tipo de filtro
 * @param {string} options.duty - 'HD' o 'LD' (opcional, se calcula si no se proporciona)
 * @param {Array} options.oemCodes - Códigos OEM (opcional)
 * @returns {Object} { SKU, prefix, digits, duty, filterType, validated }
 */
function generateSKU(options = {}) {
  const {
    code,
    filterType,
    duty,
    oemCodes = []
  } = options;
  
  // Validaciones básicas
  if (!code) {
    throw new Error('Code is required');
  }
  
  if (!filterType) {
    throw new Error('Filter type is required');
  }
  
  // Resolver Duty si no se proporciona
  const resolvedDuty = duty || 'HD'; // Default HD
  
  // Obtener prefijo del tipo de filtro
  const typeConfig = typeMapper.mapTypeToPrefix(filterType);
  const prefix = typeConfig.prefix;
  
  // Validar compatibilidad Type + Duty
  if (!typeMapper.isValidForDuty(filterType, resolvedDuty)) {
    throw new Error(
      `Filter type '${filterType}' is not valid for duty '${resolvedDuty}'. ` +
      `Valid types: ${typeMapper.getTypesForDuty(resolvedDuty).map(t => t.key).join(', ')}`
    );
  }
  
  // Buscar código prioritario
  const codeSearch = searchPriorityCode(code, resolvedDuty, oemCodes);
  
  // Construir SKU
  const sku = (prefix + codeSearch.digits).toUpperCase();
  
  // Validar formato SKU
  if (sku.length !== 7) {
    throw new Error(
      `Invalid SKU length: ${sku} (expected 7 characters)`
    );
  }
  
  // Validar que solo contenga caracteres válidos
  if (!/^[A-Z0-9]{7}$/.test(sku)) {
    throw new Error(
      `Invalid SKU format: ${sku} (must be alphanumeric only)`
    );
  }
  
  return {
    SKU: sku,
    prefix: prefix,
    digits: codeSearch.digits,
    duty: resolvedDuty,
    filterType: filterType,
    sourceCode: codeSearch.foundCode,
    manufacturer: codeSearch.manufacturer,
    isPriorityCode: codeSearch.isPriority,
    searchSource: codeSearch.source,
    validated: true
  };
}

/**
 * Valida un SKU existente
 * @param {string} sku - SKU a validar
 * @returns {Object} { valid, prefix, digits, filterType, duty }
 */
function validateSKU(sku) {
  if (!sku || !/^[A-Z]{2}[0-9]{5}$/.test(sku)) {
    return {
      valid: false,
      error: 'Invalid SKU format. Expected: 2 letters + 5 digits'
    };
  }
  
  const prefix = sku.substring(0, 2);
  const digits = sku.substring(2);
  
  // Buscar en mapa de tipos
  let filterType = null;
  for (const [type, config] of Object.entries(typeMapper.FILTER_TYPES_MAP)) {
    if (config.prefix === prefix) {
      filterType = type;
      break;
    }
  }
  
  if (!filterType) {
    return {
      valid: false,
      error: `Unknown prefix: ${prefix}`
    };
  }
  
  return {
    valid: true,
    prefix: prefix,
    digits: digits,
    filterType: filterType,
    SKU: sku
  };
}

module.exports = {
  generateSKU,
  validateSKU,
  extractLast4Digits,
  areDigitsValid,
  searchPriorityCode,
  PRIORITY_MANUFACTURERS
};
