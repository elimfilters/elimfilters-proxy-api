// src/utils/dutyResolver.js
/**
 * REGLA #1: Identificar DUTY (HD/LD) basado en OEM y características del motor
 */

const HD_OEMs = [
  // Diesel Engines - Commercial/Industrial
  'Caterpillar', 'CAT', 'Komatsu', 'John Deere', 'JD', 'Kubota', 'Mack', 'Peterbilt', 
  'Volvo', 'Isuzu', 'Cummins', 'Detroit Diesel', 'International', 'Freightliner', 
  'Scania', 'DAF', 'Mercedes-Benz', 'Hino', 'Perkins', 'Detroit', 'MWM', 'FPT',
  'Iveco', 'Renault', 'MAN', 'Navistar', 'Duramax', 'Powerstroke', 'Cummins ISX'
];

const LD_OEMs = [
  // Gasoline Engines - Personal/Light Commercial
  'Toyota', 'Nissan', 'Honda', 'BMW', 'Audi', 'Lexus', 'Volkswagen', 'Chevrolet', 
  'Ford', 'Kia', 'Hyundai', 'Mercedes', 'Porsche', 'Jaguar', 'Land Rover', 'Tesla',
  'Subaru', 'Mazda', 'Mitsubishi', 'Daimler', 'Fiat', 'Peugeot', 'Renault', 'SEAT',
  'Opel', 'Vauxhall', 'Acura', 'Infiniti', 'Cadillac', 'GMC', 'Dodge', 'RAM'
];

/**
 * Resuelve el DUTY basado en información del motor y OEM
 * @param {Object} filterData - Datos del filtro
 * @param {string} filterData.motorManufacturer - Fabricante del motor
 * @param {string} filterData.equipmentType - Tipo de equipo
 * @param {string} filterData.motorType - Tipo de motor (diesel/gasolina)
 * @returns {string} 'HD' o 'LD'
 */
function resolveDuty(filterData) {
  const { motorManufacturer = '', equipmentType = '', motorType = '' } = filterData;
  
  const allText = `${motorManufacturer} ${equipmentType} ${motorType}`.toUpperCase();
  
  // REGLA: Si es diesel + OEM HD → HD
  if (motorType.toUpperCase().includes('DIESEL')) {
    for (const oem of HD_OEMs) {
      if (allText.includes(oem.toUpperCase())) {
        return 'HD';
      }
    }
    // Diesel sin OEM reconocido → Asumir HD (aunque es comercial)
    return 'HD';
  }
  
  // REGLA: Si es gasolina + OEM LD → LD
  if (motorType.toUpperCase().includes('GASOLINA') || motorType.toUpperCase().includes('GASOLINE')) {
    return 'LD';
  }
  
  // REGLA: Buscar OEM en los textos
  for (const oem of LD_OEMs) {
    if (allText.includes(oem.toUpperCase())) {
      return 'LD';
    }
  }
  
  for (const oem of HD_OEMs) {
    if (allText.includes(oem.toUpperCase())) {
      return 'HD';
    }
  }
  
  // DEFAULT: HD (camiones/equipos pesados suelen ser HD)
  return 'HD';
}

/**
 * Valida que el OEM sea válido para el tipo de duty
 * @param {string} oem - Código OEM
 * @param {string} duty - Duty clasificado
 * @returns {boolean}
 */
function validateOEMForDuty(oem, duty) {
  const oemUpper = String(oem).toUpperCase();
  
  if (duty === 'HD') {
    return HD_OEMs.some(h => oemUpper.includes(h.toUpperCase()));
  } else if (duty === 'LD') {
    return LD_OEMs.some(l => oemUpper.includes(l.toUpperCase()));
  }
  
  return true; // Si no es HD ni LD, pasar
}

/**
 * Obtiene lista de OEMs válidos por duty
 * @param {string} duty - 'HD' o 'LD'
 * @returns {Array}
 */
function getOEMsForDuty(duty) {
  return duty === 'HD' ? HD_OEMs : LD_OEMs;
}

module.exports = {
  resolveDuty,
  validateOEMForDuty,
  getOEMsForDuty,
  HD_OEMs,
  LD_OEMs
};
