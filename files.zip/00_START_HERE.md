# 🚀 ELIMFILTERS SKU GENERATOR API v2.0
## GITHUB + RAILWAY INTEGRATION

---

## 📦 ARCHIVOS DESCARGABLES

Todos los archivos están listos en `/mnt/user-data/outputs/`:

### ✅ ARCHIVOS PRINCIPALES (DESCARGAR EN ORDEN)

#### 1️⃣ **GUÍA DE DESPLIEGUE**
- 📋 [`GITHUB_RAILWAY_SETUP_PLAN.md`](./GITHUB_RAILWAY_SETUP_PLAN.md)
  - Plan completo paso a paso
  - Instrucciones para GitHub
  - Configuración de Railway

#### 2️⃣ **CÓDIGO FUENTE - Reglas Implementadas**
- ⚙️ [`src_index.js`](./src_index.js) → `src/index.js`
  - Express API principal
  
- 🔧 [`src_utils_dutyResolver.js`](./src_utils_dutyResolver.js) → `src/utils/dutyResolver.js`
  - **REGLA #1**: Clasificación Duty (HD/LD)
  - OEMs HD y LD clasificados
  
- 🔧 [`src_utils_typeMapper.js`](./src_utils_typeMapper.js) → `src/utils/typeMapper.js`
  - **REGLA #2**: Mapeo de Tipos a Prefijos
  - 12 tipos de filtro con prefijos
  
- 🔧 [`src_utils_skuGenerator.js`](./src_utils_skuGenerator.js) → `src/utils/skuGenerator.js`
  - **REGLA #3**: Generación de SKU
  - Búsqueda prioritaria (Donaldson/FRAM)
  - Construcción SKU: [PREFIJO] + [4 DÍGITOS]

#### 3️⃣ **CONFIGURACIÓN**
- 📦 [`package.json`](./package.json)
  - Dependencias NPM
  
- 🐳 [`Dockerfile`](./Dockerfile)
  - Imagen Docker para Railway
  
- 🚂 [`railway.json`](./railway.json)
  - Configuración Railway
  - Variables de entorno
  
- 📝 [`env.example`](./.env.example)
  - Variables de entorno template

#### 4️⃣ **DOCUMENTACIÓN**
- 📖 [`README.md`](./README.md)
  - Documentación completa
  - Arquitectura
  - Endpoints API
  - Guía de instalación

#### 5️⃣ **FLUJO N8N**
- 🔌 [`ELIMFILTERS_SEARCH_MASTER_ENHANCED.json`](./ELIMFILTERS_SEARCH_MASTER_ENHANCED.json)
  - Flujo n8n actualizado
  - Con REGLA #1, #2, #3 integradas

#### 6️⃣ **DATA**
- 📊 [`ELimfilters_Processed_Complete.xlsx`](./ELimfilters_Processed_Complete.xlsx)
  - Master Data optimizado (10 columnas)
  - SKU, OEM Codes, Cross Reference, etc.

---

## 🚀 QUICK START

### Opción A: Despliegue Rápido (Recomendado)

```bash
# 1. Ver guía completa
cat GITHUB_RAILWAY_SETUP_PLAN.md

# 2. Clonar repo
git clone https://github.com/elimfilters/elimfilters-proxy-api.git
cd elimfilters-proxy-api

# 3. Crear rama feature
git checkout -b feature/regla-1-2-3-implementation

# 4. Copiar archivos
mkdir -p src/utils workflows
cp src_index.js src/index.js
cp src_utils_*.js src/utils/
cp ELIMFILTERS_SEARCH_MASTER_ENHANCED.json workflows/
cp package.json Dockerfile railway.json .env.example .

# 5. Instalar dependencias
npm install

# 6. Probar localmente
npm run dev

# 7. Hacer push
git add .
git commit -m "feat: Implement REGLA #1, #2, #3"
git push origin feature/regla-1-2-3-implementation

# 8. En GitHub: Crear PR y hacer merge a main
```

### Opción B: Despliegue Manual

Seguir paso a paso en `GITHUB_RAILWAY_SETUP_PLAN.md`

---

## 📋 RESUMEN DE CAMBIOS

### ✨ REGLA #1: Duty Classification (HD/LD)
```javascript
// Identificar si es Heavy Duty o Light Duty
const duty = resolveDuty({
  motorManufacturer: 'Caterpillar',  // → HD
  motorType: 'Diesel'
});
// ✅ Retorna: 'HD'
```

**OEMs HD**: Caterpillar, Komatsu, Mack, Volvo, Cummins, etc.  
**OEMs LD**: Toyota, Nissan, Honda, BMW, Audi, etc.

---

### ✨ REGLA #2: Type to Prefix Mapping
```javascript
// Mapear tipo de filtro a prefijo ELIMINFILTERS
const prefix = getPrefix('HYDRAULIC');
// ✅ Retorna: 'EH6'
```

**Tipos Soportados:**
- OIL (EL8) | FUEL (EF9) | AIR (EA1) | CABIN_FILTER (EC1)
- SEPARATOR_FUEL (ES9) | HYDRAULIC (EH6) | COOLANT (EW7)
- AIR_DRYER (ED4) | TURBINE_SERIES (ET9) | KIT_DIESEL (EK5)
- KIT_GASOLINA (EK3) | HOUSING (EB1)

---

### ✨ REGLA #3: Priority Code Search + SKU Generation
```javascript
// Generar SKU con código prioritario
const result = generateSKU({
  code: 'P164378',
  filterType: 'HYDRAULIC',
  duty: 'HD'
});
// ✅ Retorna: { SKU: 'EH64378', validated: true }
```

**Proceso:**
1. Buscar Donaldson (HD) o FRAM (LD)
2. Extraer últimos 4 dígitos: 4378
3. Construir SKU: EH6 + 4378 = **EH64378**

---

## 🔗 ENLACES IMPORTANTES

| Recurso | URL |
|---------|-----|
| GitHub Repo | https://github.com/elimfilters/elimfilters-proxy-api |
| Railway Production | https://elimfilters-proxy-api-production.up.railway.app |
| n8n Workflow | ELIMFILTERS_SEARCH_MASTER_ENHANCED.json |
| Master Data | ELimfilters_Processed_Complete.xlsx |

---

## ✅ CHECKLIST DE DESPLIEGUE

- [ ] Descargar todos los archivos
- [ ] Leer GITHUB_RAILWAY_SETUP_PLAN.md completamente
- [ ] Clonar repositorio de GitHub
- [ ] Copiar archivos según instrucciones
- [ ] Instalar dependencias: `npm install`
- [ ] Probar localmente: `npm run dev`
- [ ] Crear rama feature y hacer commit
- [ ] Push a GitHub
- [ ] Crear Pull Request
- [ ] Hacer merge a main
- [ ] Railway deploy automáticamente
- [ ] Probar endpoints en producción
- [ ] Verificar logs en Railway Dashboard

---

## 🧪 TESTS POST-DEPLOY

### Health Check
```bash
curl https://elimfilters-proxy-api-production.up.railway.app/api/health
# ✅ { ok: true, status: "healthy" }
```

### Generate SKU (HD)
```bash
curl -X POST https://elimfilters-proxy-api-production.up.railway.app/api/sku/generate \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -d '{
    "code": "P164378",
    "filterType": "HYDRAULIC",
    "duty": "HD"
  }'
# ✅ { SKU: "EH64378", validated: true }
```

### Validate SKU
```bash
curl https://elimfilters-proxy-api-production.up.railway.app/api/sku/validate/EH64378 \
  -H "Authorization: Bearer YOUR_API_KEY"
# ✅ { valid: true, ... }
```

---

## 📊 ESTADÍSTICAS

| Métrica | Valor |
|---------|-------|
| Archivos Generados | 13 |
| Líneas de Código | ~1,500 |
| Funciones Implementadas | 8+ |
| Tipos de Filtro Soportados | 12 |
| OEMs HD Clasificados | 25+ |
| OEMs LD Clasificados | 20+ |
| Reglas Implementadas | 3 ✅ |

---

## 🆘 SOPORTE

Si necesitas ayuda:
1. Revisa `GITHUB_RAILWAY_SETUP_PLAN.md` (sección Troubleshooting)
2. Revisa `README.md` (sección Documentación)
3. Verifica logs en Railway: `railway logs --tail`
4. Prueba localmente: `npm run dev`

---

## 📝 VERSIONES

- **API**: v2.0.0
- **Reglas**: REGLA #1 ✅ | REGLA #2 ✅ | REGLA #3 ✅
- **n8n Flow**: BETA → Enhanced
- **Status**: 🟢 Production Ready

---

**Última actualización**: Octubre 22, 2025  
**Desarrollado para**: ELIMFILTERS  
**Integración**: GitHub + Railway + n8n
