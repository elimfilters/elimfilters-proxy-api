// src/index.js
const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const helmet = require('helmet');

// Importar rutas
const skuRoutes = require('./routes/skuRoutes');
const healthRoutes = require('./routes/healthRoutes');

// Middleware
const errorHandler = require('./middleware/errorHandler');
const requestValidator = require('./middleware/validation');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

// Security & Parsing
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request Logger
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// Health Check
app.use('/api/health', healthRoutes);

// SKU Generator Routes
app.use('/api/sku', requestValidator, skuRoutes);

// 404 Handler
app.use((req, res) => {
  res.status(404).json({
    ok: false,
    error: 'Endpoint not found',
    path: req.path
  });
});

// Error Handler (debe ir al final)
app.use(errorHandler);

// Server Start
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════════════════╗
║         ELIMFILTERS SKU GENERATOR API - RAILWAY DEPLOYMENT             ║
╠════════════════════════════════════════════════════════════════════════╣
║ Server running on: http://localhost:${PORT}
║ Environment: ${process.env.NODE_ENV || 'development'}
║ API Documentation: /api/docs
║ Health Check: /api/health
╚════════════════════════════════════════════════════════════════════════╝
  `);
});

process.on('unhandledRejection', (err) => {
  console.error('Unhandled Rejection:', err);
  process.exit(1);
});

module.exports = app;
