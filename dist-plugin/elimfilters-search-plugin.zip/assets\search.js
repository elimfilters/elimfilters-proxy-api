jQuery(document).ready(function($) {
    
    const searchForm = $('#elimfilters-search-form');
    const searchInput = $('#elimfilters-search-input');
    const searchButton = $('.elimfilters-search-button');
    const loadingSpinner = $('.loading-spinner');
    const errorContainer = $('#elimfilters-search-error');
    const suggestionsContainer = $('#elimfilters-search-suggestions');
    
    let searchTimeout;
    let lastSearchQuery = '';
    
    /**
     * Manejar envío del formulario
     */
    searchForm.on('submit', function(e) {
        e.preventDefault();
        
        const query = searchInput.val().trim();
        
        if (!query) {
            showError('Por favor ingrese un código OEM o Cross Reference');
            return;
        }
        
        // Si hay página de resultados configurada, redirigir usando su permalink real
        if (elimfilters_ajax.results_page) {
            const base = elimfilters_ajax.results_page;
            const sep = base.includes('?') ? '&' : '?';
            const resultsUrl = base + sep + 'part=' + encodeURIComponent(query);
            window.location.href = resultsUrl;
        } else {
            // Realizar búsqueda AJAX directamente
            performSearch(query);
        }
    });
    
    /**
     * Búsqueda en tiempo real (opcional)
     */
    searchInput.on('input', function() {
        const query = $(this).val().trim();
        
        // Limpiar timeout anterior
        clearTimeout(searchTimeout);
        
        // Ocultar error
        hideError();
        
        if (query.length < 2) {
            hideSuggestions();
            return;
        }
        
        // Esperar 300ms después de dejar de escribir
        searchTimeout = setTimeout(function() {
            if (query !== lastSearchQuery) {
                lastSearchQuery = query;
                // Puedes descomentar esto si quieres sugerencias en tiempo real
                // getSuggestions(query);
            }
        }, 300);
    });
    
    /**
     * Realizar búsqueda AJAX
     */
    function performSearch(query) {
        showLoading(true);
        hideError();
        // Mostrar loader inline si existe el contenedor en la página del formulario
        showInlineLoading(true);
        
        $.ajax({
            url: elimfilters_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'elimfilters_search',
                nonce: elimfilters_ajax.nonce,
                query: query
            },
            timeout: 25000,
            success: function(response) {
                showLoading(false);
                showInlineLoading(false);
                try {
                    if (response && response.success) {
                        displayResults(response.data || {});
                    } else {
                        const msg = (response && response.data && response.data.message)
                            ? response.data.message
                            : 'No se encontraron resultados';
                        showError(msg);
                    }
                } catch (e) {
                    showError('Ocurrió un error inesperado al procesar la respuesta');
                }
            },
            error: function() {
                showLoading(false);
                showInlineLoading(false);
                showError('Error al conectar con el servidor. Por favor, intente nuevamente.');
            }
        });
    }
    
    /**
     * Mostrar resultados
     */
    function displayResults(data) {
        const resultsContainer = $('#elimfilters-results-content');
        // Buscar el loader más cercano al contenedor de resultados (inline o página de resultados)
        const loadingContainer = resultsContainer.closest('.elimfilters-results-container, .elimfilters-inline-results').find('.results-loading');
        
        if (!resultsContainer.length) {
            // Si no existe contenedor de resultados (p.ej., estamos en la página del formulario),
            // evita fallar silenciosamente y muestra un error amigable.
            showError('Los resultados no pudieron mostrarse aquí. Intente nuevamente o use la página de resultados.');
            return;
        }
        
        // Ocultar loading
        loadingContainer.hide();
        
        let html = '';
        
        if (data.status === 'OK' && data.data) {
            const result = data.data;
            const source = data.source || 'generated';
            const responseTime = data.response_time_ms || 0;
            
            html = `
                <div class="elimfilters-result-card">
                    <div class="result-header">
                        <h3>Resultado de Búsqueda</h3>
                        <span class="result-source source-${source}">
                            ${source === 'cache' ? 'Desde caché' : 'Generado'}
                        </span>
                    </div>
                    
                    <div class="result-content">
                        <div class="result-row">
                            <span class="result-label">Código Original:</span>
                            <span class="result-value">${escapeHtml(result.oem_number || result.original_query || '')}</span>
                        </div>
                        
                        <div class="result-row">
                            <span class="result-label">SKU ELIMFILTERS:</span>
                            <span class="result-value highlight">${escapeHtml(result.sku || 'N/A')}</span>
                        </div>
                        
                        ${result.family ? `
                        <div class="result-row">
                            <span class="result-label">Familia:</span>
                            <span class="result-value">${escapeHtml(result.family)}</span>
                        </div>
                        ` : ''}
                        
                        ${result.duty ? `
                        <div class="result-row">
                            <span class="result-label">Tipo:</span>
                            <span class="result-value">${escapeHtml(result.duty)}</span>
                        </div>
                        ` : ''}
                        
                        ${result.donaldson ? `
                        <div class="result-row">
                            <span class="result-label">Donaldson:</span>
                            <span class="result-value">${escapeHtml(result.donaldson)}</span>
                        </div>
                        ` : ''}
                        
                        ${result.fram ? `
                        <div class="result-row">
                            <span class="result-label">FRAM:</span>
                            <span class="result-value">${escapeHtml(result.fram)}</span>
                        </div>
                        ` : ''}
                        
                        ${result.notes ? `
                        <div class="result-row">
                            <span class="result-label">Notas:</span>
                            <span class="result-value">${escapeHtml(result.notes)}</span>
                        </div>
                        ` : ''}
                    </div>
                    
                    <div class="result-footer">
                        <span class="response-time">Tiempo de respuesta: ${responseTime}ms</span>
                        <button class="btn-new-search" onclick="location.reload()">Nueva Búsqueda</button>
                    </div>
                </div>
            `;
        } else {
            html = `
                <div class="elimfilters-no-results">
                    <div class="no-results-icon">🔍</div>
                    <h3>Sin Resultados</h3>
                    <p>No se encontró un equivalente para el código ingresado.</p>
                    <p>Por favor, verifique el código e intente nuevamente.</p>
                    <button class="btn-new-search" onclick="location.reload()">Nueva Búsqueda</button>
                </div>
            `;
        }
        
        resultsContainer.html(html).show();
    }

    // Mostrar/Ocultar loader inline en el formulario
    function showInlineLoading(show) {
        const inline = $('.elimfilters-inline-results');
        if (!inline.length) return;
        const loader = inline.find('.results-loading');
        const resultsContainer = $('#elimfilters-results-content');
        if (show) {
            loader.show();
            resultsContainer.hide();
        } else {
            loader.hide();
        }
    }
    
    /**
     * Funciones auxiliares
     */
    function showLoading(show) {
        if (show) {
            searchButton.addClass('loading');
            loadingSpinner.show();
            searchButton.find('.button-text').text('Buscando...');
        } else {
            searchButton.removeClass('loading');
            loadingSpinner.hide();
            searchButton.find('.button-text').text('Buscar');
        }
    }
    
    function showError(message) {
        errorContainer.html(`<p>${escapeHtml(message)}</p>`).show();
        setTimeout(hideError, 5000);
    }
    
    function hideError() {
        errorContainer.hide().empty();
    }
    
    function hideSuggestions() {
        suggestionsContainer.hide().empty();
    }
    
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    /**
     * Si estamos en la página de resultados, realizar búsqueda automática
     */
    const resultsContainer = $('.elimfilters-results-container');
    if (resultsContainer.length) {
        const query = resultsContainer.data('query');
        if (query) {
            performSearch(query);
        }
    }
});