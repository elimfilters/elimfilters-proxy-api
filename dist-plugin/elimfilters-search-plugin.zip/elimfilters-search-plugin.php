<?php
/**
 * Plugin Name: ELIMFILTERS Part Search Integration
 * Description: Integra la búsqueda de filtros con la API de ELIMFILTERS
 * Version: 1.0.0
 * Author: Tu Nombre
 * Text Domain: elimfilters-search
 */

// Evitar acceso directo
if (!defined('ABSPATH')) {
    exit;
}

// Definir constantes del plugin
define('ELIMFILTERS_API_URL', 'https://elimfilters-proxy-api-production.up.railway.app/api/detect-filter'); // URL de Railway (ajustada al dominio real del proyecto)
define('ELIMFILTERS_SEARCH_VERSION', '1.0.0');

/**
 * Clase principal del plugin
 */
class ELIMFILTERS_Search {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->init_hooks();
    }
    
    private function init_hooks() {
        // Registrar shortcodes
        add_shortcode('elimfilters_search_form', array($this, 'render_search_form'));
        add_shortcode('elimfilters_search_results', array($this, 'render_search_results'));
        
        // Registrar scripts y estilos
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Registrar AJAX handlers
        add_action('wp_ajax_elimfilters_search', array($this, 'handle_ajax_search'));
        add_action('wp_ajax_nopriv_elimfilters_search', array($this, 'handle_ajax_search'));
        
        // Crear página de resultados al activar
        register_activation_hook(__FILE__, array($this, 'create_result_page'));
    }
    
    /**
     * Encolar scripts y estilos
     */
    public function enqueue_scripts() {
        wp_enqueue_script(
            'elimfilters-search',
            plugins_url('assets/search.js', __FILE__),
            array('jquery'),
            ELIMFILTERS_SEARCH_VERSION,
            true
        );
        
        wp_enqueue_style(
            'elimfilters-search',
            plugins_url('assets/search.css', __FILE__),
            array(),
            ELIMFILTERS_SEARCH_VERSION
        );
        
        // Obtener URL de la página de resultados (si existe)
        $results_page_id = get_option('elimfilters_results_page_id', 0);
        $results_page_url = $results_page_id ? get_permalink($results_page_id) : '';

        // Pasar variables de PHP a JavaScript
        wp_localize_script('elimfilters-search', 'elimfilters_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('elimfilters_search_nonce'),
            'api_url' => ELIMFILTERS_API_URL,
            'results_page' => $results_page_url
        ));
    }
    
    /**
     * Renderizar formulario de búsqueda
     */
    public function render_search_form($atts = array()) {
        $atts = shortcode_atts(array(
            'placeholder' => 'Ingrese código OEM o Cross Reference...',
            'button_text' => 'Buscar',
            'show_loading' => 'true'
        ), $atts);
        
        ob_start();
        ?>
        <div class="elimfilters-search-container">
            <form id="elimfilters-search-form" class="elimfilters-search-form">
                <div class="search-input-wrapper">
                    <input 
                        type="text" 
                        id="elimfilters-search-input"
                        class="elimfilters-search-input"
                        placeholder="<?php echo esc_attr($atts['placeholder']); ?>"
                        required
                        autocomplete="off"
                    />
                    <button type="submit" class="elimfilters-search-button">
                        <span class="button-text"><?php echo esc_html($atts['button_text']); ?></span>
                        <?php if ($atts['show_loading'] === 'true'): ?>
                            <span class="loading-spinner" style="display: none;">
                                <svg class="spinner" width="16" height="16" viewBox="0 0 16 16">
                                    <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="1" fill="none" stroke-dasharray="20" stroke-dashoffset="20"/>
                                </svg>
                            </span>
                        <?php endif; ?>
                    </button>
                </div>
                <div id="elimfilters-search-suggestions" class="search-suggestions" style="display: none;"></div>
            </form>
            <div id="elimfilters-search-error" class="search-error" style="display: none;"></div>
        </div>
        <?php
        // Contenedor de resultados inline (fallback) para que no falle si no existe la página de resultados
        // Se mantiene oculto por defecto; el JS lo mostrará al recibir datos
        ?>
        <div class="elimfilters-inline-results">
            <div class="results-loading" style="display: none;">
                <div class="loading-spinner-large">
                    <svg class="spinner" width="32" height="32" viewBox="0 0 32 32">
                        <circle cx="16" cy="16" r="14" stroke="currentColor" stroke-width="2" fill="none" stroke-dasharray="40" stroke-dashoffset="40"/>
                    </svg>
                </div>
                <p>Buscando equivalente...</p>
            </div>
            <div id="elimfilters-results-content" class="results-content" style="display: none;"></div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Renderizar resultados de búsqueda
     */
    public function render_search_results($atts = array()) {
        // Obtener el parámetro de búsqueda de la URL
        $search_query = isset($_GET['part']) ? sanitize_text_field($_GET['part']) : '';
        
        if (empty($search_query)) {
            return '<div class="elimfilters-no-results">Por favor, realice una búsqueda.</div>';
        }
        
        ob_start();
        ?>
        <div class="elimfilters-results-container" data-query="<?php echo esc_attr($search_query); ?>">
            <div class="results-loading">
                <div class="loading-spinner-large">
                    <svg class="spinner" width="32" height="32" viewBox="0 0 32 32">
                        <circle cx="16" cy="16" r="14" stroke="currentColor" stroke-width="2" fill="none" stroke-dasharray="40" stroke-dashoffset="40"/>
                    </svg>
                </div>
                <p>Buscando equivalente para: <strong><?php echo esc_html($search_query); ?></strong></p>
            </div>
            <div id="elimfilters-results-content" class="results-content" style="display: none;"></div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Manejar búsqueda AJAX
     */
    public function handle_ajax_search() {
        // Verificar nonce para seguridad
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'elimfilters_search_nonce')) {
            wp_die('Security check failed');
        }
        
        $query = isset($_POST['query']) ? sanitize_text_field($_POST['query']) : '';
        // Validar longitud razonable del query
        $query = substr($query, 0, 128);
        
        if (empty($query)) {
            wp_send_json_error(array('message' => 'Por favor ingrese un código válido'));
        }
        
        // Llamar a la API externa
        $request_args = array(
            'method' => 'POST',
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => wp_json_encode(array('query' => $query)),
            'timeout' => 20
        );

        $response = wp_remote_post(ELIMFILTERS_API_URL, $request_args);
        
        // Reintento simple en caso de error de transporte o códigos 5xx
        if (is_wp_error($response) || (int) wp_remote_retrieve_response_code($response) >= 500) {
            // Esperar un breve instante antes de reintentar
            usleep(200000); // 200ms
            $response = wp_remote_post(ELIMFILTERS_API_URL, $request_args);
        }
        
        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'Error al conectar con el servicio'));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        if ($data === null) {
            $data = array('status' => 'ERROR', 'message' => 'Respuesta inválida del servicio');
        }
        
        if ($response_code !== 200) {
            wp_send_json_error(array(
                'message' => isset($data['message']) ? $data['message'] : 'Error en la búsqueda'
            ));
        }
        
        wp_send_json_success($data);
    }
    
    /**
     * Crear página de resultados al activar
     */
    public function create_result_page() {
        $page_title = 'Part Search Results';
        $page_slug = 'part-search';
        
        // Verificar si la página ya existe
        $page = get_page_by_path($page_slug);
        
        if (!$page) {
            $page_data = array(
                'post_title' => $page_title,
                'post_name' => $page_slug,
                'post_content' => '[elimfilters_search_results]',
                'post_status' => 'publish',
                'post_type' => 'page',
                'comment_status' => 'closed',
                'ping_status' => 'closed'
            );
            
            $page_id = wp_insert_post($page_data);
            
            if ($page_id) {
                update_option('elimfilters_results_page_id', $page_id);
            }
        }
    }
}

// Inicializar el plugin
ELIMFILTERS_Search::get_instance();