# Changelog

Todos los cambios notables en este proyecto serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/es/1.0.0/),
y este proyecto adhiere a [Semantic Versioning](https://semver.org/lang/es/).

## [3.0.0] - 2025-10-28

### 🎉 Nueva Versión Mayor - Reglas v2.2.0

#### ✅ Agregado
- Procesamiento 100% local sin dependencia de n8n
- Integración completa con Google Sheets con cache automático
- Suite completa de tests automatizados
- Script de migración v2.1.0 → v2.2.0
- Endpoint para recargar reglas sin reiniciar servidor
- Logging detallado para debugging
- Documentación completa en carpeta `/docs`
- Ejemplos visuales paso a paso
- Soporte para Railway deployment

#### 🔄 Cambiado
- **CRÍTICO**: Formato SKU de `PREFIX-NNNN` a `PREFIXNNNN` (sin guiones)
- Estructura de prefixes mejorada con mapping y aliases
- Search order con steps detallados para HD y LD
- Actualización a reglas oficiales v2.2.0 (2025-10-17)
- Mejora en la lógica de búsqueda de base code
- Validación completa de SKUs según 5 reglas

#### 🐛 Corregido
- Búsqueda de Donaldson ahora usa patrón regex correcto
- Búsqueda de FRAM ahora incluye todos los prefijos (PH, CA, CF, CH)
- Extracción de últimos 4 dígitos con padding correcto
- Validación de duty level en determinación de prefix

#### 🗑️ Removido
- Dependencia de n8n webhook (ahora procesamiento local)
- Guiones en formato SKU (v2.1.0)
- Código obsoleto de versiones anteriores

#### 📚 Documentación
- README.md completo con ejemplos
- Guía de migración v2.1.0 → v2.2.0
- Ejemplos visuales con 6 casos de uso
- Guía de implementación detallada
- Resumen ejecutivo con ventajas y costos

---

## [2.1.0] - 2025-10-23

### Versión Anterior (OBSOLETA)

#### Características
- Formato SKU: `PREFIX-NNNN` (con guiones)
- Dependencia de n8n para procesamiento
- Reglas básicas de generación

**Nota**: Esta versión está obsoleta. Usar v3.0.0 con reglas v2.2.0.

---

## Guía de Migración

### De v2.1.0 a v3.0.0

**Cambios Críticos:**
1. Formato SKU: `EL8-2100` → `EL82100` (remover guiones)
2. Reemplazar archivos: `businessLogic.js`, `server.js`, `config/REGLAS_MAESTRAS.json`
3. Ejecutar script de migración para datos existentes

**Ver:** [docs/CAMBIOS_v2.1_a_v2.2.md](docs/CAMBIOS_v2.1_a_v2.2.md)

---

## Tipos de Cambios

- `✅ Agregado` - para funcionalidades nuevas
- `🔄 Cambiado` - para cambios en funcionalidades existentes
- `🗑️ Removido` - para funcionalidades removidas
- `🐛 Corregido` - para corrección de bugs
- `🔒 Seguridad` - para vulnerabilidades
- `📚 Documentación` - para cambios en documentación

---

[3.0.0]: https://github.com/elimfilters/api/releases/tag/v3.0.0
[2.1.0]: https://github.com/elimfilters/api/releases/tag/v2.1.0
