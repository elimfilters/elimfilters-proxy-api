# 🚀 ELIMFILTERS API v3.0 - Local Processing

> API de procesamiento local para SKUs de filtros según reglas ELIMFILTERS v2.2.0

[![Version](https://img.shields.io/badge/version-3.0.0-blue.svg)](https://github.com/elimfilters/api)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D16.0.0-brightgreen.svg)](https://nodejs.org)

## 📋 Descripción

API REST para generar SKUs de filtros según las reglas oficiales ELIMFILTERS v2.2.0, con procesamiento 100% local sin dependencias externas como n8n.

### ✨ Características

- ✅ **Procesamiento Local**: Sin dependencia de servicios externos
- ✅ **Reglas v2.2.0**: Formato SKU `PREFIXNNNN` (sin guiones)
- ✅ **5 Reglas Implementadas**: Determinación de prefix, base code HD/LD, generación y validación
- ✅ **Integración Google Sheets**: Búsqueda con cache automático
- ✅ **Railway Ready**: Configuración lista para Railway
- ✅ **Tests Incluidos**: Suite completa de validación
- ✅ **Versionado en Git**: Reglas actualizables vía commits

### 🎯 Formato SKU v2.2.0

```
Formato: PREFIXNNNN (sin guiones)
Ejemplo: EL82100

Antes (v2.1.0): EL8-2100
Ahora (v2.2.0): EL82100 ✅
```

---

## 🚀 Inicio Rápido

### Instalación

```bash
# Clonar repositorio
git clone https://github.com/TU-USUARIO/elimfilters-api.git
cd elimfilters-api

# Instalar dependencias
npm install

# Configurar variables de entorno
cp .env.example .env
# Editar .env con tus credenciales

# Iniciar servidor
npm start
```

### Uso Básico

```bash
# Buscar filtro por código
curl -X POST http://localhost:3000/api/v1/filters/lookup \
  -H "Content-Type: application/json" \
  -d '{"code": "P552100"}'

# Respuesta esperada
{
  "success": true,
  "filter": {
    "sku": "EL82100",
    "family": "OIL",
    "duty_level": "HD",
    "specs": "Oil Filter HD"
  },
  "sku_info": {
    "was_generated": true,
    "base_code_used": "P552100",
    "prefix_used": "EL8",
    "last_4_digits": "2100"
  }
}
```

---

## 📁 Estructura del Proyecto

```
elimfilters-api/
├── server.js                      # Servidor Express principal
├── businessLogic.js               # Lógica de reglas v2.2.0
├── googleSheetsIntegration.js     # Integración Google Sheets
├── test.js                        # Suite de tests
├── migration-v2.1-to-v2.2.js     # Script de migración
├── package.json                   # Dependencias
├── .env.example                   # Template de variables
├── config/
│   └── REGLAS_MAESTRAS.json      # Reglas oficiales v2.2.0
└── docs/
    ├── CAMBIOS_v2.1_a_v2.2.md    # Guía de migración
    ├── EJEMPLOS_VISUALES_v2.2.0.md
    ├── GUIA_IMPLEMENTACION_LOCAL.md
    └── RESUMEN_EJECUTIVO.md
```

---

## 🎯 Reglas de Generación SKU v2.2.0

### Regla 1: Determinación de Prefix
```
TIPO + DUTY → PREFIX

Ejemplos:
- OIL + HD → EL8
- FUEL + LD → EF9
- AIRE + HD → EA1
```

### Regla 2: Base Code para HD (Heavy Duty)
```
1. Buscar DONALDSON (P\d{5,6}) en cross_reference
2. Si no encontrado → usar primer cross_reference (OEM más comercial)
3. Extraer números → tomar últimos 4 dígitos

Ejemplo: P552100 → 552100 → 2100
```

### Regla 3: Base Code para LD (Light Duty)
```
1. Buscar FRAM ((PH|CA|CF|CH)\d{3,6}) en cross_reference
2. Si no encontrado → usar primer cross_reference (OEM más comercial)
3. Extraer números → tomar últimos 4 dígitos

Ejemplo: CA10234 → 10234 → 0234
```

### Regla 4: Generación SKU
```
PREFIX + BASECODE = SKU (sin guiones)

Ejemplo: EL8 + 2100 = EL82100
```

### Regla 5: Validación
- ✅ Prefix debe estar en lista válida
- ✅ BaseCode debe ser 4 dígitos numéricos
- ✅ SKU formato: PREFIXNNNN
- ✅ Duty: HD o LD

Ver [documentación completa](docs/EJEMPLOS_VISUALES_v2.2.0.md) para más ejemplos.

---

## 🔧 Configuración

### Variables de Entorno

```env
# Servidor
PORT=3000
NODE_ENV=production

# Google Sheets
GOOGLE_SHEETS_ID=tu_spreadsheet_id_aqui
GOOGLE_CREDENTIALS={"type":"service_account",...}

# Base de Datos (alternativa a Google Sheets)
DATABASE_URL=postgresql://user:password@host:5432/database
```

### Railway Deployment

1. Conectar repositorio en Railway
2. Configurar variables de entorno en dashboard
3. Railway detecta automáticamente y despliega

```bash
git push origin main
# Railway despliega automáticamente ✅
```

---

## 🧪 Testing

```bash
# Ejecutar todos los tests
npm test

# Tests incluidos:
✅ Health check
✅ Lookup endpoint
✅ Search endpoint
✅ Invalid code handling
✅ Rate limiting
✅ Response time
```

---

## 📡 API Endpoints

### Health Check
```http
GET /health

Response:
{
  "status": "ok",
  "service": "ELIMFILTERS Local API",
  "version": "3.0.0-v2.2.0",
  "rules_version": "2.2.0",
  "sku_format": "PREFIXNNNN (sin guiones)"
}
```

### Lookup (POST)
```http
POST /api/v1/filters/lookup
Content-Type: application/json

{
  "code": "P552100"
}
```

### Search (GET)
```http
GET /api/v1/filters/search?code=P552100
```

### Reload Rules
```http
POST /api/v1/admin/reload-rules

Response:
{
  "success": true,
  "message": "Reglas recargadas exitosamente",
  "version": "2.2.0"
}
```

---

## 🔄 Migración desde v2.1.0

Si tienes SKUs con el formato antiguo (`EL8-2100`):

```bash
# Ejecutar script de migración
node migration-v2.1-to-v2.2.js

# Genera:
# - migration.sql (para bases de datos)
# - migration-google-sheets.js (para Google Sheets)
```

Ver [guía de migración completa](docs/CAMBIOS_v2.1_a_v2.2.md).

---

## 📊 Ventajas vs n8n

| Aspecto | Con n8n | Sin n8n (Local) |
|---------|---------|-----------------|
| ⚡ Velocidad | 300-500ms | **50-100ms** |
| 💰 Costo/mes | $25-35 | **$5-10** |
| 🔧 Mantenimiento | 2 servicios | **1 servicio** |
| 📝 Versionado | Manual | **Git automático** |
| 🐛 Debug | Difícil | **Fácil** |

---

## 📚 Documentación

- [📝 Cambios v2.1.0 → v2.2.0](docs/CAMBIOS_v2.1_a_v2.2.md)
- [📊 Ejemplos Visuales](docs/EJEMPLOS_VISUALES_v2.2.0.md)
- [🔧 Guía de Implementación](docs/GUIA_IMPLEMENTACION_LOCAL.md)
- [📈 Resumen Ejecutivo](docs/RESUMEN_EJECUTIVO.md)

---

## 🤝 Contribuir

1. Fork el proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

---

## 📝 Changelog

### v3.0.0-v2.2.0 (2025-10-28)
- ✅ Actualización a reglas v2.2.0
- ✅ Formato SKU sin guiones (PREFIXNNNN)
- ✅ Procesamiento 100% local (sin n8n)
- ✅ Integración Google Sheets con cache
- ✅ Suite completa de tests
- ✅ Script de migración v2.1.0 → v2.2.0

### v2.1.0 (2025-10-23)
- Versión anterior (OBSOLETA)

---

## 📄 Licencia

Este proyecto está bajo la Licencia MIT - ver el archivo [LICENSE](LICENSE) para detalles.

---

## 👥 Equipo

**ELIMFILTERS Team**

- 📧 Email: contacto@elimfilters.com
- 🌐 Web: https://elimfilters.com

---

## 🙏 Agradecimientos

- Anthropic Claude por la asistencia en desarrollo
- Railway por el hosting
- Google Sheets API

---

## ⚠️ Notas Importantes

- **Formato SKU**: v2.2.0 usa `PREFIXNNNN` (sin guiones)
- **Base de Datos**: Requiere conexión a Google Sheets o base de datos
- **Variables de Entorno**: Configurar antes de desplegar
- **Testing**: Probar localmente antes de producción

---

**¿Preguntas?** Revisa la [documentación completa](docs/) o abre un [issue](https://github.com/TU-USUARIO/elimfilters-api/issues).

**¡Listo para producción! 🚀**
