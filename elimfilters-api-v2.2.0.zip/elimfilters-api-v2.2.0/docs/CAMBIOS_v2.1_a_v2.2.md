# 🔄 ACTUALIZACIÓN: Reglas v2.1.0 → v2.2.0

## 📌 Resumen de Cambios

Las reglas han sido actualizadas de la versión **2.1.0** a la **2.2.0** con cambios **CRÍTICOS** en el formato del SKU y la estructura de las reglas.

---

## ⚠️ CAMBIOS CRÍTICOS

### 1. **Formato del SKU** (MÁS IMPORTANTE)

| Versión | Formato | Ejemplo |
|---------|---------|---------|
| **v2.1.0** | `PREFIX-NNNN` (con guión) | `EL8-2100` |
| **v2.2.0** | `PREFIXNNNN` (sin guión) | `EL82100` |

**IMPACTO:** Todos los SKUs generados ahora son sin guiones.

```javascript
// ANTES (v2.1.0)
const sku = `${prefix}-${last4}`;  // EL8-2100

// AHORA (v2.2.0)
const sku = `${prefix}${last4}`;   // EL82100
```

---

### 2. **Estructura de Prefixes**

#### ANTES (v2.1.0):
```json
"prefixes": {
  "ACEITE": "EL8",
  "OIL": "EL8",
  "COMBUSTIBLE": "EF9"
}
```

#### AHORA (v2.2.0):
```json
"prefixes": {
  "mapping": {
    "AIRE": {
      "prefix": "EA1",
      "duty": ["HD", "LD"],
      "aliases": ["AIR"]
    },
    "FUEL": {
      "prefix": "EF9",
      "duty": ["HD", "LD"],
      "aliases": ["COMBUSTIBLE"]
    }
  }
}
```

**VENTAJAS:**
- ✅ Validación de duty compatible
- ✅ Aliases múltiples
- ✅ Más flexible y estructurado

---

### 3. **Search Order**

#### ANTES (v2.1.0):
```json
"search_order": [
  {
    "duty": "HD",
    "priority": "HD_PRIMARY",
    "order": [...]
  }
]
```

#### AHORA (v2.2.0):
```json
"search_order": {
  "HD": {
    "description": "Heavy Duty - Buscar DONALDSON primero",
    "steps": [
      {
        "step": 1,
        "source": "cross_reference",
        "target": "donaldson",
        "pattern": "P\\d{5,6}",
        "priority": 1,
        "description": "Buscar código Donaldson en cross references"
      }
    ]
  }
}
```

**VENTAJAS:**
- ✅ Steps más claros y secuenciales
- ✅ Patrones específicos por step
- ✅ Descripciones detalladas

---

### 4. **Reglas Documentadas**

La v2.2.0 incluye documentación completa de las 5 reglas principales:

```json
"rules": {
  "regla_1_determinacion_prefijo": {...},
  "regla_2_busqueda_base_code_HD": {...},
  "regla_3_busqueda_base_code_LD": {...},
  "regla_4_generacion_sku_final": {...},
  "regla_5_validacion_integridad": {...}
}
```

Cada regla incluye:
- ✅ Descripción detallada
- ✅ Steps a seguir
- ✅ Ejemplos prácticos
- ✅ Casos de uso

---

## 📊 Comparación de Ejemplos

### Ejemplo 1: Oil Filter HD con Donaldson

**Datos de entrada:**
```json
{
  "family": "OIL",
  "duty_level": "HD",
  "crossReference": ["P552100", "LF3620"],
  "oemCodes": ["51515"]
}
```

**Resultados:**

| Versión | Base Code | Prefix | Últimos 4 | SKU |
|---------|-----------|--------|-----------|-----|
| v2.1.0 | P552100 | EL8 | 2100 | `EL8-2100` |
| v2.2.0 | P552100 | EL8 | 2100 | `EL82100` |

### Ejemplo 2: Fuel Filter LD sin FRAM

**Datos de entrada:**
```json
{
  "family": "FUEL",
  "duty_level": "LD",
  "crossReference": ["88922", "LF3000"],
  "oemCodes": ["12345"]
}
```

**Resultados:**

| Versión | Base Code | Prefix | Últimos 4 | SKU |
|---------|-----------|--------|-----------|-----|
| v2.1.0 | 88922 | EF9 | 8922 | `EF9-8922` |
| v2.2.0 | 88922 | EF9 | 8922 | `EF98922` |

---

## 🔧 Cambios en el Código

### businessLogic.js

#### Función `generateSKU()` - ACTUALIZADA

```javascript
// ANTES (v2.1.0)
function generateSKU(prefix, last4) {
  return `${prefix}-${last4}`;  // Con guión
}

// AHORA (v2.2.0)
function generateSKU(prefix, last4) {
  return `${prefix}${last4}`;   // Sin guión
}
```

#### Función `getElimfiltersPrefix()` - MEJORADA

```javascript
// ANTES (v2.1.0)
function getElimfiltersPrefix(family, duty) {
  const prefixMap = {
    'AIRE': 'EA1',
    'AIR': 'EA1'
  };
  return prefixMap[family] || 'ELM';
}

// AHORA (v2.2.0)
function getElimfiltersPrefix(family, duty, prefixesMapping) {
  // Buscar en mapping estructurado
  if (prefixesMapping && prefixesMapping.mapping) {
    const prefixData = prefixesMapping.mapping[family];
    if (prefixData && prefixData.duty.includes(duty)) {
      return prefixData.prefix;
    }
    // Buscar en aliases
    for (const [tipo, data] of Object.entries(prefixesMapping.mapping)) {
      if (data.aliases.includes(family) && data.duty.includes(duty)) {
        return data.prefix;
      }
    }
  }
  return 'ELM';
}
```

---

## 📝 Archivos Actualizados

Los siguientes archivos han sido actualizados para v2.2.0:

1. **`businessLogic-v2.2.js`** ✅
   - Formato SKU sin guiones
   - Lógica de prefixes mejorada
   - Función `generateSKU()` actualizada
   - Validación mejorada

2. **`server-v2.2.js`** ✅
   - Usa businessLogic v2.2
   - Carga REGLAS_MAESTRAS v2.2.0
   - Logging detallado
   - Ejemplos de mock data actualizados

3. **`config/REGLAS_MAESTRAS_v2.2.0.json`** ✅
   - Estructura completa de reglas v2.2.0
   - Prefixes con mapping
   - Search order con steps
   - Documentación de reglas

---

## ✅ Checklist de Migración

Si tienes código usando v2.1.0, debes actualizar:

- [ ] Cambiar formato SKU: `PREFIX-NNNN` → `PREFIXNNNN`
- [ ] Actualizar función `generateSKU()` (remover guión)
- [ ] Actualizar función `getElimfiltersPrefix()` (usar nuevo mapping)
- [ ] Reemplazar `REGLAS_MAESTRAS.json` con v2.2.0
- [ ] Actualizar `businessLogic.js` con versión v2.2
- [ ] Actualizar `server.js` con versión v2.2
- [ ] Probar todos los casos de uso
- [ ] Actualizar base de datos si ya tiene SKUs con guiones

---

## 🧪 Tests de Validación

### Test 1: Formato SKU
```javascript
const sku = generateSKU('EL8', '2100');
console.assert(sku === 'EL82100', 'SKU debe ser sin guiones');
console.assert(!sku.includes('-'), 'SKU no debe contener guiones');
```

### Test 2: Prefix con Mapping
```javascript
const prefix = getElimfiltersPrefix('OIL', 'HD', REGLAS_MAESTRAS.prefixes);
console.assert(prefix === 'EL8', 'Prefix debe ser EL8');
```

### Test 3: Alias Support
```javascript
const prefix = getElimfiltersPrefix('ACEITE', 'LD', REGLAS_MAESTRAS.prefixes);
console.assert(prefix === 'EL8', 'Alias ACEITE debe resolver a EL8');
```

---

## 🚨 Compatibilidad Hacia Atrás

**NO HAY** compatibilidad automática entre v2.1.0 y v2.2.0 debido al cambio de formato del SKU.

Si tienes SKUs existentes con guiones (`EL8-2100`), deberás:

1. **Opción A**: Migrar todos los SKUs quitando guiones
   ```sql
   UPDATE filters 
   SET sku = REPLACE(sku, '-', '') 
   WHERE sku LIKE '%-%';
   ```

2. **Opción B**: Mantener ambos formatos temporalmente
   ```javascript
   // Normalizar SKU al buscar
   const normalizedSKU = sku.replace('-', '');
   ```

3. **Opción C**: Generar nuevo campo `sku_v2`
   ```javascript
   // Mantener sku original y crear sku_v2
   filterData.sku_legacy = filterData.sku;  // EL8-2100
   filterData.sku = generateSKU(...);       // EL82100
   ```

---

## 📚 Recursos

- **Reglas completas**: `config/REGLAS_MAESTRAS_v2.2.0.json`
- **Código actualizado**: `businessLogic-v2.2.js`
- **Servidor actualizado**: `server-v2.2.js`
- **Documentación**: Este archivo

---

## 🎯 Próximos Pasos

1. **Revisar** todos los cambios en este documento
2. **Actualizar** tu código con los archivos v2.2
3. **Probar** con los ejemplos proporcionados
4. **Migrar** base de datos si es necesario
5. **Desplegar** a Railway

---

## ❓ FAQ

**¿Por qué cambió el formato del SKU?**
→ Para simplificar y estandarizar. El guión no aporta valor y complica búsquedas.

**¿Puedo seguir usando v2.1.0?**
→ No recomendado. v2.2.0 tiene mejor estructura y documentación.

**¿Qué hago con los SKUs existentes con guiones?**
→ Ver sección "Compatibilidad Hacia Atrás" arriba.

**¿Los prefixes cambiaron?**
→ No, los prefixes son los mismos (EL8, EF9, EA1, etc). Solo cambió la estructura del mapping.

**¿La lógica de búsqueda HD/LD cambió?**
→ No, sigue siendo: HD busca Donaldson primero, LD busca FRAM primero.

---

## 📧 Soporte

Si tienes dudas sobre la migración, revisa:
1. Este documento de cambios
2. Los archivos de código actualizados (tienen comentarios)
3. El archivo `REGLAS_MAESTRAS_v2.2.0.json` (muy documentado)

---

**Última actualización:** 2025-10-28
**Versión del documento:** 1.0
**Autor:** ELIMFILTERS Team
