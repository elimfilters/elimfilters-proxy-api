// filterProcessor.js — v3.0.1
const { normalizeQuery, isStrictElimSku } = require('./utils');
const dataAccess = require('./dataAccess');
const businessLogic = require('./businessLogic');
const jsonBuilder = require('./jsonBuilder');
const { generateSkuFrom, loadRules } = require('./homologationDB');

function nowISO() { return new Date().toISOString(); }

function detectCodeType(code) {
  const c = String(code || '').toUpperCase();
  if (isStrictElimSku(c)) return 'SKU';
  if (/^[0-9]{5,}$/.test(c)) return 'OEM';
  return 'XREF';
}

async function processFilterCode(rawQuery, opts = {}) {
  const q = normalizeQuery(String(rawQuery || '').trim());
  if (!q) return jsonBuilder.buildError('EMPTY_QUERY', 'La consulta está vacía');

  const codeType = detectCodeType(q);

  const found = await dataAccess.findByCodeOrCrossRef(q, opts);
  if (found && found.length > 0) {
    const enriched = businessLogic.enrich(found, { query: q, codeType });
    return jsonBuilder.buildSuccess({
      query: q, codeType, items: enriched.items, summary: enriched.summary,
    });
  }

  if (codeType === 'SKU') {
    return jsonBuilder.buildNotFound(q);
  }

  const reqBody = opts.reqBody || {};
  const family = reqBody.family;
  const duty   = reqBody.duty;

  if (!family || !duty) {
    return jsonBuilder.buildError('MISSING_FAMILY_DUTY', 'Para crear OEM/XREF debes enviar { family, duty } (ej. {"family":"AIRE","duty":"LD"}).');
  }

  const rules = loadRules();
  const dt = rules.decisionTable || {};
  const key = `${String(family).toUpperCase()}|${String(duty).toUpperCase()}`;
  const prefix = dt[key];

  if (!prefix) {
    return jsonBuilder.buildError('DECISION_KEY_NOT_FOUND', `No existe mapeo en decisionTable para "${key}".`);
  }

  let newSKU;
  try {
    newSKU = generateSkuFrom(q, { type: codeType, family, duty });
    console.log('[SKU RULES] key=%s -> prefix=%s | query=%s | SKU=%s', key, prefix, q, newSKU);
  } catch (e) {
    console.error('[SKU RULES][ERROR] %s', e?.message || e);
    return jsonBuilder.buildError('SKU_RULES_FAILED', 'Error generando el SKU con las reglas.');
  }

  const { headers } = await dataAccess.getTable(opts);
  const H = headers.map(h => String(h).trim().toUpperCase());

  const row = headers.map((h, idx) => {
    const HU = H[idx];
    if (HU === 'SKU' || HU === 'CODIGO' || HU === 'CODE') return newSKU;
    if (HU === 'OEM' || HU === 'CODIGO OEM') return (codeType === 'OEM') ? q : '';
    if (HU === 'CROSSREF' || HU === 'CROSS REF' || HU === 'EQUIVALENCIA' || HU === 'EQUIVALENTE') {
      return (codeType === 'XREF') ? q : '';
    }
    if (HU === 'FAMILY' || HU === 'FAMILIA') return family || '';
    if (HU === 'DUTY') return duty || '';
    if (HU === 'STATUS' || HU === 'ESTADO') return 'NEW';
    if (HU === 'CREATED_AT' || HU === 'FECHA') return nowISO();
    if (HU === 'SOURCE' || HU === 'ORIGEN') return 'API';
    return '';
  });

  try {
    await dataAccess.appendRow(row, opts);

    const item = {
      SKU: newSKU,
      OEM: codeType === 'OEM' ? q : '',
      CrossRef: codeType === 'XREF' ? q : '',
      FAMILY: family || '',
      DUTY: duty || '',
      STATUS: 'NEW',
      CREATED_AT: nowISO(),
      SOURCE: 'API',
    };

    return jsonBuilder.buildSuccess({
      created: true, query: q, codeType, items: [item], summary: { count: 1, created: 1 },
    });
  } catch (e) {
    console.error('[SHEETS][APPEND][ERROR] %s', e?.message || e);

    const item = {
      SKU: newSKU,
      OEM: codeType === 'OEM' ? q : '',
      CrossRef: codeType === 'XREF' ? q : '',
      FAMILY: family || '',
      DUTY: duty || '',
      STATUS: 'PENDING_WRITE',
      CREATED_AT: nowISO(),
      SOURCE: 'API',
    };

    return {
      ok: true, created: false, warning: 'WRITE_FAILED',
      query: q, codeType, items: [item], summary: { count: 1, created: 0 },
    };
  }
}

module.exports = { processFilterCode, detectCodeType };
