# ELIMFILTERS Proxy — Respaldo 3.0.1
Fecha: 2025-10-31T04:33:52.030985

Archivos incluidos (blindados):
- utils.js — Validación SKU estricta (prefijos oficiales + 4 dígitos).
- filterProcessor.js — OEM/XREF crean; SKU solo si existe; decisionTable obligatoria.
- homologationDB.js — Generación de SKU por decisionTable y core numérico de 4 dígitos.

Instalación:
1) Reemplace estos tres archivos en la raíz del proyecto.
2) Asegure el archivo de reglas: "REGLAS MAESTRAS" (raíz) o config/REGLAS_MAESTRAS.json.
3) Redeploy en Railway.

Smoke tests:
- 1R1808 + OIL/HD → EL81808
- CA10234 + AIRE/LD → EA10234
- 1000FH + TURBINE/HD → ET91000
- P551313 + FUEL SEPARATOR/HD → ES91313
- P527484 + AIRE/LD → EA17484

SKU estricto: Prefijo oficial + 4 dígitos. Si no existe en hoja ⇒ NOT_FOUND.
