// utils.js — Validación estricta de SKU ELIMFILTERS (prefijo válido + 4 dígitos)
const { loadRules } = require('./homologationDB');

function normalizeQuery(s) {
  return String(s || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
}

function getValidPrefixes() {
  const rules = loadRules();
  if (Array.isArray(rules.allPrefixes) && rules.allPrefixes.length) {
    return rules.allPrefixes.map(p => String(p).toUpperCase());
  }
  const dt = rules.decisionTable || {};
  const set = new Set(Object.values(dt).map(v => String(v).toUpperCase()));
  return Array.from(set);
}

function isStrictElimSku(code) {
  const c = normalizeQuery(code);
  const prefixes = getValidPrefixes();
  if (!prefixes.length) return false;
  const alt = prefixes.map(p => p.replace(/[-/\^$*+?.()|[\]{}]/g, '\$&')).join('|');
  const re = new RegExp(`^(?:${alt})\d{4}$`, 'i');
  return re.test(c);
}

function isValidCode(code) {
  return isStrictElimSku(code);
}

module.exports = { normalizeQuery, getValidPrefixes, isStrictElimSku, isValidCode };
