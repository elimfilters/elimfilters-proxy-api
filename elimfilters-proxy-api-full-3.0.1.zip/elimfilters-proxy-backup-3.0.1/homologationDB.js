/**
 * homologationDB.js
 * Reglas de SKU: PREFIJO + CORE_NUMÉRICO_4
 */
const fs = require('fs');
const path = require('path');

const clean = (s) => String(s ?? '').toUpperCase().replace(/[^0-9A-Z]/g, '');

function coreNumeric4(src) {
  const c = clean(src);
  let m = c.match(/(\d+)[A-Z]+$/);
  if (m && m[1]) return m[1].slice(-4).padStart(4, '0');
  m = c.match(/(\d+)$/);
  if (m && m[1]) return m[1].slice(-4).padStart(4, '0');
  return '0000';
}

let RULES_CACHE = null;
function loadRules() {
  if (RULES_CACHE) return RULES_CACHE;
  const candidates = [
    path.join(__dirname, 'REGLAS MAESTRAS'),
    path.join(__dirname, 'config', 'REGLAS_MAESTRAS.json'),
  ];
  for (const p of candidates) {
    if (fs.existsSync(p)) {
      const raw = fs.readFileSync(p, 'utf8');
      RULES_CACHE = JSON.parse(raw);
      return RULES_CACHE;
    }
  }
  throw new Error('REGLAS MAESTRAS no encontrado');
}

function prefixOf(family, duty) {
  const rules = loadRules();
  const dt = rules?.decisionTable || {};
  const key = `${String(family || '').toUpperCase()}|${String(duty || '').toUpperCase()}`;
  return dt[key] || null;
}

function generateSkuFrom(sourceCode, ctx = {}) {
  const core = coreNumeric4(sourceCode);
  const px = prefixOf(ctx.family, ctx.duty);
  const fallback = ctx.type === 'OEM' ? 'EO' : 'EX';
  return `${px || fallback}${core}`;
}

module.exports = {
  generateSkuFrom,
  loadRules,
  _internals: { clean, coreNumeric4, prefixOf },
};
