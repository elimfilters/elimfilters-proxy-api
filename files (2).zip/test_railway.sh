#!/bin/bash

# ═══════════════════════════════════════════════════════════════
# RAILWAY API - TEST SUITE v2.4.0
# ═══════════════════════════════════════════════════════════════

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# URL de Railway
RAILWAY_URL="https://elimfilters-proxy-api-production.up.railway.app"

echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  RAILWAY API TEST SUITE v2.4.0${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
echo ""
echo "Testing: $RAILWAY_URL"
echo ""

# Contador de tests
PASSED=0
FAILED=0

# ═══════════════════════════════════════════════════════════════
# TEST 1: Health Check
# ═══════════════════════════════════════════════════════════════
echo -e "${YELLOW}Test 1: Health Check${NC}"
RESPONSE=$(curl -s "$RAILWAY_URL/health")
if echo "$RESPONSE" | grep -q '"status":"ok"'; then
  if echo "$RESPONSE" | grep -q '"version":"2.4.0"'; then
    echo -e "${GREEN}✅ PASSED${NC} - Health check OK, version 2.4.0"
    ((PASSED++))
  else
    echo -e "${RED}❌ FAILED${NC} - Wrong version"
    echo "$RESPONSE"
    ((FAILED++))
  fi
else
  echo -e "${RED}❌ FAILED${NC} - Health check failed"
  echo "$RESPONSE"
  ((FAILED++))
fi
echo ""

# ═══════════════════════════════════════════════════════════════
# TEST 2: Código muy corto (INVALID_LENGTH)
# ═══════════════════════════════════════════════════════════════
echo -e "${YELLOW}Test 2: Validación - Código muy corto${NC}"
RESPONSE=$(curl -s -X POST "$RAILWAY_URL/api/v1/filters/search" \
  -H "Content-Type: application/json" \
  -d '{"code":"AB"}')
if echo "$RESPONSE" | grep -q '"error_code":"INVALID_LENGTH"'; then
  echo -e "${GREEN}✅ PASSED${NC} - Detected INVALID_LENGTH"
  ((PASSED++))
else
  echo -e "${RED}❌ FAILED${NC} - Should detect INVALID_LENGTH"
  echo "$RESPONSE"
  ((FAILED++))
fi
echo ""

# ═══════════════════════════════════════════════════════════════
# TEST 3: Caracteres inválidos (INVALID_CHARS)
# ═══════════════════════════════════════════════════════════════
echo -e "${YELLOW}Test 3: Validación - Caracteres inválidos${NC}"
RESPONSE=$(curl -s -X POST "$RAILWAY_URL/api/v1/filters/search" \
  -H "Content-Type: application/json" \
  -d '{"code":"ABC@#$"}')
if echo "$RESPONSE" | grep -q '"error_code":"INVALID_CHARS"'; then
  echo -e "${GREEN}✅ PASSED${NC} - Detected INVALID_CHARS"
  ((PASSED++))
else
  echo -e "${RED}❌ FAILED${NC} - Should detect INVALID_CHARS"
  echo "$RESPONSE"
  ((FAILED++))
fi
echo ""

# ═══════════════════════════════════════════════════════════════
# TEST 4: Código faltante (MISSING_CODE)
# ═══════════════════════════════════════════════════════════════
echo -e "${YELLOW}Test 4: Validación - Código faltante${NC}"
RESPONSE=$(curl -s -X POST "$RAILWAY_URL/api/v1/filters/search" \
  -H "Content-Type: application/json" \
  -d '{}')
if echo "$RESPONSE" | grep -q '"error_code":"MISSING_CODE"'; then
  echo -e "${GREEN}✅ PASSED${NC} - Detected MISSING_CODE"
  ((PASSED++))
else
  echo -e "${RED}❌ FAILED${NC} - Should detect MISSING_CODE"
  echo "$RESPONSE"
  ((FAILED++))
fi
echo ""

# ═══════════════════════════════════════════════════════════════
# TEST 5: Código válido (debe aceptar)
# ═══════════════════════════════════════════════════════════════
echo -e "${YELLOW}Test 5: Código válido${NC}"
RESPONSE=$(curl -s -X POST "$RAILWAY_URL/api/v1/filters/search" \
  -H "Content-Type: application/json" \
  -d '{"code":"1R1808"}')
if echo "$RESPONSE" | grep -q '"success":true'; then
  echo -e "${GREEN}✅ PASSED${NC} - Valid code accepted"
  ((PASSED++))
else
  echo -e "${RED}❌ FAILED${NC} - Should accept valid code"
  echo "$RESPONSE"
  ((FAILED++))
fi
echo ""

# ═══════════════════════════════════════════════════════════════
# TEST 6: Endpoint de test
# ═══════════════════════════════════════════════════════════════
echo -e "${YELLOW}Test 6: Endpoint de test${NC}"
RESPONSE=$(curl -s -X POST "$RAILWAY_URL/api/v1/test/validate" \
  -H "Content-Type: application/json" \
  -d '{"code":"P551808"}')
if echo "$RESPONSE" | grep -q '"normalized":"P551808"'; then
  echo -e "${GREEN}✅ PASSED${NC} - Test endpoint functional"
  ((PASSED++))
else
  echo -e "${RED}❌ FAILED${NC} - Test endpoint not working"
  echo "$RESPONSE"
  ((FAILED++))
fi
echo ""

# ═══════════════════════════════════════════════════════════════
# TEST 7: Normalización de código (lowercase → uppercase)
# ═══════════════════════════════════════════════════════════════
echo -e "${YELLOW}Test 7: Normalización de código${NC}"
RESPONSE=$(curl -s -X POST "$RAILWAY_URL/api/v1/test/validate" \
  -H "Content-Type: application/json" \
  -d '{"code":"p551808"}')
if echo "$RESPONSE" | grep -q '"normalized":"P551808"'; then
  echo -e "${GREEN}✅ PASSED${NC} - Code normalized to uppercase"
  ((PASSED++))
else
  echo -e "${RED}❌ FAILED${NC} - Code should be normalized"
  echo "$RESPONSE"
  ((FAILED++))
fi
echo ""

# ═══════════════════════════════════════════════════════════════
# TEST 8: Ruta no encontrada (404)
# ═══════════════════════════════════════════════════════════════
echo -e "${YELLOW}Test 8: Ruta no encontrada${NC}"
RESPONSE=$(curl -s "$RAILWAY_URL/ruta-inexistente")
if echo "$RESPONSE" | grep -q '"error_code":"ROUTE_NOT_FOUND"'; then
  echo -e "${GREEN}✅ PASSED${NC} - 404 handler working"
  ((PASSED++))
else
  echo -e "${RED}❌ FAILED${NC} - 404 should return ROUTE_NOT_FOUND"
  echo "$RESPONSE"
  ((FAILED++))
fi
echo ""

# ═══════════════════════════════════════════════════════════════
# TEST 9: Chat endpoint
# ═══════════════════════════════════════════════════════════════
echo -e "${YELLOW}Test 9: Chat endpoint${NC}"
RESPONSE=$(curl -s -X POST "$RAILWAY_URL/chat" \
  -H "Content-Type: application/json" \
  -d '{"message":"test"}')
if echo "$RESPONSE" | grep -q '"success":true'; then
  echo -e "${GREEN}✅ PASSED${NC} - Chat endpoint functional"
  ((PASSED++))
else
  echo -e "${RED}❌ FAILED${NC} - Chat endpoint not working"
  echo "$RESPONSE"
  ((FAILED++))
fi
echo ""

# ═══════════════════════════════════════════════════════════════
# TEST 10: Caracteres permitidos (guiones y puntos)
# ═══════════════════════════════════════════════════════════════
echo -e "${YELLOW}Test 10: Caracteres especiales permitidos${NC}"
RESPONSE=$(curl -s -X POST "$RAILWAY_URL/api/v1/test/validate" \
  -H "Content-Type: application/json" \
  -d '{"code":"ABC-123_456.789"}')
if echo "$RESPONSE" | grep -q '"success":true'; then
  echo -e "${GREEN}✅ PASSED${NC} - Allowed special chars accepted"
  ((PASSED++))
else
  echo -e "${RED}❌ FAILED${NC} - Should accept - _ ."
  echo "$RESPONSE"
  ((FAILED++))
fi
echo ""

# ═══════════════════════════════════════════════════════════════
# RESUMEN
# ═══════════════════════════════════════════════════════════════
TOTAL=$((PASSED + FAILED))
echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
echo -e "${BLUE}  TEST RESULTS${NC}"
echo -e "${BLUE}════════════════════════════════════════════════════════${NC}"
echo -e "Total tests: $TOTAL"
echo -e "${GREEN}Passed: $PASSED${NC}"
echo -e "${RED}Failed: $FAILED${NC}"
echo ""

if [ $FAILED -eq 0 ]; then
  echo -e "${GREEN}✅ ALL TESTS PASSED!${NC}"
  exit 0
else
  echo -e "${RED}❌ SOME TESTS FAILED${NC}"
  exit 1
fi
