# 🚀 ACTUALIZACIÓN RAILWAY v2.4.0

## 📋 CAMBIOS IMPLEMENTADOS

### ✅ **NUEVAS CARACTERÍSTICAS:**

1. **Validación Completa de Input** (igual a n8n)
   - Longitud: 3-10 caracteres
   - Caracteres permitidos: A-Z, 0-9, -, _, .
   - Normalización automática (uppercase)

2. **Manejo de Errores Estandarizado**
   - Códigos de error claros (MISSING_CODE, INVALID_LENGTH, etc.)
   - HTTP status codes apropiados (400, 404, 500)
   - Respuestas JSON consistentes

3. **Integración con n8n Lista**
   - Variable de entorno N8N_WEBHOOK_URL
   - Forward automático a n8n cuando está configurado
   - Fallback cuando n8n no está disponible

4. **Nuevos Endpoints**
   - POST /api/v1/filters/search (principal)
   - POST /api/v1/filters/lookup (alternativo)
   - POST /api/v1/test/validate (testing)
   - POST /chat (chatbot)

5. **Logging Mejorado**
   - Request logging automático
   - Error tracking detallado
   - Startup info completo

---

## 📦 ARCHIVOS ACTUALIZADOS

### **1. server.js** → **v2.4.0**
- ✅ Validación completa
- ✅ Manejo de errores robusto
- ✅ Integración n8n
- ✅ 4 endpoints funcionales

### **2. package.json** → **v2.4.0**
- ✅ Agregada dependencia: node-fetch@2.7.0
- ✅ Actualizada versión

### **3. .env.example** → **Nuevo**
- ✅ Variables de entorno documentadas
- ✅ N8N_WEBHOOK_URL incluida

---

## 🔧 PASOS DE ACTUALIZACIÓN

### **MÉTODO 1: VÍA GITHUB (Recomendado)**

#### **Paso 1: Descargar archivos actualizados**
Desde Claude:
1. server.js actualizado
2. package.json actualizado
3. .env.example

#### **Paso 2: Reemplazar en tu repositorio local**
```bash
# En tu terminal
cd elimfilters-proxy-api

# Backup de archivos actuales (opcional)
cp server.js server.js.backup
cp package.json package.json.backup

# Reemplazar con archivos actualizados
cp ~/Downloads/server_updated.js ./server.js
cp ~/Downloads/package_updated.json ./package.json
cp ~/Downloads/.env.example ./.env.example
```

#### **Paso 3: Commit y push**
```bash
git add server.js package.json .env.example
git commit -m "feat: v2.4.0 - validación completa y integración n8n"
git push origin main
```

#### **Paso 4: Railway redesplegará automáticamente**
- Ve a Railway dashboard
- Verifica que el nuevo deployment inicia
- Espera ~30-60 segundos
- Status debe ser "Active ✅"

---

### **MÉTODO 2: EDITAR EN GITHUB WEB**

#### **Paso 1: Editar server.js**
1. Ve a: https://github.com/elimfilters/elimfilters-proxy-api/blob/main/server.js
2. Click en ✏️ "Edit this file"
3. Borra todo el contenido
4. Copia y pega el contenido de server_updated.js
5. Commit changes: "feat: update server.js to v2.4.0"

#### **Paso 2: Editar package.json**
1. Ve a: https://github.com/elimfilters/elimfilters-proxy-api/blob/main/package.json
2. Click en ✏️ "Edit this file"
3. Actualiza:
   - version: "2.4.0"
   - dependencies: agregar "node-fetch": "^2.7.0"
4. Commit changes

#### **Paso 3: Agregar .env.example**
1. En GitHub, click en "Add file" → "Create new file"
2. Nombre: `.env.example`
3. Copia contenido del archivo .env.example
4. Commit changes

---

## ⚙️ CONFIGURACIÓN RAILWAY

### **Paso 1: Configurar variable de entorno N8N_WEBHOOK_URL**

**Después de activar tu workflow n8n:**

1. En Railway, ve a tu proyecto
2. Click en "Variables"
3. Agregar nueva variable:
   ```
   Key: N8N_WEBHOOK_URL
   Value: https://tu-n8n-instance.app.n8n.cloud/webhook/filter-lookup
   ```
4. Click "Add" y "Deploy"

**⚠️ IMPORTANTE:** Sin esta variable, Railway funcionará pero no se conectará a n8n.

---

## 🧪 VALIDAR ACTUALIZACIÓN

### **Test 1: Health check**
```bash
curl https://elimfilters-proxy-api-production.up.railway.app/health
```

**Esperado:**
```json
{
  "status": "ok",
  "version": "2.4.0",
  "endpoints": {
    "health": "GET /health",
    "search": "POST /api/v1/filters/search",
    "lookup": "POST /api/v1/filters/lookup",
    "chat": "POST /chat"
  }
}
```

---

### **Test 2: Validación - Código corto**
```bash
curl -X POST https://elimfilters-proxy-api-production.up.railway.app/api/v1/filters/search \
  -H "Content-Type: application/json" \
  -d '{"code": "AB"}'
```

**Esperado:**
```json
{
  "success": false,
  "error": "Code must be 3-10 characters",
  "error_code": "INVALID_LENGTH",
  "received": "AB"
}
```

---

### **Test 3: Validación - Caracteres inválidos**
```bash
curl -X POST https://elimfilters-proxy-api-production.up.railway.app/api/v1/filters/search \
  -H "Content-Type: application/json" \
  -d '{"code": "ABC@#$"}'
```

**Esperado:**
```json
{
  "success": false,
  "error": "Invalid characters in code. Only alphanumeric and -_. allowed",
  "error_code": "INVALID_CHARS",
  "received": "ABC@#$"
}
```

---

### **Test 4: Código válido**
```bash
curl -X POST https://elimfilters-proxy-api-production.up.railway.app/api/v1/filters/search \
  -H "Content-Type: application/json" \
  -d '{"code": "1R1808"}'
```

**Esperado (sin N8N_WEBHOOK_URL configurada):**
```json
{
  "success": true,
  "message": "Code validated successfully - n8n integration pending",
  "code": "1R1808",
  "note": "Set N8N_WEBHOOK_URL environment variable to enable full integration"
}
```

**Esperado (CON N8N_WEBHOOK_URL configurada):**
```json
{
  "success": true,
  "source": "database" o "generated",
  "data": {
    "sku": "EL81808",
    ...
  }
}
```

---

### **Test 5: Endpoint de test**
```bash
curl -X POST https://elimfilters-proxy-api-production.up.railway.app/api/v1/test/validate \
  -H "Content-Type: application/json" \
  -d '{"code": "P551808"}'
```

**Esperado:**
```json
{
  "success": true,
  "message": "Code is valid",
  "normalized": "P551808",
  "original": "P551808"
}
```

---

## 📊 COMPARACIÓN DE RESPUESTAS

### **ANTES (v2.3.0):**
```json
{
  "success": false,
  "error": "Query required"
}
```

### **AHORA (v2.4.0):**
```json
{
  "success": false,
  "error": "Code is required",
  "error_code": "MISSING_CODE",
  "timestamp": "2025-10-25T10:30:00.000Z"
}
```

**Mejoras:**
- ✅ error_code para manejo programático
- ✅ timestamp para logs
- ✅ Respuestas consistentes

---

## 🔄 FLUJO COMPLETO (Railway → n8n)

```
CLIENTE
   ↓
   POST /api/v1/filters/search
   Body: {"code": "1R1808"}
   ↓
RAILWAY (v2.4.0)
   ├─ Valida código ✅
   ├─ Normaliza: "1R1808" → "1R1808"
   └─ Forward a n8n →
                        ↓
                   N8N WORKFLOW
                        ├─ Busca en Google Sheet
                        ├─ Web scraping si no existe
                        ├─ Genera SKU
                        └─ Responde ←
   ↓
RAILWAY
   └─ Retorna respuesta al cliente
   ↓
CLIENTE
   Recibe: {"success": true, "data": {...}}
```

---

## ⚠️ TROUBLESHOOTING

### **Error: "Cannot find module 'node-fetch'"**
```
Causa: package.json no actualizado
Solución:
1. Actualizar package.json
2. Push a GitHub
3. Railway reinstalará dependencias automáticamente
```

### **Error: "N8N_WEBHOOK_URL is not defined"**
```
Causa: Variable de entorno no configurada
Solución:
1. En Railway → Variables
2. Agregar N8N_WEBHOOK_URL
3. Deploy
```

### **Railway no redespliega**
```
Causa: Git push no detectado
Solución:
1. Verificar que hiciste push a main/master
2. En Railway → Deployments → Manual Deploy
```

---

## 📈 PRÓXIMOS PASOS

### **1. Ahora mismo:**
⬜ Actualizar archivos en GitHub
⬜ Validar deployment en Railway
⬜ Probar endpoints con tests

### **2. Después de n8n activo:**
⬜ Configurar N8N_WEBHOOK_URL en Railway
⬜ Probar integración completa
⬜ Validar que ambos sistemas se comunican

### **3. Fase final:**
⬜ Integrar con WordPress
⬜ Configurar monitoreo
⬜ Optimizar performance

---

## ✅ CHECKLIST DE ACTUALIZACIÓN

⬜ Descargar archivos actualizados
⬜ Reemplazar en repositorio local
⬜ Commit y push a GitHub
⬜ Verificar deployment en Railway (status Active)
⬜ Test 1: Health check → version "2.4.0"
⬜ Test 2: Validación longitud → error_code "INVALID_LENGTH"
⬜ Test 3: Validación caracteres → error_code "INVALID_CHARS"
⬜ Test 4: Código válido → success true
⬜ Test 5: Endpoint test → normalized code
⬜ Configurar N8N_WEBHOOK_URL (después de activar n8n)
⬜ Test integración Railway → n8n

---

## 📞 RESUMEN

**Lo que tendrás después de actualizar:**

✅ Validación de input robusta (igual a n8n)
✅ Manejo de errores estandarizado
✅ Códigos de error claros (MISSING_CODE, INVALID_LENGTH, etc.)
✅ Integración con n8n lista
✅ 4 endpoints funcionales
✅ Logging mejorado
✅ Respuestas consistentes

**Versión:** 2.4.0
**Fecha:** 2025-10-25
**Status:** ✅ Listo para deployment
