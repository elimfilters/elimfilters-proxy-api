# Changelog - ELIMFILTERS Proxy API

## [3.0.0] - 2025-10-29

### 🔒 REGLAS CORREGIDAS v2.2.3

#### Agregado
- ✅ **businessLogic.js v2.2.3** con 17 reglas corregidas
- ✅ **rulesProtection.js** - Sistema de protección inmutable
- ✅ **REGLAS_MAESTRAS.json v2.2.3** - Configuración actualizada
- ✅ README completo con documentación
- ✅ CHANGELOG con historial de versiones

#### Cambiado
- ✅ 10 prefijos corregidos:
  - OIL|LD: EL9 → EL8
  - FUEL|HD: EF8 → EF9
  - AIRE|LD: EA2 → EA1
  - CABIN|HD: EC2 → EC1
  - AIR DRYER|HD: ED1 → ED4
  - COOLANT|HD: ET8 → EW7
  - CARCAZA AIR FILTER|HD: EZ1 → EA2
  - TURBINE SERIES|HD: EB1 → ET9
  - KITS SERIES HD|HD: EK8 → EK5
  - KITS SERIES LD|LD: EK9 → EK3

#### Eliminado
- ❌ 5 reglas LD que no existen:
  - FUEL SEPARATOR|LD
  - AIR DRYER|LD
  - COOLANT|LD
  - CARCAZA AIR FILTER|LD
  - TURBINE SERIES|LD

### 🚀 Mejoras de Arquitectura

- Eliminada dependencia de n8n
- Procesamiento directo en el proxy
- Conexión directa a Google Sheets
- Sistema de protección de reglas
- Mayor velocidad de respuesta

---

## [2.5.0-no-n8n] - 2025-10-28

### Agregado
- Versión sin dependencia de n8n
- Procesamiento directo de filtros
- Endpoint /api/detect-filter

### Cambiado
- Arquitectura simplificada
- CORS limitado a elimfilters.com

---

## [2.4.0] - 2025-10-27

### Agregado
- Proxy con n8n
- Endpoints /api/v1/filters/lookup y /search
- Rate limiting

---

## Comparación de Versiones

| Feature | v2.4.0 | v2.5.0 | v3.0.0 |
|---------|--------|--------|--------|
| **n8n** | ✅ Requiere | ❌ No | ❌ No |
| **Reglas** | v2.1 | v2.1 | v2.2.3 ✅ |
| **Protección** | ❌ | ❌ | ✅ |
| **Prefijos correctos** | ❌ | ❌ | ✅ |
| **Google Sheets** | Via n8n | ✅ Directo | ✅ Directo |
| **Velocidad** | Lento | Rápido | Rápido |

---

## Migration Guide

### De v2.5.0 a v3.0.0

```bash
# 1. Pull nuevo código
git pull origin main

# 2. Instalar dependencias (si cambiaron)
npm install

# 3. Verificar variables de entorno
#    (no se requieren cambios)

# 4. Deploy
git push railway main

# 5. Verificar
curl https://tu-url.railway.app/health
# Debe mostrar: "version": "3.0.0"
```

**⚠️ NOTA**: Los SKUs existentes con prefijos incorrectos seguirán funcionando, pero los **nuevos SKUs usarán reglas v2.2.3 correctas**.

### De v2.4.0 (con n8n) a v3.0.0

```bash
# 1. Pull código v3.0.0
git pull origin main

# 2. Actualizar package.json dependencies
npm install

# 3. ELIMINAR variable N8N_WEBHOOK_URL de Railway
#    Ya no se usa

# 4. MANTENER variables de Google Sheets:
#    - GOOGLE_SHEETS_ID
#    - GOOGLE_CREDENTIALS

# 5. Deploy
git push railway main

# 6. Verificar que n8n ya no recibe requests
#    (el proxy procesa todo directamente)
```

---

## Breaking Changes

### v3.0.0
- **Ninguno**: API compatible con v2.5.0
- Endpoints siguen siendo los mismos
- Formato de respuesta idéntico
- WordPress no requiere cambios

### v2.5.0
- Eliminación de n8n
- Cambio de endpoint: `/api/v1/filters/lookup` → `/api/detect-filter`

---

**ELIMFILTERS Proxy API**  
**v3.0.0 - Reglas Corregidas y Protegidas** 🔒
