# 🔧 ELIMFILTERS Proxy API v3.0.0

Servidor proxy sin dependencias de n8n con **Reglas v2.2.3 corregidas** y **Sistema de protección inmutable**.

## 🆕 NUEVO EN v3.0.0

```
✅ Reglas v2.2.3 CORREGIDAS (17 combinaciones)
✅ Sistema de protección inmutable  
✅ Sin dependencia de n8n
✅ Procesamiento directo
✅ Google Sheets integrado
✅ Compatible con WordPress
```

---

## 🔄 FLUJO

```
WordPress (elimfilters.com)
         │
         ▼
Proxy API (Railway) ← ESTE SERVIDOR
    ├─ Busca en Google Sheets Master
    ├─ Si existe → retorna datos
    └─ Si NO existe → genera SKU + guarda + retorna
         │
         ▼
WordPress (muestra resultado)
```

---

## 📋 REGLAS CORREGIDAS v2.2.3

### 17 Combinaciones Correctas

| Family | Duty | Prefix |
|--------|------|--------|
| OIL | HD | EL8 |
| OIL | LD | EL8 |
| FUEL | HD | EF9 |
| FUEL | LD | EF9 |
| AIRE | HD | EA1 |
| AIRE | LD | EA1 |
| CABIN | HD | EC1 |
| CABIN | LD | EC1 |
| FUEL SEPARATOR | HD | ES9 |
| AIR DRYER | HD | ED4 |
| HIDRAULIC | HD | EH8 |
| HIDRAULIC | LD | EH9 |
| COOLANT | HD | EW7 |
| CARCAZA AIR FILTER | HD | EA2 |
| TURBINE SERIES | HD | ET9 |
| KITS SERIES HD | HD | EK5 |
| KITS SERIES LD | LD | EK3 |

### Cambios desde v2.2.2

- ✅ 10 prefijos corregidos
- ✅ 5 reglas LD eliminadas (solo HD)
- ✅ Sistema de protección inmutable

---

## 🚀 DEPLOYMENT

### Railway

1. **Push a GitHub**
```bash
git add .
git commit -m "Update to v3.0.0 with rules v2.2.3"
git push origin main
```

2. **Railway detecta cambios automáticamente**

3. **Variables de entorno requeridas:**
```
GOOGLE_SHEETS_ID=1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U
GOOGLE_CREDENTIALS=<json_credentials>
PORT=3000
```

### Verificar Deployment

```bash
# Health check
curl https://elimfilters-proxy-api-production.up.railway.app/health

# Debe retornar:
{
  "status": "ok",
  "version": "3.0.0",
  "service": "ELIMFILTERS Proxy API"
}
```

---

## 📡 ENDPOINTS

### GET /health

Health check del servidor

```bash
curl https://tu-url.railway.app/health
```

**Response:**
```json
{
  "status": "ok",
  "timestamp": "2025-10-29T12:00:00.000Z",
  "service": "ELIMFILTERS Proxy API",
  "version": "3.0.0",
  "endpoints": {
    "health": "GET /health",
    "detect": "POST /api/detect-filter"
  }
}
```

### POST /api/detect-filter

Buscar/generar filtro por código OEM

```bash
curl -X POST https://tu-url.railway.app/api/detect-filter \
  -H "Content-Type: application/json" \
  -d '{"code": "P552100"}'
```

**Acepta múltiples nombres de campo:**
- `code`
- `sku`  
- `oem`
- `query`

**Response exitoso:**
```json
{
  "status": "OK",
  "sku": "EL82100",
  "oem_code": "P552100",
  "family": "OIL",
  "duty": "HD",
  "filter_media": "ELIMTEK",
  "specs_summary": "Oil Filter with ELIMTEK™ Technology",
  ...
}
```

---

## 🔧 DESARROLLO LOCAL

### 1. Instalar dependencias

```bash
npm install
```

### 2. Configurar variables de entorno

```bash
cp .env.example .env
# Editar .env con tus credenciales
```

### 3. Iniciar servidor

```bash
npm start
# O con auto-reload:
npm run dev
```

### 4. Probar

```bash
curl http://localhost:3000/health

curl -X POST http://localhost:3000/api/detect-filter \
  -H "Content-Type: application/json" \
  -d '{"code": "P552100"}'
```

---

## 📁 ESTRUCTURA

```
elimfilters-proxy-v3.0.0/
├── server.js                    # Servidor Express principal
├── businessLogic.js             # Reglas v2.2.3 corregidas
├── rulesProtection.js           # Sistema de protección inmutable
├── filterProcessor.js           # Procesamiento de filtros
├── detectionService.js          # Detección y lookup
├── googleSheetsConnector.js     # Conexión Google Sheets
├── jsonBuilder.js               # Constructor de respuestas
├── utils.js                     # Utilidades
├── security.js                  # Seguridad
├── package.json                 # Dependencias v3.0.0
├── Dockerfile                   # Para Docker
├── railway.json                 # Config Railway
├── .env.example                 # Template variables
├── config/
│   └── REGLAS_MAESTRAS.json    # Reglas v2.2.3
└── README.md                    # Este archivo
```

---

## 🔒 SEGURIDAD

### Sistema de Protección de Reglas

```
Capa 1: Hardcoded en código
Capa 2: Object.freeze() inmutable
Capa 3: Validación en runtime
```

Las reglas v2.2.3 están protegidas y **no pueden ser alteradas**.

### Rate Limiting

```javascript
30 requests por minuto por IP
```

### CORS

```javascript
Solo permite:
- https://elimfilters.com
- https://www.elimfilters.com
```

---

## 🆚 DIFERENCIAS CON v2.5.0

| Feature | v2.5.0 | v3.0.0 |
|---------|--------|--------|
| Reglas | v2.1 (antiguas) | v2.2.3 (corregidas) |
| Sistema protección | ❌ No | ✅ Sí |
| Prefijos correctos | ❌ 10 errores | ✅ Corregidos |
| Dependencia n8n | ❌ No | ❌ No |
| Google Sheets | ✅ Sí | ✅ Sí |

---

## 📊 COMPATIBILIDAD

### WordPress

Compatible con el plugin/código actual en:
- `https://elimfilters.com/part-search/`

No requiere cambios en WordPress, solo actualizar URL del proxy.

### Google Sheets

Compatible con Sheet Master:
- ID: `1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U`
- 32 columnas con especificaciones completas

---

## ❓ TROUBLESHOOTING

### Error: "Cannot connect to Google Sheets"

```bash
# Verificar credenciales
echo $GOOGLE_CREDENTIALS | jq .

# Verificar Sheet ID
echo $GOOGLE_SHEETS_ID
```

### Error: "Rules validation failed"

```bash
# Las reglas están protegidas
# No intentar modificar businessLogic.js manualmente
# Usar versión oficial
```

### El servidor no inicia

```bash
# Verificar Node.js version
node --version  # Debe ser >= 18.0.0

# Reinstalar dependencias
rm -rf node_modules
npm install
npm start
```

---

## 📝 CHANGELOG

### v3.0.0 (2025-10-29)

**🔒 REGLAS CORREGIDAS v2.2.3**
- ✅ 10 prefijos corregidos
- ✅ 5 reglas LD eliminadas
- ✅ 17 combinaciones finales
- ✅ Sistema de protección inmutable

**🔧 MEJORAS**
- Sin dependencia de n8n
- Procesamiento directo
- Más rápido
- Más control

**📚 DOCUMENTACIÓN**
- README actualizado
- Ejemplos de uso
- Guía de deployment

---

## 🔗 LINKS

- **Producción:** https://elimfilters-proxy-api-production.up.railway.app
- **WordPress:** https://elimfilters.com/part-search/
- **GitHub:** https://github.com/elimfilters/elimfilters-proxy-api
- **Google Sheet:** https://docs.google.com/spreadsheets/d/1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U

---

## ✅ CHECKLIST DE DEPLOYMENT

- [ ] Push a GitHub
- [ ] Railway detecta cambios
- [ ] Variables de entorno configuradas
- [ ] Build exitoso
- [ ] Servidor inicia
- [ ] `/health` retorna OK
- [ ] `/api/detect-filter` funciona
- [ ] WordPress conecta correctamente

---

**ELIMFILTERS Proxy API v3.0.0**  
**Con Reglas v2.2.3 Protegidas** 🔒  
**Sin n8n - Procesamiento Directo** 🚀
