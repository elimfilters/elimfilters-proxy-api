/**
 * universeValidator.js - v2.1.0
 * 
 * Validador y normalizador de OEM Codes y Cross References
 * Maneja el UNIVERSO COMPLETO de códigos (no solo uno)
 * 
 * USO EN server.js:
 * const UniverseValidator = require('./universeValidator');
 * const validator = new UniverseValidator(RULES_MASTER);
 * 
 * Usa RULES_MASTER.oem_universe para:
 * - Patrones de Donaldson, FRAM, Generic
 * - Búsqueda en cascada por duty
 * - Validación de códigos
 * - Normalización de múltiples formatos
 */

class UniverseValidator {
  constructor(rulesMaster) {
    if (!rulesMaster) {
      throw new Error('⚠️  UniverseValidator: rulesMaster REQUIRED');
    }
    if (!rulesMaster.oem_universe) {
      throw new Error('⚠️  UniverseValidator: rulesMaster.oem_universe MISSING (actualizar REGLAS_MAESTRAS.json v2.1.0)');
    }
    this.rulesMaster = rulesMaster;
    this.universe = rulesMaster.oem_universe;
    console.log(`✅ UniverseValidator initialized (v${rulesMaster.version})`);
  }

  /**
   * FUNCIÓN 1: Normalizar múltiples formatos de entrada
   * 
   * Maneja:
   * - Arrays: ['P552100', 'LF3620']
   * - Strings delimitados: 'P552100, LF3620; 1R1808'
   * - Strings con saltos: 'P552100\nLF3620\n1R1808'
   * - Objetos: [{brand: 'DONALDSON', code: 'P552100'}]
   */
  normalize(input) {
    if (!input) return [];
    
    // Si es array, procesar cada elemento
    if (Array.isArray(input)) {
      return input
        .map(item => this._normalizeItem(item))
        .filter(item => item && item.length > 0);
    }

    // Si es string, hacer split por delimitadores
    if (typeof input === 'string') {
      const delimiters = this.universe.delimiters || [',', ';', '\n', ' ', '|'];
      const regex = new RegExp(`[${delimiters.map(d => d.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('')}]+`);
      
      return input
        .split(regex)
        .map(code => this._normalizeItem(code))
        .filter(item => item && item.length > 0);
    }

    // Si es objeto
    if (typeof input === 'object' && input.code) {
      return [this._normalizeItem(input.code)];
    }

    return [];
  }

  /**
   * Normalizar UN código individual
   */
  _normalizeItem(item) {
    if (!item) return '';
    
    let code = item;
    
    // Si es objeto, extraer código
    if (typeof item === 'object') {
      code = item.code || item.value || item.id || '';
    }

    // Convertir a string
    code = String(code).trim();

    // Aplicar validaciones
    const validation = this.universe.validation || {};

    // Convertir a mayúsculas
    if (validation.normalize_uppercase !== false) {
      code = code.toUpperCase();
    }

    // Eliminar caracteres especiales NO permitidos
    if (Array.isArray(validation.allow_special_chars)) {
      const allowed = validation.allow_special_chars;
      code = code.replace(/[^A-Z0-9-_.]/g, '');
    } else {
      // Solo alfanuméricos por defecto
      code = code.replace(/[^A-Z0-9]/g, '');
    }

    // Validar longitud
    const minLen = validation.min_length || 3;
    const maxLen = validation.max_length || 10;
    
    if (code.length < minLen || code.length > maxLen) {
      return '';
    }

    return code;
  }

  /**
   * FUNCIÓN 2: Validar códigos contra patterns
   */
  validate(codes) {
    const normalized = this.normalize(codes);
    
    const results = {
      valid: true,
      normalized,
      patterns: [],
      candidates: normalized.slice(0, this.universe.search_order_max || 10),
      invalid: [],
      details: []
    };

    // Probar cada código contra patterns
    for (const code of normalized) {
      let found = false;
      
      // Buscar en Donaldson
      if (!found && this._matchesPattern(code, 'donaldson')) {
        results.patterns.push({
          code,
          type: 'DONALDSON',
          pattern: '/^P\\d{5,6}$/i',
          priority: 1,
          duty: 'HD'
        });
        found = true;
      }

      // Buscar en FRAM
      if (!found && this._matchesPattern(code, 'fram')) {
        results.patterns.push({
          code,
          type: 'FRAM',
          pattern: '/^(PH|CA|CF|CH)\\d{3,6}$/i',
          priority: 2,
          duty: 'LD'
        });
        found = true;
      }

      // Buscar en Generic
      if (!found && this._matchesPattern(code, 'generic')) {
        results.patterns.push({
          code,
          type: 'GENERIC',
          pattern: '/^[A-Z0-9]{4,10}$/i',
          priority: 3,
          duty: 'any'
        });
        found = true;
      }

      // Si no encontró patrón, marcar como inválido
      if (!found) {
        results.valid = false;
        results.invalid.push(code);
      }
    }

    return results;
  }

  /**
   * Auxiliar: probar si un código matchea un pattern
   */
  _matchesPattern(code, patternType) {
    const patterns = this.universe.patterns[patternType];
    if (!patterns || !patterns.primary) {
      return false;
    }

    // Probar primary patterns
    for (const patternStr of patterns.primary) {
      const regex = this._stringToRegex(patternStr);
      if (regex.test(code)) {
        return true;
      }
    }

    // Probar fallback patterns
    if (Array.isArray(patterns.fallback)) {
      for (const patternStr of patterns.fallback) {
        const regex = this._stringToRegex(patternStr);
        if (regex.test(code)) {
          return true;
        }
      }
    }

    return false;
  }

  /**
   * Auxiliar: convertir string regex a RegExp
   * Input: "/^P\\d{5,6}$/i" o "^P\\d{5,6}$"
   * Output: RegExp object
   */
  _stringToRegex(str) {
    if (!str) return /^$/;
    
    // Si ya es regex, retornar
    if (str instanceof RegExp) {
      return str;
    }

    // Extraer pattern e flags de string
    const match = str.match(/^\/(.*)\/([gimuy]*)$/);
    if (match) {
      return new RegExp(match[1], match[2] || 'i');
    }

    // Si no tiene slashes, asumir que es pattern con flags
    return new RegExp(str, 'i');
  }

  /**
   * FUNCIÓN 3: Ejecutar búsqueda en cascada (CRITICAL)
   */
  searchInCascade(oemCodes, crossReferences, dutyLevel) {
    const validated = this.validate(oemCodes);
    
    if (!validated.valid) {
      return {
        success: false,
        error: 'INVALID_OEM_CODES',
        invalid: validated.invalid
      };
    }

    // Obtener search order para este duty
    const searchOrder = this._getSearchOrder(dutyLevel);

    // Ejecutar búsqueda en orden
    for (const step of searchOrder.order) {
      const source = step.source; // 'cross_reference' o 'oem_codes'
      const target = step.target; // 'donaldson', 'fram', 'hd_brands', etc

      let codes;
      if (source === 'cross_reference') {
        codes = this.normalize(crossReferences);
      } else {
        codes = validated.candidates;
      }

      // Buscar código que matchee target
      const result = this._findCodeInList(codes, target);
      
      if (result) {
        return {
          success: true,
          code_used: result.code,
          source_type: result.type,
          matched_pattern: result.pattern,
          search_order_position: searchOrder.order.indexOf(step) + 1,
          candidates_evaluated: validated.candidates,
          search_order_used: `${dutyLevel}_${searchOrder.priority}`,
          evaluation_time: new Date().getTime()
        };
      }
    }

    // Si no encontró nada, fallback a cualquier código válido
    if (validated.candidates.length > 0) {
      return {
        success: true,
        code_used: validated.candidates[0],
        source_type: 'FALLBACK',
        matched_pattern: 'ANY',
        search_order_position: 999,
        candidates_evaluated: validated.candidates,
        search_order_used: `${dutyLevel}_FALLBACK`,
        evaluation_time: new Date().getTime()
      };
    }

    return {
      success: false,
      error: 'NO_VALID_CODES',
      candidates_evaluated: validated.candidates
    };
  }

  /**
   * Auxiliar: obtener search order para duty level
   */
  _getSearchOrder(dutyLevel) {
    const searchOrders = this.universe.search_order || [];
    
    for (const order of searchOrders) {
      if (order.duty === dutyLevel) {
        return {
          priority: dutyLevel,
          order: order.order
        };
      }
    }

    // Default fallback
    return {
      priority: 'DEFAULT',
      order: [
        { source: 'cross_reference', target: 'generic' },
        { source: 'oem_codes', target: 'any' }
      ]
    };
  }

  /**
   * Auxiliar: buscar en lista de códigos un match para target
   */
  _findCodeInList(codes, target) {
    for (const code of codes) {
      // Buscar si matchea target pattern
      if (target === 'donaldson' && this._matchesPattern(code, 'donaldson')) {
        return {
          code,
          type: 'DONALDSON',
          pattern: '/^P\\d{5,6}$/i'
        };
      }

      if (target === 'fram' && this._matchesPattern(code, 'fram')) {
        return {
          code,
          type: 'FRAM',
          pattern: '/^(PH|CA|CF|CH)\\d{3,6}$/i'
        };
      }

      // Si target es generic o any
      if ((target === 'generic' || target === 'any') && code) {
        return {
          code,
          type: 'GENERIC',
          pattern: '/^[A-Z0-9]+$/i'
        };
      }
    }

    return null;
  }

  /**
   * FUNCIÓN 4: Normalizar y validar entrada raw
   */
  normalizeAndValidate(rawOEM, rawCross) {
    return {
      oemCodes: {
        raw: rawOEM,
        normalized: this.normalize(rawOEM),
        validated: this.validate(rawOEM)
      },
      crossReferences: {
        raw: rawCross,
        normalized: this.normalize(rawCross),
        validated: this.validate(rawCross)
      },
      timestamp: new Date().toISOString()
    };
  }

  /**
   * FUNCIÓN 5: Obtener universo para enviar a frontend
   */
  getUniverse() {
    return {
      patterns: this.universe.patterns,
      brands: this.universe.brands,
      validation: this.universe.validation,
      examples: {
        donaldson: 'P552100, P164378, DBL123',
        fram: 'PH8A, CA123, CF456',
        generic: 'LF3620, 1R1808'
      },
      search_order: this.universe.search_order
    };
  }
}

module.exports = UniverseValidator;
