/**
 * ELIMFILTERS Proxy API
 * Versión estable para producción en Railway.
 * Problema resuelto: express-rate-limit ya no tumba el contenedor cuando Railway
 * añade el header X-Forwarded-For.
 *
 * Rutas expuestas:
 *   GET  /health
 *   POST /api/v1/filters/lookup
 *   GET  /api/v1/filters/search
 *   POST /chat
 */

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const fetch = require('node-fetch'); // v2.x compatible con require()
const helmet = require('helmet');

const app = express();

/**
 * IMPORTANTE:
 * Railway trabaja detrás de proxy. Express por defecto NO confía en X-Forwarded-For.
 * express-rate-limit valida eso y si no confía rompe la app con
 * ERR_ERL_UNEXPECTED_X_FORWARDED_FOR.
 *
 * Esta línea es obligatoria. Sin esto la app se cae.
 */
app.set('trust proxy', 1);

// Seguridad básica HTTP
app.use(helmet());

// CORS y body parser
app.use(cors());
app.use(express.json());

/**
 * Rate limiter protegido y compatible con proxy.
 * Clave: usamos keyGenerator propio y no dejamos que falle.
 */
const limiter = rateLimit({
  windowMs: 60 * 1000, // 1 minuto
  max: 60,             // 60 requests por IP por minuto
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req /*, res*/) => {
    // req.ip ya respeta trust proxy. Si por alguna razón viene vacío devolvemos 'unknown'
    return req.ip || 'unknown';
  },
});
app.use(limiter);

/**
 * Normalizador de entrada.
 * Extrae código de búsqueda desde body o query.
 * Admite code | sku | oem | query.
 */
function buildQueryPayload(req) {
  const codeCandidate =
    (req.body && (req.body.code || req.body.sku || req.body.oem || req.body.query)) ||
    (req.query && (req.query.code || req.query.sku || req.query.oem || req.query.query)) ||
    '';

  const cleaned = String(codeCandidate || '').trim();

  return {
    raw_query_used: codeCandidate || '',
    normalized_query_used: cleaned.toUpperCase(),
  };
}

/**
 * Conector hacia el flujo n8n "elimfilters-search".
 * Esta es la pieza central de catálogo.
 */
async function callN8nSearchService(userQueryInfo) {
  // Permitimos override por variable de entorno
  const webhookUrl =
    process.env.N8N_WEBHOOK_URL ||
    'https://elimfilterscross.app.n8n.cloud/webhook/elimfilters-search';

  const bodyToSend = {
    query: userQueryInfo.normalized_query_used,
    raw: userQueryInfo.raw_query_used,
    source: 'railway-proxy',
  };

  const resp = await fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(bodyToSend),
  });

  let result;
  try {
    result = await resp.json();
  } catch (e) {
    // n8n devolvió algo que no es JSON o devolvió vacío
    result = {
      error: true,
      message: 'Respuesta no es JSON válido desde n8n',
      statusCode: resp.status,
    };
  }

  return {
    status: resp.status,
    ok: resp.ok,
    n8n_response: result,
  };
}

/**
 * GET /health
 * Diagnóstico rápido. Úsalo para monitoreo y para que WordPress verifique conexión.
 */
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'ELIMFILTERS Proxy API with rules 2.1.0',
    env: process.env.NODE_ENV || 'production',
    endpoints: {
      health: 'GET /health',
      lookup: 'POST /api/v1/filters/lookup',
      search: 'GET /api/v1/filters/search',
      chat: 'POST /chat',
    },
  });
});

/**
 * POST /api/v1/filters/lookup
 * Uso: catálogos, chatbot, WP.
 * Body esperado: { "code": "LF3000" } o "sku", "oem", "query".
 */
app.post('/api/v1/filters/lookup', async (req, res) => {
  try {
    const queryInfo = buildQueryPayload(req);
    const n8nResult = await callN8nSearchService(queryInfo);

    res.status(n8nResult.status || 200).json({
      success: n8nResult.ok,
      ...queryInfo,
      source: 'POST /api/v1/filters/lookup',
      data: n8nResult.n8n_response || null,
    });
  } catch (err) {
    console.error('lookup error', err);
    res.status(500).json({
      success: false,
      source: 'POST /api/v1/filters/lookup',
      error: 'Lookup internal error',
    });
  }
});

/**
 * GET /api/v1/filters/search
 * Este endpoint existe SOLO porque tu n8n llama un HTTP GET Railway API Fallback.
 * Params soportados:
 *   /api/v1/filters/search?code=LF3000
 *   /api/v1/filters/search?sku=EL82100
 *   /api/v1/filters/search?oem=P552100
 */
app.get('/api/v1/filters/search', async (req, res) => {
  try {
    const queryInfo = buildQueryPayload(req);
    const n8nResult = await callN8nSearchService(queryInfo);

    res.status(n8nResult.status || 200).json({
      success: n8nResult.ok,
      ...queryInfo,
      source: 'GET /api/v1/filters/search',
      data: n8nResult.n8n_response || null,
    });
  } catch (err) {
    console.error('search error', err);
    res.status(500).json({
      success: false,
      source: 'GET /api/v1/filters/search',
      error: 'Search internal error',
    });
  }
});

/**
 * POST /chat
 * Punto para integración futura WhatsApp / webchat comercial.
 */
app.post('/chat', async (req, res) => {
  try {
    const { message } = req.body || {};
    if (!message || !String(message).trim()) {
      return res.status(400).json({
        success: false,
        error: 'message requerido',
      });
    }

    // Placeholder: Aquí puedes enrutar a otro flujo n8n específico de soporte humano
    res.json({
      success: true,
      echo: message,
      note: 'Ruta /chat operativa.',
    });
  } catch (err) {
    console.error('chat error', err);
    res.status(500).json({
      success: false,
      source: 'POST /chat',
      error: 'Chat internal error',
    });
  }
});

/**
 * Arranque del servidor
 * Railway inyecta PORT en runtime. Fallback 3000 local/dev.
 */
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('✅ ELIMFILTERS Proxy API with rules 2.1.0');
  console.log(`🚀 Listening on port ${PORT}`);
  console.log('📊 Health: GET /health');
  console.log('🔎 Lookup: POST /api/v1/filters/lookup');
  console.log('🔍 Search: GET /api/v1/filters/search');
  console.log('💬 Chat: POST /chat');
  console.log('🌐 n8n webhook:', process.env.N8N_WEBHOOK_URL ||
    'https://elimfilterscross.app.n8n.cloud/webhook/elimfilters-search');
});
