# elimfilters-proxy-api

Proxy API estable para catálogo ELIMFILTERS.

## Endpoints vivos

- `GET /health`
- `POST /api/v1/filters/lookup`
- `GET /api/v1/filters/search`
- `POST /chat`

## Error original

El contenedor en Railway se caía con:

ValidationError: The 'X-Forwarded-For' header is set but the Express 'trust proxy' setting is false

Causa: express-rate-limit + proxy de Railway.

## Fijado

En \`server.js\`:

```js
app.set('trust proxy', 1);

const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || 'unknown',
});
app.use(limiter);
```

## Deploy

1. Sube este repo completo a GitHub (reemplaza el código viejo).  
2. Railway va a redeploy automáticamente.  
3. En Variables de Railway define:
   - \`N8N_WEBHOOK_URL\` si quieres override al webhook.
