// elimfiltersTechnology.js
// Validación y mapeo de tecnologías ELIMFILTERS

// ============================================================================
// TECNOLOGÍAS ELIMFILTERS
// ============================================================================

const ELIMFILTERS_TECHNOLOGIES = {
  ELIMTEK: {
    name: 'ELIMTEK™',
    description: 'Advanced liquid filtration media engineered for superior efficiency',
    efficiency: '99.99%',
    applications: ['OIL', 'FUEL', 'HIDRAULIC', 'FUEL SEPARATOR', 'COOLANT'],
    fullDescription: 'ELIMTEK™ technology ensures 99.99% efficiency in extreme conditions'
  },
  
  MAXFLOW: {
    name: 'MAXFLOW™',
    description: 'High-capacity air filtration media for engines and heavy-duty applications',
    protection: 'Up to 10,000 km',
    applications: ['AIRE'],
    fullDescription: 'MAXFLOW™ technology provides up to 10,000 km on-road protection'
  },
  
  MICROKAPPA: {
    name: 'MICROKAPPA™',
    description: 'Cabin air filters with activated carbon and multilayer protection',
    features: 'Captures fine particles, allergens, and harmful gases',
    applications: ['CABIN'],
    fullDescription: 'MICROKAPPA™ with activated carbon captures ultra-fine particles and harmful gases'
  },
  
  STANDARD: {
    name: 'Standard',
    description: 'Standard filtration media',
    applications: ['ALL'],
    fullDescription: 'Standard filtration media'
  }
};

// ============================================================================
// MAPEO: FAMILIA → TECNOLOGÍA RECOMENDADA
// ============================================================================

const FAMILY_TO_TECHNOLOGY = {
  'OIL': 'ELIMTEK',
  'FUEL': 'ELIMTEK',
  'AIRE': 'MAXFLOW',
  'CABIN': 'MICROKAPPA',
  'FUEL SEPARATOR': 'ELIMTEK',
  'AIR DRYER': 'MAXFLOW',
  'HIDRAULIC': 'ELIMTEK',
  'COOLANT': 'ELIMTEK',
  'CARCAZA AIR FILTER': 'STANDARD',
  'TURBINE SERIES': 'STANDARD',
  'KITS SERIES HD': 'STANDARD',
  'KITS SERIES LD': 'STANDARD'
};

// ============================================================================
// FUNCIONES DE VALIDACIÓN
// ============================================================================

/**
 * Valida si una tecnología es válida
 * @param {string} technology - ELIMTEK, MAXFLOW, MICROKAPPA, o Standard
 * @returns {boolean}
 */
function isValidTechnology(technology) {
  if (!technology) return false;
  const upperTech = technology.toUpperCase();
  return upperTech === 'ELIMTEK' || 
         upperTech === 'MAXFLOW' || 
         upperTech === 'MICROKAPPA' || 
         upperTech === 'STANDARD';
}

/**
 * Obtiene la tecnología recomendada para una familia de filtro
 * @param {string} family - OIL, FUEL, AIRE, etc.
 * @returns {string}
 */
function getRecommendedTechnology(family) {
  if (!family) return 'STANDARD';
  return FAMILY_TO_TECHNOLOGY[family.toUpperCase()] || 'STANDARD';
}

/**
 * Valida si una tecnología es apropiada para una familia
 * @param {string} technology - ELIMTEK, MAXFLOW, etc.
 * @param {string} family - OIL, FUEL, AIRE, etc.
 * @returns {boolean}
 */
function isCompatibleTechnology(technology, family) {
  if (!technology || !family) return false;
  
  const upperTech = technology.toUpperCase();
  const upperFamily = family.toUpperCase();
  
  // Standard es compatible con todo
  if (upperTech === 'STANDARD') return true;
  
  const techInfo = ELIMFILTERS_TECHNOLOGIES[upperTech];
  if (!techInfo) return false;
  
  return techInfo.applications.includes(upperFamily) || 
         techInfo.applications.includes('ALL');
}

/**
 * Obtiene información completa de una tecnología
 * @param {string} technology - ELIMTEK, MAXFLOW, MICROKAPPA, Standard
 * @returns {object|null}
 */
function getTechnologyInfo(technology) {
  if (!technology) return null;
  const upperTech = technology.toUpperCase();
  return ELIMFILTERS_TECHNOLOGIES[upperTech] || null;
}

/**
 * Genera una descripción de specs que incluya la tecnología
 * @param {string} baseDescription - Descripción base del filtro
 * @param {string} technology - ELIMTEK, MAXFLOW, MICROKAPPA
 * @returns {string}
 */
function generateSpecsWithTechnology(baseDescription, technology) {
  if (!technology || technology.toUpperCase() === 'STANDARD') {
    return baseDescription;
  }
  
  const techInfo = getTechnologyInfo(technology);
  if (!techInfo) return baseDescription;
  
  // Si ya menciona la tecnología, no agregar de nuevo
  if (baseDescription.includes(techInfo.name)) {
    return baseDescription;
  }
  
  return `${baseDescription} with ${techInfo.name} Technology`;
}

/**
 * Genera notas técnicas basadas en la tecnología
 * @param {string} technology - ELIMTEK, MAXFLOW, MICROKAPPA
 * @returns {string}
 */
function generateTechnologyNotes(technology) {
  const techInfo = getTechnologyInfo(technology);
  return techInfo ? techInfo.fullDescription : '';
}

/**
 * Valida que no se estén usando nombres de tecnologías de otros fabricantes
 * @param {string} text - Texto a validar
 * @returns {object} { valid: boolean, issues: string[] }
 */
function validateNoCompetitorTechnologies(text) {
  if (!text) return { valid: true, issues: [] };
  
  const competitors = [
    'POWERCORE', 'SYNTEQ', 'ULTRA-WEB', 'ULTRA WEB', 'ULTRAWEEB',
    'NANONET', 'NANO NET', 'NANO-NET', 'NANOWEB',
    'STRATAPORE', 'TETRATEX', 'OPTIMAIR'
  ];
  
  const upperText = text.toUpperCase();
  const issues = [];
  
  competitors.forEach(comp => {
    if (upperText.includes(comp)) {
      issues.push(`Found competitor technology: ${comp}`);
    }
  });
  
  return {
    valid: issues.length === 0,
    issues: issues
  };
}

// ============================================================================
// FUNCIONES DE AUTO-CORRECCIÓN
// ============================================================================

/**
 * Auto-asigna tecnología basada en familia si no se proporcionó
 * @param {object} filterData - Datos del filtro
 * @returns {object} filterData actualizado
 */
function autoAssignTechnology(filterData) {
  if (!filterData.filter_media || filterData.filter_media === '') {
    filterData.filter_media = getRecommendedTechnology(filterData.family);
  }
  return filterData;
}

/**
 * Valida y corrige datos de un filtro
 * @param {object} filterData - Datos del filtro
 * @returns {object} { valid: boolean, data: object, errors: string[], warnings: string[] }
 */
function validateFilterTechnology(filterData) {
  const errors = [];
  const warnings = [];
  
  // Validar familia
  if (!filterData.family) {
    errors.push('Family is required');
  }
  
  // Auto-asignar tecnología si falta
  if (!filterData.filter_media) {
    filterData.filter_media = getRecommendedTechnology(filterData.family);
    warnings.push(`Auto-assigned technology: ${filterData.filter_media} based on family: ${filterData.family}`);
  }
  
  // Validar tecnología
  if (!isValidTechnology(filterData.filter_media)) {
    errors.push(`Invalid technology: ${filterData.filter_media}. Use: ELIMTEK, MAXFLOW, MICROKAPPA, or Standard`);
  }
  
  // Validar compatibilidad
  if (filterData.family && filterData.filter_media) {
    if (!isCompatibleTechnology(filterData.filter_media, filterData.family)) {
      warnings.push(`Technology ${filterData.filter_media} may not be optimal for ${filterData.family}. Recommended: ${getRecommendedTechnology(filterData.family)}`);
    }
  }
  
  // Validar specs_summary
  if (filterData.specs_summary) {
    const validation = validateNoCompetitorTechnologies(filterData.specs_summary);
    if (!validation.valid) {
      errors.push(...validation.issues);
    }
  }
  
  // Validar notes
  if (filterData.notes) {
    const validation = validateNoCompetitorTechnologies(filterData.notes);
    if (!validation.valid) {
      errors.push(...validation.issues);
    }
  }
  
  return {
    valid: errors.length === 0,
    data: filterData,
    errors: errors,
    warnings: warnings
  };
}

// ============================================================================
// EXPORTS
// ============================================================================

module.exports = {
  // Constantes
  ELIMFILTERS_TECHNOLOGIES,
  FAMILY_TO_TECHNOLOGY,
  
  // Validación
  isValidTechnology,
  getRecommendedTechnology,
  isCompatibleTechnology,
  getTechnologyInfo,
  validateNoCompetitorTechnologies,
  validateFilterTechnology,
  
  // Generación
  generateSpecsWithTechnology,
  generateTechnologyNotes,
  
  // Auto-corrección
  autoAssignTechnology
};
