#!/usr/bin/env node

// test.js
// Script para probar la API localmente

const http = require('http');

const BASE_URL = process.env.API_URL || 'http://localhost:3000';

// Colores para la consola
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

// ============================================================================
// TESTS
// ============================================================================

async function testHealthEndpoint() {
  log('\n🧪 Test 1: Health Check', 'cyan');
  
  try {
    const response = await fetch(`${BASE_URL}/health`);
    const data = await response.json();
    
    if (response.ok && data.status === 'ok') {
      log('✅ Health check PASSED', 'green');
      log(`   Service: ${data.service}`, 'blue');
      log(`   Version: ${data.version}`, 'blue');
      log(`   Processing: ${data.processing}`, 'blue');
      log(`   Rules loaded: ${data.rules_loaded}`, 'blue');
      return true;
    } else {
      log('❌ Health check FAILED', 'red');
      return false;
    }
  } catch (error) {
    log(`❌ Health check ERROR: ${error.message}`, 'red');
    return false;
  }
}

async function testLookupEndpoint() {
  log('\n🧪 Test 2: Lookup Endpoint (POST)', 'cyan');
  
  const testCode = 'P552100'; // Código de prueba
  
  try {
    const response = await fetch(`${BASE_URL}/api/v1/filters/lookup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ code: testCode })
    });
    
    const data = await response.json();
    
    if (response.ok) {
      log('✅ Lookup endpoint PASSED', 'green');
      log(`   Code: ${testCode}`, 'blue');
      log(`   Success: ${data.success}`, 'blue');
      log(`   Processed by: ${data.processed_by || 'N/A'}`, 'blue');
      
      if (data.filter) {
        log(`   SKU: ${data.filter.sku}`, 'blue');
        log(`   Family: ${data.filter.family}`, 'blue');
        log(`   Duty Level: ${data.filter.duty_level}`, 'blue');
      }
      
      return true;
    } else {
      log('⚠️  Lookup returned non-ok status', 'yellow');
      log(`   Status: ${response.status}`, 'yellow');
      log(`   Message: ${data.message || data.error}`, 'yellow');
      return false;
    }
  } catch (error) {
    log(`❌ Lookup endpoint ERROR: ${error.message}`, 'red');
    return false;
  }
}

async function testSearchEndpoint() {
  log('\n🧪 Test 3: Search Endpoint (GET)', 'cyan');
  
  const testCode = 'CA123'; // Código de prueba
  
  try {
    const response = await fetch(`${BASE_URL}/api/v1/filters/search?code=${testCode}`);
    const data = await response.json();
    
    if (response.ok) {
      log('✅ Search endpoint PASSED', 'green');
      log(`   Code: ${testCode}`, 'blue');
      log(`   Success: ${data.success}`, 'blue');
      log(`   Processed by: ${data.processed_by || 'N/A'}`, 'blue');
      
      if (data.filter) {
        log(`   SKU: ${data.filter.sku}`, 'blue');
        log(`   Family: ${data.filter.family}`, 'blue');
        log(`   Duty Level: ${data.filter.duty_level}`, 'blue');
      }
      
      return true;
    } else {
      log('⚠️  Search returned non-ok status', 'yellow');
      log(`   Status: ${response.status}`, 'yellow');
      log(`   Message: ${data.message || data.error}`, 'yellow');
      return false;
    }
  } catch (error) {
    log(`❌ Search endpoint ERROR: ${error.message}`, 'red');
    return false;
  }
}

async function testInvalidCode() {
  log('\n🧪 Test 4: Invalid Code Handling', 'cyan');
  
  const testCode = 'INVALID_CODE_XYZ123';
  
  try {
    const response = await fetch(`${BASE_URL}/api/v1/filters/lookup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ code: testCode })
    });
    
    const data = await response.json();
    
    if (response.status === 404 || !data.success) {
      log('✅ Invalid code handling PASSED', 'green');
      log(`   Correctly returned error for invalid code`, 'blue');
      return true;
    } else {
      log('⚠️  Invalid code should return error', 'yellow');
      return false;
    }
  } catch (error) {
    log(`❌ Invalid code test ERROR: ${error.message}`, 'red');
    return false;
  }
}

async function testRateLimiting() {
  log('\n🧪 Test 5: Rate Limiting', 'cyan');
  
  try {
    log('   Sending 10 rapid requests...', 'blue');
    
    const requests = [];
    for (let i = 0; i < 10; i++) {
      requests.push(
        fetch(`${BASE_URL}/health`)
      );
    }
    
    const responses = await Promise.all(requests);
    const allSuccess = responses.every(r => r.ok);
    
    if (allSuccess) {
      log('✅ Rate limiting allows normal traffic', 'green');
      log(`   All 10 requests succeeded`, 'blue');
      return true;
    } else {
      const failedCount = responses.filter(r => !r.ok).length;
      log(`⚠️  ${failedCount} requests were rate limited`, 'yellow');
      return true; // Esto es esperado si hay rate limiting
    }
  } catch (error) {
    log(`❌ Rate limiting test ERROR: ${error.message}`, 'red');
    return false;
  }
}

async function testResponseTime() {
  log('\n🧪 Test 6: Response Time', 'cyan');
  
  const testCode = 'P552100';
  
  try {
    const start = Date.now();
    
    const response = await fetch(`${BASE_URL}/api/v1/filters/lookup`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ code: testCode })
    });
    
    const end = Date.now();
    const responseTime = end - start;
    
    await response.json();
    
    if (responseTime < 200) {
      log('✅ Response time EXCELLENT', 'green');
      log(`   Response time: ${responseTime}ms`, 'blue');
      return true;
    } else if (responseTime < 500) {
      log('✅ Response time GOOD', 'green');
      log(`   Response time: ${responseTime}ms`, 'blue');
      return true;
    } else {
      log('⚠️  Response time SLOW', 'yellow');
      log(`   Response time: ${responseTime}ms`, 'yellow');
      return false;
    }
  } catch (error) {
    log(`❌ Response time test ERROR: ${error.message}`, 'red');
    return false;
  }
}

// ============================================================================
// RUNNER
// ============================================================================

async function runAllTests() {
  log('\n═══════════════════════════════════════════════════════', 'cyan');
  log('   ELIMFILTERS Local API - Test Suite', 'cyan');
  log('═══════════════════════════════════════════════════════', 'cyan');
  log(`\n🎯 Testing API at: ${BASE_URL}`, 'blue');
  
  const results = [];
  
  results.push(await testHealthEndpoint());
  results.push(await testLookupEndpoint());
  results.push(await testSearchEndpoint());
  results.push(await testInvalidCode());
  results.push(await testRateLimiting());
  results.push(await testResponseTime());
  
  // Resumen
  const passed = results.filter(r => r === true).length;
  const total = results.length;
  const percentage = Math.round((passed / total) * 100);
  
  log('\n═══════════════════════════════════════════════════════', 'cyan');
  log('   TEST RESULTS', 'cyan');
  log('═══════════════════════════════════════════════════════', 'cyan');
  
  if (percentage === 100) {
    log(`\n✅ ALL TESTS PASSED: ${passed}/${total} (${percentage}%)`, 'green');
  } else if (percentage >= 80) {
    log(`\n⚠️  MOST TESTS PASSED: ${passed}/${total} (${percentage}%)`, 'yellow');
  } else {
    log(`\n❌ MANY TESTS FAILED: ${passed}/${total} (${percentage}%)`, 'red');
  }
  
  log('\n═══════════════════════════════════════════════════════\n', 'cyan');
  
  process.exit(percentage === 100 ? 0 : 1);
}

// ============================================================================
// EJEMPLOS DE USO
// ============================================================================

if (require.main === module) {
  // Script ejecutado directamente
  runAllTests().catch(error => {
    log(`\n❌ Fatal error: ${error.message}`, 'red');
    process.exit(1);
  });
}

// ============================================================================
// INSTRUCCIONES
// ============================================================================

/*

CÓMO USAR ESTE SCRIPT:

1. LOCAL (servidor corriendo en localhost:3000):
   node test.js

2. PRODUCCIÓN (Railway o cualquier URL):
   API_URL=https://tu-app.railway.app node test.js

3. PUERTO PERSONALIZADO:
   API_URL=http://localhost:5000 node test.js

SALIDAS:
- Exit code 0: Todos los tests pasaron
- Exit code 1: Algunos tests fallaron

INTEGRACIÓN CON CI/CD:
Puedes usar este script en GitHub Actions, Railway, etc:

  - name: Run Tests
    run: |
      npm start &
      sleep 5
      npm test

*/

module.exports = {
  testHealthEndpoint,
  testLookupEndpoint,
  testSearchEndpoint,
  testInvalidCode,
  testRateLimiting,
  testResponseTime,
  runAllTests
};
