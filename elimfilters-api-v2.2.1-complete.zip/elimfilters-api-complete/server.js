require('dotenv').config();

const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const fs = require('fs');
const path = require('path');

// Importar módulos locales para procesamiento
const businessLogic = require('./businessLogic-v2.2');

const app = express();

// Trust proxy - necesario en Railway
app.set('trust proxy', 1);

// CORS y JSON
app.use(cors());
app.use(express.json());

// Rate limiter
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => req.ip || 'unknown',
});
app.use(limiter);

// ============================================================================
// CARGAR REGLAS MAESTRAS v2.2.0 AL INICIO
// ============================================================================
let REGLAS_MAESTRAS = null;

function loadMasterRules() {
  try {
    const rulesPath = path.join(__dirname, 'config', 'REGLAS_MAESTRAS.json');
    const rulesContent = fs.readFileSync(rulesPath, 'utf8');
    REGLAS_MAESTRAS = JSON.parse(rulesContent);
    console.log('✅ Reglas maestras cargadas correctamente');
    console.log(`📋 Versión: ${REGLAS_MAESTRAS.version}`);
    console.log(`📅 Fecha: ${REGLAS_MAESTRAS.timestamp}`);
    return true;
  } catch (error) {
    console.error('❌ Error cargando reglas maestras:', error);
    return false;
  }
}

// Cargar reglas al iniciar
loadMasterRules();

// ============================================================================
// PROCESAMIENTO LOCAL DE FILTROS CON REGLAS v2.2.0
// ============================================================================

/**
 * Procesa la búsqueda de filtro usando las reglas locales v2.2.0
 */
async function processFilterLocally(queryCode) {
  try {
    // 1. Normalizar código de búsqueda
    const normalizedCode = String(queryCode).toUpperCase().trim();
    
    console.log(`\n${'='.repeat(60)}`);
    console.log(`[LOCAL v2.2.0] Procesando código: ${normalizedCode}`);
    console.log('='.repeat(60));

    // 2. Buscar en base de datos (esto necesitarías conectar a Google Sheets o tu DB)
    const filterData = await searchInDatabase(normalizedCode);
    
    if (!filterData) {
      console.log(`[LOCAL] ❌ Código ${normalizedCode} no encontrado en base de datos`);
      return {
        success: false,
        message: 'Código no encontrado en base de datos',
        code: normalizedCode,
        timestamp: new Date().toISOString()
      };
    }

    console.log(`[LOCAL] ✓ Filtro encontrado en base de datos`);

    // 3. Validar integridad de datos
    try {
      businessLogic.validateMasterDataIntegrity(filterData);
      console.log(`[LOCAL] ✓ Datos íntegros`);
    } catch (validationError) {
      console.error(`[LOCAL] ❌ Datos incompletos:`, validationError.message);
      return {
        success: false,
        error: 'Datos incompletos en base de datos',
        details: validationError.message,
        code: normalizedCode
      };
    }

    // 4. Generar SKU si no existe o está vacío
    let skuGenerated = false;
    let baseCodeUsed = null;
    let prefixUsed = null;
    let last4Used = null;

    if (!filterData.sku || filterData.sku.trim() === '') {
      console.log(`[LOCAL] Generando SKU según reglas v2.2.0...`);
      
      try {
        // REGLA 2 o 3: Obtener base code según duty
        baseCodeUsed = businessLogic.applyBaseCodeLogic(
          filterData.duty_level,
          filterData.family,
          filterData.oemCodes || [],
          filterData.crossReference || [],
          REGLAS_MAESTRAS.oem_universe.search_order
        );
        
        console.log(`[LOCAL] ✓ Base code seleccionado: ${baseCodeUsed}`);
        
        // REGLA 1: Obtener prefix según tipo
        prefixUsed = businessLogic.getElimfiltersPrefix(
          filterData.family,
          filterData.duty_level,
          REGLAS_MAESTRAS.prefixes
        );
        
        console.log(`[LOCAL] ✓ Prefix determinado: ${prefixUsed}`);
        
        // Extraer últimos 4 dígitos
        last4Used = businessLogic.extractLast4Digits(baseCodeUsed);
        
        console.log(`[LOCAL] ✓ Últimos 4 dígitos: ${last4Used}`);
        
        // REGLA 4: Generar SKU (FORMATO v2.2.0: SIN GUIONES)
        filterData.sku = businessLogic.generateSKU(prefixUsed, last4Used);
        
        skuGenerated = true;
        console.log(`[LOCAL] ✅ SKU generado: ${filterData.sku}`);
        
        // REGLA 5: Validar SKU
        const validation = businessLogic.validateSKU(
          filterData.sku,
          prefixUsed,
          last4Used,
          filterData.duty_level
        );
        
        if (!validation.valid) {
          console.warn(`[LOCAL] ⚠️ SKU generado con advertencias: ${validation.errors.join(', ')}`);
        } else {
          console.log(`[LOCAL] ✓ SKU validado correctamente`);
        }
        
      } catch (skuError) {
        console.error(`[LOCAL] ❌ Error generando SKU:`, skuError.message);
        return {
          success: false,
          error: 'Error generando SKU',
          details: skuError.message,
          code: normalizedCode,
          filter_data: filterData
        };
      }
    } else {
      console.log(`[LOCAL] ✓ SKU ya existe: ${filterData.sku}`);
    }

    // 5. Preparar respuesta
    const response = {
      success: true,
      code: normalizedCode,
      filter: {
        sku: filterData.sku,
        family: filterData.family,
        duty_level: filterData.duty_level,
        specs: filterData.specs,
        oem_codes: filterData.oemCodes || [],
        cross_reference: filterData.crossReference || [],
        validated: true
      },
      sku_info: {
        was_generated: skuGenerated,
        base_code_used: baseCodeUsed,
        prefix_used: prefixUsed,
        last_4_digits: last4Used,
        format: 'v2.2.0 (sin guiones)'
      },
      rules_version: REGLAS_MAESTRAS?.version || 'unknown',
      rules_date: REGLAS_MAESTRAS?.timestamp || 'unknown',
      processed_by: 'railway-local-v2.2.0',
      timestamp: new Date().toISOString()
    };

    console.log(`[LOCAL] ✅ Procesamiento completado exitosamente`);
    console.log('='.repeat(60));
    
    return response;

  } catch (error) {
    console.error('[LOCAL] ❌ Error crítico procesando filtro:', error);
    console.log('='.repeat(60));
    return {
      success: false,
      error: error.message,
      code: queryCode,
      timestamp: new Date().toISOString()
    };
  }
}

/**
 * Simula búsqueda en base de datos
 * AQUÍ DEBERÍAS CONECTAR A GOOGLE SHEETS O TU BASE DE DATOS REAL
 */
async function searchInDatabase(code) {
  console.log(`[DB] Buscando en base de datos: ${code}`);
  
  // MOCK DATA - REEMPLAZAR CON CONEXIÓN REAL A GOOGLE SHEETS
  // Ejemplos según reglas v2.2.0
  const mockDatabase = {
    // Ejemplo HD con Donaldson
    'P552100': {
      sku: '', // Vacío para que se genere automáticamente
      family: 'OIL',
      duty_level: 'HD',
      specs: 'Oil Filter HD',
      oemCodes: ['51515'],
      crossReference: ['P552100', 'LF3620', '1R0739']
      // Resultado esperado: EL82100 (sin guiones)
    },
    
    // Ejemplo HD sin Donaldson
    'LF3620': {
      sku: '',
      family: 'OIL',
      duty_level: 'HD',
      specs: 'Oil Filter HD',
      oemCodes: ['51515'],
      crossReference: ['LF3620', '1R0739']
      // Resultado esperado: EL83620
    },
    
    // Ejemplo LD con FRAM
    'CA10234': {
      sku: '',
      family: 'OIL',
      duty_level: 'LD',
      specs: 'Oil Filter LD',
      oemCodes: ['88922'],
      crossReference: ['CA10234', 'PH8A']
      // Resultado esperado: EL80234
    },
    
    // Ejemplo LD sin FRAM
    '88922': {
      sku: '',
      family: 'FUEL',
      duty_level: 'LD',
      specs: 'Fuel Filter LD',
      oemCodes: ['88922'],
      crossReference: ['88922', 'LF3000']
      // Resultado esperado: EF98922
    },
    
    // Ejemplo con SKU ya existente
    'EXISTING': {
      sku: 'EA15507',
      family: 'AIRE',
      duty_level: 'HD',
      specs: 'Air Filter HD',
      oemCodes: ['12345'],
      crossReference: ['P555507', 'AF25667']
    }
  };

  const result = mockDatabase[code] || null;
  
  if (result) {
    console.log(`[DB] ✓ Encontrado en mock database`);
  } else {
    console.log(`[DB] ✗ No encontrado en mock database`);
  }
  
  return result;
}

// ============================================================================
// NORMALIZACIÓN DE INPUT
// ============================================================================

function buildQueryPayload(req) {
  const candidate =
    (req.body && (req.body.code || req.body.sku || req.body.oem || req.body.query)) ||
    (req.query && (req.query.code || req.query.sku || req.query.oem || req.query.query)) ||
    '';

  const cleaned = String(candidate || '').trim();

  return {
    raw_query_used: candidate || '',
    normalized_query_used: cleaned.toUpperCase(),
  };
}

// ============================================================================
// ENDPOINTS
// ============================================================================

// GET /health
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'ELIMFILTERS Local API',
    version: '3.0.0-v2.2.0',
    processing: 'LOCAL (sin n8n)',
    rules_loaded: REGLAS_MAESTRAS !== null,
    rules_version: REGLAS_MAESTRAS?.version || 'N/A',
    rules_date: REGLAS_MAESTRAS?.timestamp || 'N/A',
    sku_format: 'PREFIXNNNN (sin guiones)',
    endpoints: {
      health: 'GET /health',
      lookup: 'POST /api/v1/filters/lookup',
      search: 'GET /api/v1/filters/search',
      reload_rules: 'POST /api/v1/admin/reload-rules'
    },
  });
});

// POST /api/v1/filters/lookup
app.post('/api/v1/filters/lookup', async (req, res) => {
  try {
    console.log('[LOOKUP] Request body:', req.body);
    const queryInfo = buildQueryPayload(req);
    
    if (!queryInfo.normalized_query_used) {
      return res.status(400).json({
        success: false,
        error: 'Código requerido',
        message: 'Debes enviar code, sku, oem o query',
      });
    }

    // Procesar localmente con reglas v2.2.0
    const result = await processFilterLocally(queryInfo.normalized_query_used);

    res.status(result.success ? 200 : 404).json({
      ...result,
      query_info: queryInfo,
      source: 'POST /api/v1/filters/lookup (LOCAL v2.2.0)',
    });

  } catch (err) {
    console.error('[LOOKUP] Error:', err);
    res.status(500).json({
      success: false,
      source: 'POST /api/v1/filters/lookup',
      error: err.message || 'Lookup internal error',
    });
  }
});

// GET /api/v1/filters/search
app.get('/api/v1/filters/search', async (req, res) => {
  try {
    console.log('[SEARCH] Query params:', req.query);
    const queryInfo = buildQueryPayload(req);
    
    if (!queryInfo.normalized_query_used) {
      return res.status(400).json({
        success: false,
        error: 'Código requerido',
        message: 'Debes enviar code, sku, oem o query como query parameter',
      });
    }

    // Procesar localmente con reglas v2.2.0
    const result = await processFilterLocally(queryInfo.normalized_query_used);

    res.status(result.success ? 200 : 404).json({
      ...result,
      query_info: queryInfo,
      source: 'GET /api/v1/filters/search (LOCAL v2.2.0)',
    });

  } catch (err) {
    console.error('[SEARCH] Error:', err);
    res.status(500).json({
      success: false,
      source: 'GET /api/v1/filters/search',
      error: err.message || 'Search internal error',
    });
  }
});

// POST /api/v1/admin/reload-rules - Recargar reglas sin reiniciar servidor
app.post('/api/v1/admin/reload-rules', (req, res) => {
  try {
    const success = loadMasterRules();
    
    if (success) {
      res.json({
        success: true,
        message: 'Reglas recargadas exitosamente',
        version: REGLAS_MAESTRAS?.version,
        date: REGLAS_MAESTRAS?.timestamp,
        timestamp: new Date().toISOString()
      });
    } else {
      res.status(500).json({
        success: false,
        message: 'Error recargando reglas',
      });
    }
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Manejo de errores global
app.use((err, req, res, next) => {
  console.error('[ERROR GLOBAL]:', err);
  res.status(500).json({
    success: false,
    error: 'Internal server error',
    message: err.message,
  });
});

// ============================================================================
// ARRANQUE SERVIDOR
// ============================================================================

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('');
  console.log('═══════════════════════════════════════════════════════');
  console.log('✅ ELIMFILTERS Local API v3.0.0 - REGLAS v2.2.0');
  console.log('═══════════════════════════════════════════════════════');
  console.log(`🚀 Escuchando en puerto ${PORT}`);
  console.log('📊 Health: GET /health');
  console.log('🔎 Lookup: POST /api/v1/filters/lookup');
  console.log('🔍 Search: GET /api/v1/filters/search');
  console.log('🔄 Reload: POST /api/v1/admin/reload-rules');
  console.log('');
  console.log('🎯 Procesamiento: LOCAL (sin n8n)');
  console.log(`📋 Reglas: ${REGLAS_MAESTRAS ? 'Cargadas ✓' : 'ERROR ✗'}`);
  if (REGLAS_MAESTRAS) {
    console.log(`📌 Versión reglas: ${REGLAS_MAESTRAS.version}`);
    console.log(`📅 Fecha reglas: ${REGLAS_MAESTRAS.timestamp}`);
    console.log(`🏷️  Formato SKU: PREFIXNNNN (sin guiones)`);
  }
  console.log('═══════════════════════════════════════════════════════');
  console.log('');
});
