// businessLogic.js
// Lógica de negocio para determinación de niveles de servicio
// ACTUALIZADO CON REGLAS v2.2.0 - SKU SIN GUIONES

function determineDutyLevel(family, specs, oemCodes, crossReference, rawData) {
    // Validar que rawData existe
    if (!rawData) {
        throw new Error('rawData no fue proporcionado. La clasificación de Duty Level requiere data maestra.');
    }
    
    // Si la data maestra ya trae duty_level, ÚSALO
    if (rawData.duty_level && rawData.duty_level.trim() !== '') {
        return rawData.duty_level;
    }
    
    // Si el duty_level está vacío o no existe, fallar explícitamente
    throw new Error(
        `Clasificación de Duty Level no definida en la base de datos maestra para SKU: ${rawData.sku || 'desconocido'}`
    );
}

function validateMasterDataIntegrity(rawData) {
    // Validar que todos los campos críticos existan en la data maestra
    const requiredFields = ['duty_level', 'sku', 'family', 'specs'];
    
    const missingFields = requiredFields.filter(field => 
        !rawData[field] || (typeof rawData[field] === 'string' && rawData[field].trim() === '')
    );
    
    if (missingFields.length > 0) {
        throw new Error(
            `Campos críticos faltantes en data maestra: ${missingFields.join(', ')}`
        );
    }
    
    return true;
}

function processFilterData(family, specs, oemCodes, crossReference, rawData) {
    // Validar integridad de data maestra primero
    validateMasterDataIntegrity(rawData);
    
    // Obtener duty level desde data maestra validada
    const dutyLevel = determineDutyLevel(family, specs, oemCodes, crossReference, rawData);
    
    return {
        sku: rawData.sku,
        family: rawData.family,
        specs: rawData.specs,
        duty_level: dutyLevel,
        crossReference: crossReference,
        oemCodes: oemCodes,
        validated: true,
        timestamp: new Date().toISOString()
    };
}

// ============================================================================
// REGLAS v2.2.0 - SKU ELIMFILTERS (SIN GUIONES)
// ============================================================================

/**
 * Obtener prefijo según TIPO usando el nuevo mapping de v2.2.0
 * REGLA 1: Determinación de Prefijo
 */
function getElimfiltersPrefix(family, duty, prefixesMapping) {
    // Normalizar entrada
    const familyUpper = String(family).toUpperCase().trim();
    const dutyUpper = String(duty).toUpperCase().trim();
    
    console.log(`[PREFIX] Buscando prefijo para: ${familyUpper} / ${dutyUpper}`);
    
    // Si se proporciona el mapping completo, usarlo
    if (prefixesMapping && prefixesMapping.mapping) {
        // Buscar coincidencia exacta primero
        if (prefixesMapping.mapping[familyUpper]) {
            const prefixData = prefixesMapping.mapping[familyUpper];
            
            // Verificar si el duty es compatible
            if (prefixData.duty.includes(dutyUpper)) {
                console.log(`[PREFIX] ✓ Encontrado: ${prefixData.prefix} para ${familyUpper}`);
                return prefixData.prefix;
            } else {
                console.warn(`[PREFIX] Duty ${dutyUpper} no compatible con ${familyUpper}. Duties válidos: ${prefixData.duty.join(', ')}`);
            }
        }
        
        // Buscar en aliases
        for (const [tipo, data] of Object.entries(prefixesMapping.mapping)) {
            if (data.aliases && data.aliases.includes(familyUpper)) {
                if (data.duty.includes(dutyUpper)) {
                    console.log(`[PREFIX] ✓ Encontrado por alias: ${data.prefix} para ${familyUpper} (${tipo})`);
                    return data.prefix;
                }
            }
        }
    }
    
    // Fallback a mapping estático si no hay mapping proporcionado
    const staticPrefixMap = {
        'AIRE': 'EA1',
        'AIR': 'EA1',
        'FUEL': 'EF9',
        'COMBUSTIBLE': 'EF9',
        'OIL': 'EL8',
        'ACEITE': 'EL8',
        'CABIN': 'EC1',
        'CABIN AIR': 'EC1',
        'AIRE CABINA': 'EC1',
        'FUEL SEPARATOR': 'ES9',
        'SEPARADOR': 'ES9',
        'AIR DRYER': 'ED4',
        'HIDRAULIC': 'EH6',
        'HYDRAULIC': 'EH6',
        'COOLANT': 'EW7',
        'REFRIGERANTE': 'EW7',
        'CARCAZA AIR FILTER': 'EA3',
        'HOUSING': 'EA3',
        'TURBINE SERIES': 'ET9',
        'TURBINA': 'ET9',
        'KITS SERIES HD': 'EK5',
        'KIT DIESEL': 'EK5',
        'KITS SERIES LD': 'EK3',
        'KIT GAS': 'EK3',
        'KIT PASAJEROS': 'EK3'
    };
    
    if (staticPrefixMap[familyUpper]) {
        console.log(`[PREFIX] ✓ Encontrado en fallback: ${staticPrefixMap[familyUpper]}`);
        return staticPrefixMap[familyUpper];
    }
    
    // Fallback genérico
    console.warn(`[PREFIX] ⚠ Familia no encontrada: ${familyUpper}. Usando fallback genérico ELM`);
    return 'ELM';
}

/**
 * Aplicar lógica de base code según reglas v2.2.0
 * 
 * REGLA 2 (HD): Buscar DONALDSON primero (patrón P\d{5,6}), luego OEM más comercial
 * REGLA 3 (LD): Buscar FRAM primero (patrón (PH|CA|CF|CH)\d{3,6}), luego OEM más comercial
 */
function applyBaseCodeLogic(duty, family, oemCodes, crossReference, searchOrderRules) {
    const dutyUpper = String(duty).toUpperCase().trim();
    
    console.log(`[BASE_CODE] Procesando ${dutyUpper}...`);
    console.log(`[BASE_CODE] Cross references: ${JSON.stringify(crossReference)}`);
    console.log(`[BASE_CODE] OEM codes: ${JSON.stringify(oemCodes)}`);
    
    /**
     * Buscar código por patrón regex
     */
    function findByPattern(codes, pattern) {
        if (!codes || !Array.isArray(codes) || codes.length === 0) return null;
        
        try {
            // Convertir string de patrón a RegExp
            const regex = new RegExp(pattern, 'i');
            
            const found = codes.find(code => {
                const codeStr = String(code).trim();
                return regex.test(codeStr);
            });
            
            return found || null;
        } catch (error) {
            console.error(`[BASE_CODE] Error en patrón ${pattern}:`, error);
            return null;
        }
    }
    
    /**
     * Ejecutar los steps del search order
     */
    function executeSearchSteps(steps) {
        for (const step of steps) {
            console.log(`[BASE_CODE] Step ${step.step}: ${step.description}`);
            
            let sourceData = null;
            if (step.source === 'cross_reference') {
                sourceData = crossReference;
            } else if (step.source === 'oem_codes') {
                sourceData = oemCodes;
            }
            
            if (!sourceData || sourceData.length === 0) {
                console.log(`[BASE_CODE] Step ${step.step}: No hay datos en ${step.source}`);
                continue;
            }
            
            // Si tiene patrón específico (Donaldson o FRAM)
            if (step.pattern && step.target !== 'generic') {
                const found = findByPattern(sourceData, step.pattern);
                if (found) {
                    console.log(`[BASE_CODE] ✓ Step ${step.step}: Encontrado ${found} con patrón ${step.pattern}`);
                    return found;
                } else {
                    console.log(`[BASE_CODE] Step ${step.step}: No se encontró código con patrón ${step.pattern}`);
                }
            } 
            // Si es generic, usar el primer código disponible (OEM más comercial)
            else if (step.target === 'generic') {
                const firstCode = sourceData[0];
                console.log(`[BASE_CODE] ✓ Step ${step.step}: Usando primer código (OEM más comercial): ${firstCode}`);
                return firstCode;
            }
        }
        
        return null;
    }
    
    // Si hay reglas de search order proporcionadas, usarlas
    if (searchOrderRules && searchOrderRules[dutyUpper]) {
        const steps = searchOrderRules[dutyUpper].steps;
        const selectedCode = executeSearchSteps(steps);
        
        if (selectedCode) {
            console.log(`[BASE_CODE] Código final seleccionado: ${selectedCode}`);
            return selectedCode;
        }
    }
    
    // Fallback: lógica simplificada si no hay search order rules
    console.log(`[BASE_CODE] Usando lógica fallback...`);
    
    let selectedCode = null;
    
    if (dutyUpper === 'HD') {
        // HD: Buscar Donaldson primero (P + números)
        selectedCode = findByPattern(crossReference, 'P\\d{5,6}') ||
                      findByPattern(oemCodes, 'P\\d{5,6}') ||
                      (crossReference && crossReference.length > 0 ? crossReference[0] : null) ||
                      (oemCodes && oemCodes.length > 0 ? oemCodes[0] : null);
    } else if (dutyUpper === 'LD') {
        // LD: Buscar FRAM primero (PH, CA, CF, CH)
        selectedCode = findByPattern(crossReference, '(PH|CA|CF|CH)\\d{3,6}') ||
                      findByPattern(oemCodes, '(PH|CA|CF|CH)\\d{3,6}') ||
                      (crossReference && crossReference.length > 0 ? crossReference[0] : null) ||
                      (oemCodes && oemCodes.length > 0 ? oemCodes[0] : null);
    } else {
        // Duty desconocido, usar primer código disponible
        selectedCode = (crossReference && crossReference.length > 0) ? crossReference[0] : 
                      (oemCodes && oemCodes.length > 0) ? oemCodes[0] : null;
    }
    
    if (!selectedCode) {
        throw new Error('No se encontró ningún código válido en referencias OEM o cross-reference');
    }
    
    console.log(`[BASE_CODE] Código seleccionado (fallback): ${selectedCode}`);
    return selectedCode;
}

/**
 * Extraer últimos 4 dígitos de un código
 * REGLA 2 & 3: Paso 6 y 7
 */
function extractLast4Digits(code) {
    if (!code) {
        throw new Error('Código vacío para extraer dígitos');
    }
    
    // Extraer solo números
    const numbers = String(code).replace(/[^0-9]/g, '');
    
    if (numbers.length === 0) {
        throw new Error(`No se encontraron dígitos en el código: ${code}`);
    }
    
    // Obtener últimos 4 dígitos (o menos si no hay suficientes)
    const last4 = numbers.slice(-4);
    
    // Si tiene menos de 4 dígitos, rellenar con ceros a la izquierda
    const paddedLast4 = last4.padStart(4, '0');
    
    console.log(`[EXTRACT] Código: ${code} → Números: ${numbers} → Últimos 4: ${paddedLast4}`);
    return paddedLast4;
}

/**
 * Generar SKU según REGLA 4 de v2.2.0
 * Formato: PREFIXNNNN (SIN GUIONES)
 */
function generateSKU(prefix, last4Digits) {
    // Validar inputs
    if (!prefix || prefix.trim() === '') {
        throw new Error('Prefix vacío');
    }
    
    if (!last4Digits || last4Digits.length !== 4) {
        throw new Error(`Base code debe tener exactamente 4 dígitos. Recibido: ${last4Digits}`);
    }
    
    // Formato v2.2.0: PREFIXNNNN (sin guiones)
    const sku = `${prefix}${last4Digits}`;
    
    console.log(`[SKU] Generado: ${prefix} + ${last4Digits} = ${sku}`);
    return sku;
}

/**
 * Validar SKU generado según REGLA 5
 */
function validateSKU(sku, prefix, basecode, duty) {
    const errors = [];
    
    // Validar formato
    if (!sku || typeof sku !== 'string') {
        errors.push('SKU debe ser un string válido');
    }
    
    // Validar que comienza con el prefix
    if (!sku.startsWith(prefix)) {
        errors.push(`SKU debe comenzar con prefix ${prefix}`);
    }
    
    // Validar que basecode son 4 dígitos numéricos
    if (!/^\d{4}$/.test(basecode)) {
        errors.push('Base code debe tener exactamente 4 dígitos numéricos');
    }
    
    // Validar duty level
    if (!['HD', 'LD'].includes(duty.toUpperCase())) {
        errors.push('Duty level debe ser HD o LD');
    }
    
    // Validar longitud del SKU (prefix típicamente 3 chars + 4 dígitos = 7)
    if (sku.length < 6 || sku.length > 9) {
        errors.push('Longitud de SKU fuera de rango esperado (6-9 caracteres)');
    }
    
    if (errors.length > 0) {
        console.warn(`[VALIDATION] Errores encontrados: ${errors.join(', ')}`);
        return {
            valid: false,
            errors: errors
        };
    }
    
    console.log(`[VALIDATION] ✓ SKU válido: ${sku}`);
    return {
        valid: true,
        errors: []
    };
}

// ============================================================================
// EXPORTACIONES (CommonJS)
// ============================================================================
module.exports = {
    determineDutyLevel,
    validateMasterDataIntegrity,
    processFilterData,
    getElimfiltersPrefix,
    applyBaseCodeLogic,
    extractLast4Digits,
    generateSKU,
    validateSKU
};
