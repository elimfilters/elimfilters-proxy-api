# Changelog

Todos los cambios notables de este proyecto serán documentados en este archivo.

El formato está basado en [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
y este proyecto adhiere a [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [2.2.1] - 2025-10-28

### ✨ Agregado
- **Tecnologías ELIMFILTERS**: Integración de ELIMTEK™, MAXFLOW™, MICROKAPPA™
- **Validador de tecnologías**: `elimfiltersTechnology.js` con auto-asignación
- **32 columnas**: Especificaciones técnicas completas en Google Sheet
- **Archivos TSV**: Headers y ejemplos para importación rápida
- **Scripts de migración**: `migrate-add-columns.js` para agregar columnas sin perder datos
- **Detección de competidores**: Validación que rechaza marcas de otros fabricantes
- **Documentación ampliada**: Guías para TSV, columnas y tecnologías

### 🔧 Cambiado
- **Columna R (Filter_Media)**: Ahora usa ELIMTEK/MAXFLOW/MICROKAPPA en lugar de términos genéricos
- **setup-google-sheet.js**: Actualizado con 4 ejemplos usando tecnologías ELIMFILTERS
- **Specs_Summary**: Ahora incluye tecnología (ej: "with ELIMTEK™ Technology")
- **package.json**: Versión actualizada a 2.2.1

### 🚫 Eliminado
- Referencias a tecnologías de competidores (Powercore, Synteq, etc.)
- Términos genéricos como "Cellulose", "Synthetic" en columna Filter_Media

### 📝 Documentación
- Nueva guía: `COLUMNAS_ELIMFILTERS_ACTUALIZADO.md`
- Nueva guía: `GUIA_COPIAR_TSV.md`
- Nueva guía: `ARCHIVOS_AJUSTADOS_RESUMEN.md`
- Actualizado: README.md con sección de tecnologías ELIMFILTERS

---

## [2.2.0] - 2025-10-27

### ✨ Agregado
- **Reglas v2.2.0**: Sistema de generación de SKUs completamente rediseñado
- **5 reglas principales**: OIL+HD, FUEL+LD, AIRE+HD, CABIN+LD, FUEL SEPARATOR+HD
- **businessLogic-v2.2.js**: Implementación de nuevas reglas
- **Tabla de decisión**: Sistema robusto de mapeo Family+Duty → Prefix
- **Script de migración**: `migration-v2.1-to-v2.2.js` para actualizar SKUs existentes
- **Tests**: Suite de tests automatizados con 6 casos de prueba
- **Documentación**: EJEMPLOS_VISUALES_v2.2.0.md con diagramas paso a paso

### 🔧 Cambiado
- **Generación de prefijos**: Ahora basada en combinación Family+Duty
- **Formato de SKU**: Sin guiones, formato compacto (ej: EL82100)
- **Extracción de dígitos**: Mejorada para manejar códigos alfanuméricos complejos

### 📝 Documentación
- Nueva guía: `CAMBIOS_v2.1_a_v2.2.md`
- Nueva guía: `EJEMPLOS_VISUALES_v2.2.0.md`
- Actualizado: README con ejemplos de reglas v2.2.0

---

## [2.1.0] - 2025-10-26

### ✨ Agregado
- **Sistema inicial**: Primera versión funcional del sistema de SKUs
- **Reglas v2.1.0**: Sistema básico de generación
- **Integración Google Sheets**: Lectura de catálogo desde Google Sheets
- **API REST**: Endpoint /lookup para búsqueda de filtros
- **Cache**: Sistema de caché para optimizar consultas
- **Servidor Express**: API REST con Express.js

### 📝 Documentación
- Documentación inicial del proyecto
- Guía de credenciales de Google Cloud

---

## [2.0.0] - 2025-10-25

### ✨ Agregado
- Setup inicial del proyecto
- Estructura base de carpetas
- Configuración de dependencias
- Google Sheets API integration

---

## Tipos de Cambios

- **✨ Agregado**: Para nuevas funcionalidades
- **🔧 Cambiado**: Para cambios en funcionalidades existentes
- **🐛 Corregido**: Para corrección de bugs
- **🚫 Eliminado**: Para funcionalidades removidas
- **🔐 Seguridad**: Para cambios relacionados con seguridad
- **📝 Documentación**: Para cambios en documentación

---

## Links

- [v2.2.1]: https://github.com/tu-usuario/elimfilters-api/releases/tag/v2.2.1
- [v2.2.0]: https://github.com/tu-usuario/elimfilters-api/releases/tag/v2.2.0
- [v2.1.0]: https://github.com/tu-usuario/elimfilters-api/releases/tag/v2.1.0
- [v2.0.0]: https://github.com/tu-usuario/elimfilters-api/releases/tag/v2.0.0
