// test-google-sheet.js
// Script para probar la conexión con tu Google Sheet
// Sheet ID: 1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U

require('dotenv').config();
const { google } = require('googleapis');

// ============================================================================
// CONFIGURACIÓN
// ============================================================================

const SHEET_ID = '1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U';

// Colores para consola
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

// ============================================================================
// FUNCIONES DE PRUEBA
// ============================================================================

async function testConnection() {
  log('\n╔════════════════════════════════════════════════════════╗', 'cyan');
  log('║  TEST: Conexión con Google Sheet                      ║', 'cyan');
  log('╚════════════════════════════════════════════════════════╝', 'cyan');
  
  // 1. Verificar variables de entorno
  log('\n📋 PASO 1: Verificar variables de entorno', 'blue');
  
  if (!process.env.GOOGLE_CREDENTIALS) {
    log('❌ ERROR: GOOGLE_CREDENTIALS no configurado', 'red');
    log('   Debes configurar la variable en tu archivo .env', 'yellow');
    return false;
  }
  log('✅ GOOGLE_CREDENTIALS encontrado', 'green');
  
  // 2. Parsear credenciales
  log('\n📋 PASO 2: Validar credenciales JSON', 'blue');
  let credentials;
  try {
    credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
    log('✅ JSON de credenciales válido', 'green');
    log(`   Project ID: ${credentials.project_id}`, 'blue');
    log(`   Email: ${credentials.client_email}`, 'blue');
  } catch (error) {
    log('❌ ERROR: Credenciales JSON inválidas', 'red');
    log(`   ${error.message}`, 'yellow');
    return false;
  }
  
  // 3. Autenticar con Google
  log('\n📋 PASO 3: Autenticar con Google', 'blue');
  let auth;
  try {
    auth = new google.auth.GoogleAuth({
      credentials: credentials,
      scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly']
    });
    const authClient = await auth.getClient();
    log('✅ Autenticación exitosa', 'green');
  } catch (error) {
    log('❌ ERROR en autenticación', 'red');
    log(`   ${error.message}`, 'yellow');
    return false;
  }
  
  // 4. Conectar a Sheets API
  log('\n📋 PASO 4: Conectar a Google Sheets API', 'blue');
  let sheets;
  try {
    sheets = google.sheets({ version: 'v4', auth });
    log('✅ Conexión a API establecida', 'green');
  } catch (error) {
    log('❌ ERROR conectando a API', 'red');
    log(`   ${error.message}`, 'yellow');
    return false;
  }
  
  // 5. Leer metadata del Sheet
  log('\n📋 PASO 5: Leer información del Sheet', 'blue');
  log(`   Sheet ID: ${SHEET_ID}`, 'cyan');
  
  try {
    const metadata = await sheets.spreadsheets.get({
      spreadsheetId: SHEET_ID
    });
    
    log('✅ Sheet encontrado', 'green');
    log(`   Título: ${metadata.data.properties.title}`, 'blue');
    log(`   Hojas: ${metadata.data.sheets.length}`, 'blue');
    
    // Listar hojas
    log('\n   📄 Hojas disponibles:', 'blue');
    metadata.data.sheets.forEach((sheet, index) => {
      log(`      ${index + 1}. ${sheet.properties.title}`, 'cyan');
    });
    
  } catch (error) {
    log('❌ ERROR leyendo Sheet', 'red');
    log(`   ${error.message}`, 'yellow');
    
    if (error.message.includes('permission')) {
      log('\n   💡 SOLUCIÓN:', 'yellow');
      log('   1. Ir al Google Sheet', 'yellow');
      log('   2. Click en "Compartir"', 'yellow');
      log(`   3. Agregar: ${credentials.client_email}`, 'yellow');
      log('   4. Dar permisos de "Editor"', 'yellow');
    }
    
    return false;
  }
  
  // 6. Leer datos de la primera hoja
  log('\n📋 PASO 6: Leer datos (primeras 5 filas)', 'blue');
  
  try {
    const firstSheet = metadata.data.sheets[0].properties.title;
    const range = `${firstSheet}!A1:F5`; // Primeras 5 filas, 6 columnas
    
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SHEET_ID,
      range: range
    });
    
    const rows = response.data.values;
    
    if (!rows || rows.length === 0) {
      log('⚠️  Sheet vacío o sin datos', 'yellow');
      log('   Agrega datos en las columnas:', 'yellow');
      log('   A=SKU, B=Family, C=Duty, D=Specs, E=OEM, F=Cross', 'yellow');
      return true; // Conexión OK pero sin datos
    }
    
    log('✅ Datos leídos correctamente', 'green');
    log(`   Filas encontradas: ${rows.length}`, 'blue');
    
    // Mostrar estructura
    log('\n   📊 Estructura de datos:', 'blue');
    rows.forEach((row, index) => {
      if (index === 0) {
        log(`      Header: ${row.join(' | ')}`, 'cyan');
      } else if (index <= 2) {
        log(`      Fila ${index}: ${row.join(' | ')}`, 'blue');
      }
    });
    
    if (rows.length > 3) {
      log(`      ... y ${rows.length - 3} filas más`, 'blue');
    }
    
  } catch (error) {
    log('❌ ERROR leyendo datos', 'red');
    log(`   ${error.message}`, 'yellow');
    return false;
  }
  
  // 7. Verificar estructura esperada
  log('\n📋 PASO 7: Verificar estructura de columnas', 'blue');
  
  const expectedHeaders = ['SKU', 'Family', 'Duty', 'Specs', 'OEM', 'Cross'];
  const actualHeaders = rows[0].map(h => h.trim());
  
  log('   Columnas esperadas vs encontradas:', 'blue');
  expectedHeaders.forEach((expected, index) => {
    const actual = actualHeaders[index] || '(vacío)';
    const match = actual.toLowerCase().includes(expected.toLowerCase());
    const icon = match ? '✅' : '⚠️';
    log(`   ${icon} ${expected}: ${actual}`, match ? 'green' : 'yellow');
  });
  
  return true;
}

async function testSearch(code) {
  log('\n╔════════════════════════════════════════════════════════╗', 'cyan');
  log('║  TEST: Búsqueda de Filtro                             ║', 'cyan');
  log('╚════════════════════════════════════════════════════════╝', 'cyan');
  
  log(`\n🔍 Buscando código: ${code}`, 'blue');
  
  try {
    const credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
    const auth = new google.auth.GoogleAuth({
      credentials: credentials,
      scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly']
    });
    
    const sheets = google.sheets({ version: 'v4', auth });
    
    // Leer todos los datos
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: SHEET_ID,
      range: 'A:F' // Todas las filas, columnas A-F
    });
    
    const rows = response.data.values;
    if (!rows || rows.length <= 1) {
      log('❌ No hay datos para buscar', 'red');
      return false;
    }
    
    // Buscar en todas las columnas
    const headerRow = rows[0];
    let found = null;
    
    for (let i = 1; i < rows.length; i++) {
      const row = rows[i];
      
      // Buscar en cada celda de la fila
      for (let j = 0; j < row.length; j++) {
        if (row[j] && row[j].toString().toUpperCase().includes(code.toUpperCase())) {
          found = row;
          break;
        }
      }
      
      if (found) break;
    }
    
    if (found) {
      log('✅ Filtro encontrado!', 'green');
      log('\n   📋 Datos del filtro:', 'blue');
      
      found.forEach((value, index) => {
        const header = headerRow[index] || `Columna ${index + 1}`;
        log(`      ${header}: ${value}`, 'cyan');
      });
      
      return true;
    } else {
      log('❌ Filtro no encontrado', 'yellow');
      log(`   Código buscado: ${code}`, 'yellow');
      log('   Verifica que el código exista en tu Sheet', 'yellow');
      return false;
    }
    
  } catch (error) {
    log('❌ ERROR en búsqueda', 'red');
    log(`   ${error.message}`, 'yellow');
    return false;
  }
}

// ============================================================================
// EJECUCIÓN
// ============================================================================

async function runTests() {
  console.log('\n');
  log('═══════════════════════════════════════════════════════════', 'cyan');
  log('  TEST DE CONEXIÓN: Google Sheet ELIMFILTERS', 'cyan');
  log('═══════════════════════════════════════════════════════════', 'cyan');
  
  log(`\n📊 Sheet ID: ${SHEET_ID}`, 'blue');
  log(`🔗 URL: https://docs.google.com/spreadsheets/d/${SHEET_ID}/edit`, 'blue');
  
  // Test 1: Conexión
  const connectionOk = await testConnection();
  
  if (!connectionOk) {
    log('\n❌ Tests fallidos. Revisa los errores arriba.', 'red');
    process.exit(1);
  }
  
  // Test 2: Búsqueda (si se proporciona código)
  const searchCode = process.argv[2];
  if (searchCode) {
    await testSearch(searchCode);
  } else {
    log('\n💡 TIP: Para probar búsqueda, ejecuta:', 'yellow');
    log('   node test-google-sheet.js P552100', 'cyan');
  }
  
  // Resumen
  log('\n═══════════════════════════════════════════════════════════', 'cyan');
  log('  ✅ TODOS LOS TESTS PASARON', 'green');
  log('═══════════════════════════════════════════════════════════', 'cyan');
  
  log('\n📝 Próximos pasos:', 'blue');
  log('   1. Agregar más datos a tu Google Sheet', 'cyan');
  log('   2. Configurar las mismas variables en Railway', 'cyan');
  log('   3. Desplegar tu código', 'cyan');
  log('   4. ¡Listo para producción!', 'cyan');
  
  console.log('\n');
}

// Ejecutar
runTests().catch(error => {
  log(`\n❌ ERROR FATAL: ${error.message}`, 'red');
  console.error(error);
  process.exit(1);
});
