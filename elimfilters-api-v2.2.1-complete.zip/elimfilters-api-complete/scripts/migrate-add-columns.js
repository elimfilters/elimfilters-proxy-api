// migrate-add-columns.js
// Script para AGREGAR columnas técnicas a un Sheet existente con datos

require('dotenv').config();
const { google } = require('googleapis');

const SHEET_ID = process.env.GOOGLE_SHEETS_ID || '1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U';

// ============================================================================
// COLUMNAS EXISTENTES VS NUEVAS
// ============================================================================

const EXISTING_COLUMNS = ['SKU', 'OEM_Code', 'Family', 'Duty', 'Specs_Summary', 'Cross_Reference'];
const NEW_COLUMNS = [
  // Grupo B: DIMENSIONES FÍSICAS
  'Height_Inches', 'Height_MM', 'Outer_Diameter_Inches', 'Outer_Diameter_MM',
  'Inner_Diameter_Inches', 'Inner_Diameter_MM',
  
  // Grupo C: ROSCA Y SELLO
  'Thread_Size', 'Thread_Type', 'Gasket_OD_Inches', 'Gasket_Type',
  
  // Grupo D: FILTRACIÓN (usar tecnologías ELIMFILTERS)
  'Micron_Rating', 'Filter_Media', 'Filter_Type',
  
  // Grupo E: CAPACIDAD Y FLUJO
  'Flow_Rate_GPM', 'Flow_Rate_LPM', 'Dirt_Capacity_Grams', 'Collapse_PSI',
  
  // Grupo F: APLICACIONES
  'Primary_Application', 'Compatible_Applications', 'OEM_Brands',
  
  // Grupo G: REFERENCIAS
  'Replaces', 'Superseded_By',
  
  // Grupo H: METADATA
  'Notes', 'Stock_Status', 'Created_At', 'Updated_At'
];

// ============================================================================
// FUNCIONES PRINCIPALES
// ============================================================================

async function migrateAddColumns() {
  console.log('\n🔄 INICIANDO MIGRACIÓN: Agregar Columnas Técnicas\n');
  console.log(`📊 Sheet ID: ${SHEET_ID}\n`);
  
  // 1. Autenticar
  console.log('🔐 Autenticando con Google...');
  const auth = await getAuth();
  const sheets = google.sheets({ version: 'v4', auth });
  
  // 2. Verificar Sheet
  console.log('✅ Verificando Sheet...');
  const spreadsheet = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_ID
  });
  console.log(`   Título: "${spreadsheet.data.properties.title}"`);
  
  // 3. Verificar hoja FILTERS
  const filtersSheet = spreadsheet.data.sheets.find(s => s.properties.title === 'FILTERS');
  if (!filtersSheet) {
    console.log('❌ No se encontró hoja "FILTERS"');
    console.log('   Ejecuta setup-google-sheet.js primero');
    return;
  }
  
  const sheetId = filtersSheet.properties.sheetId;
  console.log(`   Hoja FILTERS encontrada (ID: ${sheetId})`);
  
  // 4. Leer headers actuales
  console.log('\n📋 Leyendo estructura actual...');
  const currentHeaders = await readHeaders(sheets, SHEET_ID);
  console.log(`   Columnas actuales: ${currentHeaders.length}`);
  console.log(`   Headers: ${currentHeaders.join(', ')}`);
  
  // 5. Verificar si ya tiene columnas nuevas
  const hasNewColumns = NEW_COLUMNS.some(col => currentHeaders.includes(col));
  if (hasNewColumns) {
    console.log('\n⚠️  ADVERTENCIA: Ya tienes algunas columnas nuevas');
    console.log('   Recomendación: Ejecuta setup-google-sheet.js para configuración completa');
    
    const proceed = process.argv.includes('--force');
    if (!proceed) {
      console.log('\n   Para continuar de todos modos, usa: --force');
      return;
    }
  }
  
  // 6. Contar filas con datos
  const dataRows = await countDataRows(sheets, SHEET_ID);
  console.log(`\n📊 Filas con datos: ${dataRows}`);
  
  if (dataRows === 0) {
    console.log('\n💡 No hay datos en el Sheet');
    console.log('   Recomendación: Usa setup-google-sheet.js para configuración limpia');
    return;
  }
  
  // 7. Crear backup (opcional)
  if (process.argv.includes('--backup')) {
    console.log('\n💾 Creando backup...');
    await createBackupSheet(sheets, SHEET_ID, sheetId);
  }
  
  // 8. Agregar nuevas columnas
  console.log('\n➕ Agregando columnas nuevas...');
  await addNewColumnHeaders(sheets, SHEET_ID, currentHeaders.length);
  
  // 9. Formatear nuevas columnas
  console.log('🎨 Formateando nuevas columnas...');
  await formatNewColumns(sheets, SHEET_ID, sheetId, currentHeaders.length);
  
  // 10. Agregar timestamps a filas existentes
  console.log('⏰ Agregando timestamps a filas existentes...');
  await addTimestampsToExistingRows(sheets, SHEET_ID, dataRows, currentHeaders.length);
  
  console.log('\n✅ MIGRACIÓN COMPLETADA\n');
  console.log('📋 RESUMEN:');
  console.log(`   Columnas antes: ${currentHeaders.length}`);
  console.log(`   Columnas nuevas: ${NEW_COLUMNS.length}`);
  console.log(`   Total columnas: ${currentHeaders.length + NEW_COLUMNS.length}`);
  console.log(`   Filas migradas: ${dataRows}\n`);
  console.log(`🔗 URL: https://docs.google.com/spreadsheets/d/${SHEET_ID}/edit\n`);
  
  // Siguiente paso
  console.log('📝 SIGUIENTE PASO:');
  console.log('   Ahora puedes agregar especificaciones técnicas');
  console.log('   a tus filtros existentes editando el Sheet\n');
}

// ============================================================================
// FUNCIONES DE SOPORTE
// ============================================================================

async function getAuth() {
  const credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
  const auth = new google.auth.GoogleAuth({
    credentials: credentials,
    scopes: ['https://www.googleapis.com/auth/spreadsheets']
  });
  return await auth.getClient();
}

async function readHeaders(sheets, spreadsheetId) {
  const response = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: 'FILTERS!1:1'
  });
  
  return response.data.values ? response.data.values[0] : [];
}

async function countDataRows(sheets, spreadsheetId) {
  const response = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: 'FILTERS!A:A'
  });
  
  const values = response.data.values || [];
  // Restar 1 por el header
  return Math.max(0, values.length - 1);
}

async function createBackupSheet(sheets, spreadsheetId, originalSheetId) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupName = `FILTERS_BACKUP_${timestamp}`;
  
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId,
    requestBody: {
      requests: [{
        duplicateSheet: {
          sourceSheetId: originalSheetId,
          newSheetName: backupName
        }
      }]
    }
  });
  
  console.log(`   Backup creado: "${backupName}"`);
}

async function addNewColumnHeaders(sheets, spreadsheetId, startColumn) {
  // Convertir índice a letra de columna
  const startLetter = columnIndexToLetter(startColumn);
  const endLetter = columnIndexToLetter(startColumn + NEW_COLUMNS.length - 1);
  const range = `FILTERS!${startLetter}1:${endLetter}1`;
  
  await sheets.spreadsheets.values.update({
    spreadsheetId,
    range: range,
    valueInputOption: 'RAW',
    requestBody: {
      values: [NEW_COLUMNS]
    }
  });
  
  console.log(`   ${NEW_COLUMNS.length} nuevos headers agregados`);
  console.log(`   Rango: ${range}`);
}

async function formatNewColumns(sheets, spreadsheetId, sheetId, startColumn) {
  const requests = [];
  
  // Formatear headers de nuevas columnas (misma apariencia que las existentes)
  requests.push({
    repeatCell: {
      range: {
        sheetId: sheetId,
        startRowIndex: 0,
        endRowIndex: 1,
        startColumnIndex: startColumn,
        endColumnIndex: startColumn + NEW_COLUMNS.length
      },
      cell: {
        userEnteredFormat: {
          backgroundColor: { red: 0.8, green: 0.8, blue: 0.8 },
          textFormat: {
            bold: true,
            fontSize: 10
          },
          horizontalAlignment: 'CENTER'
        }
      },
      fields: 'userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)'
    }
  });
  
  // Ajustar anchos de columnas nuevas
  const widths = {
    'Height_Inches': 120, 'Height_MM': 100,
    'Outer_Diameter_Inches': 150, 'Outer_Diameter_MM': 140,
    'Inner_Diameter_Inches': 150, 'Inner_Diameter_MM': 140,
    'Thread_Size': 100, 'Thread_Type': 100,
    'Gasket_OD_Inches': 130, 'Gasket_Type': 100,
    'Micron_Rating': 110, 'Filter_Media': 110, 'Filter_Type': 100,
    'Flow_Rate_GPM': 120, 'Flow_Rate_LPM': 120,
    'Dirt_Capacity_Grams': 150, 'Collapse_PSI': 110,
    'Primary_Application': 150, 'Compatible_Applications': 200,
    'OEM_Brands': 150, 'Replaces': 150, 'Superseded_By': 120,
    'Notes': 200, 'Stock_Status': 110,
    'Created_At': 150, 'Updated_At': 150
  };
  
  NEW_COLUMNS.forEach((colName, index) => {
    requests.push({
      updateDimensionProperties: {
        range: {
          sheetId: sheetId,
          dimension: 'COLUMNS',
          startIndex: startColumn + index,
          endIndex: startColumn + index + 1
        },
        properties: {
          pixelSize: widths[colName] || 120
        },
        fields: 'pixelSize'
      }
    });
  });
  
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId,
    requestBody: { requests }
  });
  
  console.log('   Formato y anchos aplicados');
}

async function addTimestampsToExistingRows(sheets, spreadsheetId, dataRows, startColumn) {
  if (dataRows === 0) return;
  
  const now = new Date().toISOString();
  
  // Created_At y Updated_At son las últimas 2 columnas
  const createdAtCol = columnIndexToLetter(startColumn + NEW_COLUMNS.length - 2);
  const updatedAtCol = columnIndexToLetter(startColumn + NEW_COLUMNS.length - 1);
  
  // Crear arrays de timestamps
  const timestamps = [];
  for (let i = 0; i < dataRows; i++) {
    timestamps.push([now]);
  }
  
  // Actualizar Created_At
  await sheets.spreadsheets.values.update({
    spreadsheetId,
    range: `FILTERS!${createdAtCol}2:${createdAtCol}${dataRows + 1}`,
    valueInputOption: 'RAW',
    requestBody: {
      values: timestamps
    }
  });
  
  // Actualizar Updated_At
  await sheets.spreadsheets.values.update({
    spreadsheetId,
    range: `FILTERS!${updatedAtCol}2:${updatedAtCol}${dataRows + 1}`,
    valueInputOption: 'RAW',
    requestBody: {
      values: timestamps
    }
  });
  
  console.log(`   Timestamps agregados a ${dataRows} filas`);
}

function columnIndexToLetter(index) {
  let letter = '';
  while (index >= 0) {
    letter = String.fromCharCode((index % 26) + 65) + letter;
    index = Math.floor(index / 26) - 1;
  }
  return letter;
}

// ============================================================================
// EJECUCIÓN
// ============================================================================

console.log(`
╔════════════════════════════════════════════════════════════╗
║  MIGRACIÓN: Agregar Columnas Técnicas                     ║
║                                                            ║
║  Este script agrega columnas técnicas nuevas sin          ║
║  perder los datos existentes en tu Google Sheet.          ║
╚════════════════════════════════════════════════════════════╝
`);

// Verificar flags
if (process.argv.includes('--help')) {
  console.log(`
USO: node migrate-add-columns.js [opciones]

OPCIONES:
  --backup    Crear backup del Sheet antes de migrar
  --force     Continuar aunque ya existan algunas columnas nuevas
  --help      Mostrar esta ayuda

EJEMPLOS:
  # Migración simple
  node migrate-add-columns.js

  # Con backup
  node migrate-add-columns.js --backup

  # Forzar migración
  node migrate-add-columns.js --force --backup
`);
  process.exit(0);
}

migrateAddColumns()
  .then(() => {
    console.log('✅ Script completado exitosamente\n');
    process.exit(0);
  })
  .catch(error => {
    console.error('\n❌ ERROR:', error.message);
    console.error(error);
    process.exit(1);
  });
