// setup-google-sheet.js
// Script para inicializar/configurar Google Sheet con estructura completa (32 columnas)

require('dotenv').config();
const { google } = require('googleapis');

const SHEET_ID = process.env.GOOGLE_SHEETS_ID || '1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U';

// ============================================================================
// DEFINICIÓN DE COLUMNAS COMPLETAS
// ============================================================================

const COLUMNS = [
  // Grupo A: IDENTIFICACIÓN (A-F)
  { letter: 'A', name: 'SKU', width: 100, required: true, description: 'SKU ELIMFILTERS generado' },
  { letter: 'B', name: 'OEM_Code', width: 120, required: true, description: 'Código OEM principal' },
  { letter: 'C', name: 'Family', width: 120, required: true, description: 'Tipo de filtro' },
  { letter: 'D', name: 'Duty', width: 60, required: true, description: 'HD o LD' },
  { letter: 'E', name: 'Specs_Summary', width: 250, required: false, description: 'Descripción breve' },
  { letter: 'F', name: 'Cross_Reference', width: 200, required: false, description: 'Códigos compatibles' },
  
  // Grupo B: DIMENSIONES FÍSICAS (G-L)
  { letter: 'G', name: 'Height_Inches', width: 120, required: false, description: 'Altura en pulgadas' },
  { letter: 'H', name: 'Height_MM', width: 100, required: false, description: 'Altura en mm (auto)' },
  { letter: 'I', name: 'Outer_Diameter_Inches', width: 150, required: false, description: 'Diámetro ext. pulgadas' },
  { letter: 'J', name: 'Outer_Diameter_MM', width: 140, required: false, description: 'Diámetro ext. mm (auto)' },
  { letter: 'K', name: 'Inner_Diameter_Inches', width: 150, required: false, description: 'Diámetro int. pulgadas' },
  { letter: 'L', name: 'Inner_Diameter_MM', width: 140, required: false, description: 'Diámetro int. mm (auto)' },
  
  // Grupo C: ROSCA Y SELLO (M-P)
  { letter: 'M', name: 'Thread_Size', width: 100, required: false, description: 'Tamaño de rosca' },
  { letter: 'N', name: 'Thread_Type', width: 100, required: false, description: 'Tipo de rosca' },
  { letter: 'O', name: 'Gasket_OD_Inches', width: 130, required: false, description: 'Diámetro empaque' },
  { letter: 'P', name: 'Gasket_Type', width: 100, required: false, description: 'Tipo de empaque' },
  
  // Grupo D: FILTRACIÓN (Q-S)
  { letter: 'Q', name: 'Micron_Rating', width: 110, required: false, description: 'Micronaje' },
  { letter: 'R', name: 'Filter_Media', width: 130, required: false, description: 'ELIMTEK/MAXFLOW/MICROKAPPA/Standard' },
  { letter: 'S', name: 'Filter_Type', width: 100, required: false, description: 'Tipo de filtro' },
  
  // Grupo E: CAPACIDAD Y FLUJO (T-W)
  { letter: 'T', name: 'Flow_Rate_GPM', width: 120, required: false, description: 'Flujo GPM' },
  { letter: 'U', name: 'Flow_Rate_LPM', width: 120, required: false, description: 'Flujo LPM (auto)' },
  { letter: 'V', name: 'Dirt_Capacity_Grams', width: 150, required: false, description: 'Capacidad suciedad' },
  { letter: 'W', name: 'Collapse_PSI', width: 110, required: false, description: 'Presión colapso' },
  
  // Grupo F: APLICACIONES (X-Z)
  { letter: 'X', name: 'Primary_Application', width: 150, required: false, description: 'Aplicación principal' },
  { letter: 'Y', name: 'Compatible_Applications', width: 200, required: false, description: 'Aplicaciones compatibles' },
  { letter: 'Z', name: 'OEM_Brands', width: 150, required: false, description: 'Marcas OEM' },
  
  // Grupo G: REFERENCIAS (AA-AB)
  { letter: 'AA', name: 'Replaces', width: 150, required: false, description: 'Códigos que reemplaza' },
  { letter: 'AB', name: 'Superseded_By', width: 120, required: false, description: 'Reemplazado por' },
  
  // Grupo H: METADATA (AC-AF)
  { letter: 'AC', name: 'Notes', width: 200, required: false, description: 'Notas especiales' },
  { letter: 'AD', name: 'Stock_Status', width: 110, required: false, description: 'Estado de stock' },
  { letter: 'AE', name: 'Created_At', width: 150, required: true, description: 'Fecha creación' },
  { letter: 'AF', name: 'Updated_At', width: 150, required: true, description: 'Fecha actualización' }
];

// ============================================================================
// COLORES Y ESTILOS
// ============================================================================

const COLORS = {
  header: { red: 0.8, green: 0.8, blue: 0.8 }, // Gris
  required: { red: 1, green: 1, blue: 0.8 }, // Amarillo claro
  autoCalculated: { red: 0.8, green: 0.9, blue: 1 }, // Azul claro
  normal: { red: 1, green: 1, blue: 1 } // Blanco
};

// ============================================================================
// FUNCIONES PRINCIPALES
// ============================================================================

async function setupGoogleSheet() {
  console.log('\n🚀 INICIANDO CONFIGURACIÓN DE GOOGLE SHEET\n');
  console.log(`📊 Sheet ID: ${SHEET_ID}\n`);
  
  // 1. Autenticar
  console.log('🔐 Autenticando con Google...');
  const auth = await getAuth();
  const sheets = google.sheets({ version: 'v4', auth });
  
  // 2. Verificar acceso al Sheet
  console.log('✅ Verificando acceso al Sheet...');
  const spreadsheet = await sheets.spreadsheets.get({
    spreadsheetId: SHEET_ID
  });
  console.log(`   Título: "${spreadsheet.data.properties.title}"`);
  
  // 3. Obtener o crear hoja "FILTERS"
  console.log('\n📄 Configurando hoja "FILTERS"...');
  const sheetId = await getOrCreateSheet(sheets, SHEET_ID, 'FILTERS');
  
  // 4. Escribir headers
  console.log('📝 Escribiendo headers (fila 1)...');
  await writeHeaders(sheets, SHEET_ID);
  
  // 5. Formatear headers
  console.log('🎨 Formateando headers...');
  await formatHeaders(sheets, SHEET_ID, sheetId);
  
  // 6. Ajustar anchos de columnas
  console.log('📐 Ajustando anchos de columnas...');
  await setColumnWidths(sheets, SHEET_ID, sheetId);
  
  // 7. Aplicar colores a columnas especiales
  console.log('🎨 Aplicando colores especiales...');
  await applyColumnColors(sheets, SHEET_ID, sheetId);
  
  // 8. Congelar primera fila
  console.log('❄️  Congelando primera fila...');
  await freezeFirstRow(sheets, SHEET_ID, sheetId);
  
  // 9. Agregar filtros de prueba (opcional)
  const addSamples = process.argv.includes('--samples');
  if (addSamples) {
    console.log('\n📦 Agregando filtros de prueba...');
    await addSampleData(sheets, SHEET_ID);
  }
  
  console.log('\n✅ CONFIGURACIÓN COMPLETADA\n');
  console.log('🎉 Tu Google Sheet está listo con 32 columnas\n');
  console.log(`🔗 URL: https://docs.google.com/spreadsheets/d/${SHEET_ID}/edit\n`);
  
  // Resumen
  console.log('📋 RESUMEN DE COLUMNAS:');
  console.log('   Total: 32 columnas (A-AF)');
  console.log('   Obligatorias: 6 (A, B, C, D, AE, AF)');
  console.log('   Auto-calculadas: 5 (H, J, L, U, AE, AF)');
  console.log('   Opcionales: 21\n');
}

// ============================================================================
// FUNCIONES DE SOPORTE
// ============================================================================

async function getAuth() {
  const credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
  const auth = new google.auth.GoogleAuth({
    credentials: credentials,
    scopes: ['https://www.googleapis.com/auth/spreadsheets']
  });
  return await auth.getClient();
}

async function getOrCreateSheet(sheets, spreadsheetId, sheetName) {
  const spreadsheet = await sheets.spreadsheets.get({ spreadsheetId });
  const sheet = spreadsheet.data.sheets.find(s => s.properties.title === sheetName);
  
  if (sheet) {
    console.log(`   Hoja "${sheetName}" encontrada (ID: ${sheet.properties.sheetId})`);
    return sheet.properties.sheetId;
  }
  
  // Crear nueva hoja
  console.log(`   Creando nueva hoja "${sheetName}"...`);
  const response = await sheets.spreadsheets.batchUpdate({
    spreadsheetId,
    requestBody: {
      requests: [{
        addSheet: {
          properties: {
            title: sheetName,
            gridProperties: {
              rowCount: 1000,
              columnCount: 32,
              frozenRowCount: 1
            }
          }
        }
      }]
    }
  });
  
  return response.data.replies[0].addSheet.properties.sheetId;
}

async function writeHeaders(sheets, spreadsheetId) {
  const headers = COLUMNS.map(col => col.name);
  
  await sheets.spreadsheets.values.update({
    spreadsheetId,
    range: 'FILTERS!A1:AF1',
    valueInputOption: 'RAW',
    requestBody: {
      values: [headers]
    }
  });
  
  console.log(`   ${headers.length} headers escritos`);
}

async function formatHeaders(sheets, spreadsheetId, sheetId) {
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId,
    requestBody: {
      requests: [
        {
          repeatCell: {
            range: {
              sheetId: sheetId,
              startRowIndex: 0,
              endRowIndex: 1,
              startColumnIndex: 0,
              endColumnIndex: 32
            },
            cell: {
              userEnteredFormat: {
                backgroundColor: COLORS.header,
                textFormat: {
                  bold: true,
                  fontSize: 10
                },
                horizontalAlignment: 'CENTER'
              }
            },
            fields: 'userEnteredFormat(backgroundColor,textFormat,horizontalAlignment)'
          }
        }
      ]
    }
  });
  
  console.log('   Headers formateados (gris + negrita)');
}

async function setColumnWidths(sheets, spreadsheetId, sheetId) {
  const requests = COLUMNS.map((col, index) => ({
    updateDimensionProperties: {
      range: {
        sheetId: sheetId,
        dimension: 'COLUMNS',
        startIndex: index,
        endIndex: index + 1
      },
      properties: {
        pixelSize: col.width
      },
      fields: 'pixelSize'
    }
  }));
  
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId,
    requestBody: { requests }
  });
  
  console.log(`   ${requests.length} anchos de columna ajustados`);
}

async function applyColumnColors(sheets, spreadsheetId, sheetId) {
  const requests = [];
  
  // Columnas obligatorias (A-D, AE-AF) - Amarillo claro
  const requiredColumns = [0, 1, 2, 3, 30, 31]; // A, B, C, D, AE, AF
  requiredColumns.forEach(colIndex => {
    requests.push({
      repeatCell: {
        range: {
          sheetId: sheetId,
          startRowIndex: 1,
          endRowIndex: 1000,
          startColumnIndex: colIndex,
          endColumnIndex: colIndex + 1
        },
        cell: {
          userEnteredFormat: {
            backgroundColor: COLORS.required
          }
        },
        fields: 'userEnteredFormat.backgroundColor'
      }
    });
  });
  
  // Columnas auto-calculadas (H, J, L, U) - Azul claro
  const autoColumns = [7, 9, 11, 20]; // H, J, L, U
  autoColumns.forEach(colIndex => {
    requests.push({
      repeatCell: {
        range: {
          sheetId: sheetId,
          startRowIndex: 1,
          endRowIndex: 1000,
          startColumnIndex: colIndex,
          endColumnIndex: colIndex + 1
        },
        cell: {
          userEnteredFormat: {
            backgroundColor: COLORS.autoCalculated
          }
        },
        fields: 'userEnteredFormat.backgroundColor'
      }
    });
  });
  
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId,
    requestBody: { requests }
  });
  
  console.log('   Colores aplicados:');
  console.log('      Amarillo claro: Columnas obligatorias');
  console.log('      Azul claro: Columnas auto-calculadas');
}

async function freezeFirstRow(sheets, spreadsheetId, sheetId) {
  await sheets.spreadsheets.batchUpdate({
    spreadsheetId,
    requestBody: {
      requests: [{
        updateSheetProperties: {
          properties: {
            sheetId: sheetId,
            gridProperties: {
              frozenRowCount: 1
            }
          },
          fields: 'gridProperties.frozenRowCount'
        }
      }]
    }
  });
  
  console.log('   Primera fila congelada');
}

async function addSampleData(sheets, spreadsheetId) {
  const samples = [
    [
      'EL89000', 'P559000', 'OIL', 'HD', 
      'Oil Filter Heavy Duty Spin-on with ELIMTEK™ Technology',
      'P550949, DBL7900, LF3620, 1R0739',
      '5.0', '127.0', '3.75', '95.25', '1.5', '38.1',
      '3/4-16', 'UNF', '2.5', 'Nitrile',
      '10', 'ELIMTEK', 'Spin-on',
      '8.5', '32.2', '45', '40',
      'CAT 3406E', 'CAT 3406B, CAT 3406C, CAT C15',
      'CATERPILLAR, DONALDSON, BALDWIN',
      'P551315, P550148', '',
      'ELIMTEK™ technology ensures 99.99% efficiency in extreme conditions',
      'In Stock',
      new Date().toISOString(),
      new Date().toISOString()
    ],
    [
      'EL80949', 'P550949', 'OIL', 'HD',
      'Oil Filter Heavy Duty Spin-on Compact with ELIMTEK™',
      'P559000, DBL7900, LF3620',
      '4.5', '114.3', '3.5', '88.9', '1.5', '38.1',
      '3/4-16', 'UNF', '2.5', 'Nitrile',
      '15', 'ELIMTEK', 'Spin-on',
      '7.0', '26.5', '35', '35',
      'CAT 3406E', 'CAT 3406B, CAT 3406C',
      'CATERPILLAR, DONALDSON',
      '', '',
      'Compact version with ELIMTEK™ liquid filtration technology',
      'In Stock',
      new Date().toISOString(),
      new Date().toISOString()
    ],
    [
      'EA11080', 'P181080', 'AIRE', 'HD',
      'Air Filter Heavy Duty Panel with MAXFLOW™ Technology',
      'AF25667, 555507',
      '14.5', '368.3', '5.25', '133.35', '', '',
      '', 'None', '', '',
      '10', 'MAXFLOW', 'Panel',
      '', '', '750', '',
      'CAT 3406E', 'CAT C15, CAT C15 ACERT',
      'CATERPILLAR, DONALDSON',
      'P606119, CA256', '',
      'MAXFLOW™ technology provides up to 10,000 km on-road protection',
      'In Stock',
      new Date().toISOString(),
      new Date().toISOString()
    ],
    [
      'EC10456', '87139-07010', 'CABIN', 'LD',
      'Cabin Air Filter with MICROKAPPA™ Multilayer Technology',
      'CF10456',
      '1.5', '38.1', '8.5', '215.9', '', '',
      '', 'None', '', '',
      '5', 'MICROKAPPA', 'Panel',
      '', '', '', '',
      'Toyota Hilux 2015-2020', 'Toyota Fortuner 2015-2020',
      'TOYOTA',
      '', '',
      'MICROKAPPA™ with activated carbon captures ultra-fine particles and harmful gases',
      'In Stock',
      new Date().toISOString(),
      new Date().toISOString()
    ]
  ];
  
  await sheets.spreadsheets.values.append({
    spreadsheetId,
    range: 'FILTERS!A2',
    valueInputOption: 'RAW',
    requestBody: {
      values: samples
    }
  });
  
  console.log(`   ${samples.length} filtros de prueba agregados`);
  console.log('   - 2 Oil Filters HD con ELIMTEK™');
  console.log('   - 1 Air Filter HD con MAXFLOW™');
  console.log('   - 1 Cabin Filter LD con MICROKAPPA™');
}

// ============================================================================
// EJECUCIÓN
// ============================================================================

setupGoogleSheet()
  .then(() => {
    console.log('✅ Script completado exitosamente\n');
    process.exit(0);
  })
  .catch(error => {
    console.error('\n❌ ERROR:', error.message);
    console.error(error);
    process.exit(1);
  });
