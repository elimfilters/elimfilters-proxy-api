#!/usr/bin/env node

// migration-v2.1-to-v2.2.js
// Script para migrar SKUs de formato v2.1.0 (con guiones) a v2.2.0 (sin guiones)

const fs = require('fs');
const path = require('path');

// Colores para consola
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  magenta: '\x1b[35m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

// ============================================================================
// FUNCIONES DE MIGRACIÓN
// ============================================================================

/**
 * Convierte un SKU de v2.1.0 a v2.2.0
 * Ejemplo: "EL8-2100" → "EL82100"
 */
function migrateSKU(oldSKU) {
  if (!oldSKU || typeof oldSKU !== 'string') {
    return null;
  }
  
  // Remover guiones
  const newSKU = oldSKU.replace(/-/g, '');
  
  return newSKU;
}

/**
 * Valida que el SKU migrado es correcto
 */
function validateMigratedSKU(oldSKU, newSKU) {
  // Verificar que el nuevo SKU no tiene guiones
  if (newSKU.includes('-')) {
    return {
      valid: false,
      error: 'El SKU migrado aún contiene guiones'
    };
  }
  
  // Verificar que tiene el formato correcto: 3 letras + 4 números
  const pattern = /^[A-Z]{3}\d{4}$/i;
  if (!pattern.test(newSKU)) {
    return {
      valid: false,
      error: 'El SKU migrado no tiene el formato correcto (debe ser PREFIXNNNN)'
    };
  }
  
  // Verificar que el contenido es el mismo (sin el guión)
  const oldWithoutDash = oldSKU.replace(/-/g, '');
  if (oldWithoutDash !== newSKU) {
    return {
      valid: false,
      error: 'El contenido del SKU cambió durante la migración'
    };
  }
  
  return {
    valid: true,
    error: null
  };
}

/**
 * Migra un array de SKUs
 */
function migrateSKUArray(skus) {
  const results = {
    total: skus.length,
    migrated: 0,
    unchanged: 0,
    errors: 0,
    details: []
  };
  
  for (const oldSKU of skus) {
    if (!oldSKU.includes('-')) {
      // Ya está en formato v2.2.0
      results.unchanged++;
      results.details.push({
        old: oldSKU,
        new: oldSKU,
        status: 'unchanged',
        message: 'Ya está en formato v2.2.0'
      });
      continue;
    }
    
    const newSKU = migrateSKU(oldSKU);
    const validation = validateMigratedSKU(oldSKU, newSKU);
    
    if (validation.valid) {
      results.migrated++;
      results.details.push({
        old: oldSKU,
        new: newSKU,
        status: 'success',
        message: 'Migrado exitosamente'
      });
    } else {
      results.errors++;
      results.details.push({
        old: oldSKU,
        new: newSKU,
        status: 'error',
        message: validation.error
      });
    }
  }
  
  return results;
}

/**
 * Genera SQL para actualizar base de datos
 */
function generateSQL(migrations, tableName = 'filters', columnName = 'sku') {
  const statements = [];
  
  for (const migration of migrations) {
    if (migration.status === 'success') {
      statements.push(
        `UPDATE ${tableName} SET ${columnName} = '${migration.new}' WHERE ${columnName} = '${migration.old}';`
      );
    }
  }
  
  return statements.join('\n');
}

/**
 * Genera script para Google Sheets
 */
function generateGoogleSheetsScript(migrations) {
  const updates = migrations
    .filter(m => m.status === 'success')
    .map(m => `  replaceInColumn('${m.old}', '${m.new}');`)
    .join('\n');
  
  return `
function migrateSkus() {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var range = sheet.getDataRange();
  var values = range.getValues();
  
  function replaceInColumn(oldValue, newValue) {
    for (var i = 0; i < values.length; i++) {
      for (var j = 0; j < values[i].length; j++) {
        if (values[i][j] === oldValue) {
          sheet.getRange(i + 1, j + 1).setValue(newValue);
          Logger.log('Migrado: ' + oldValue + ' → ' + newValue);
        }
      }
    }
  }
  
${updates}
  
  Logger.log('Migración completada');
}
`;
}

// ============================================================================
// MODO INTERACTIVO
// ============================================================================

function runInteractiveMode() {
  log('\n╔════════════════════════════════════════════════════════╗', 'cyan');
  log('║  MIGRACIÓN v2.1.0 → v2.2.0 - ELIMFILTERS SKU         ║', 'cyan');
  log('╚════════════════════════════════════════════════════════╝', 'cyan');
  
  log('\n📋 Este script te ayudará a migrar tus SKUs', 'blue');
  log('   Formato anterior: EL8-2100 (con guión)', 'yellow');
  log('   Formato nuevo:    EL82100  (sin guión)\n', 'green');
  
  // Ejemplos de SKUs para probar
  const exampleSKUs = [
    'EL8-2100',
    'EF9-5507',
    'EA1-0234',
    'ES9-1313',
    'EK5-1329',
    'EC1-4567',
    'EL82100',  // Ya en formato v2.2.0
    'INVALID-SKU-123'
  ];
  
  log('🧪 Probando con SKUs de ejemplo...', 'cyan');
  const results = migrateSKUArray(exampleSKUs);
  
  log('\n📊 RESULTADOS:', 'magenta');
  log(`   Total:      ${results.total}`, 'blue');
  log(`   Migrados:   ${results.migrated}`, 'green');
  log(`   Sin cambio: ${results.unchanged}`, 'yellow');
  log(`   Errores:    ${results.errors}`, 'red');
  
  log('\n📝 DETALLES:', 'magenta');
  for (const detail of results.details) {
    const icon = detail.status === 'success' ? '✅' : 
                 detail.status === 'unchanged' ? '➡️' : '❌';
    const color = detail.status === 'success' ? 'green' : 
                  detail.status === 'unchanged' ? 'yellow' : 'red';
    
    log(`   ${icon} ${detail.old} → ${detail.new}`, color);
    log(`      ${detail.message}`, 'blue');
  }
  
  // Generar SQL
  log('\n📄 SQL GENERADO:', 'magenta');
  const sql = generateSQL(results.details);
  log(sql || '   (ninguna migración necesaria)', 'yellow');
  
  // Generar script de Google Sheets
  log('\n📄 SCRIPT GOOGLE SHEETS:', 'magenta');
  const gsScript = generateGoogleSheetsScript(results.details);
  if (results.migrated > 0) {
    log('   Ver archivo: migration-google-sheets.js', 'yellow');
    fs.writeFileSync('migration-google-sheets.js', gsScript);
    log('   ✅ Archivo creado', 'green');
  } else {
    log('   (ninguna migración necesaria)', 'yellow');
  }
  
  // Guardar SQL
  if (sql) {
    fs.writeFileSync('migration.sql', sql);
    log('\n✅ Archivo SQL guardado: migration.sql', 'green');
  }
  
  log('\n════════════════════════════════════════════════════════\n', 'cyan');
}

// ============================================================================
// MODO ARCHIVO
// ============================================================================

function runFileMode(inputFile, outputFile) {
  log('\n🔄 Procesando archivo...', 'cyan');
  
  try {
    // Leer archivo
    const content = fs.readFileSync(inputFile, 'utf8');
    const skus = content.split('\n').map(line => line.trim()).filter(line => line);
    
    log(`   📁 Archivo: ${inputFile}`, 'blue');
    log(`   📊 SKUs encontrados: ${skus.length}`, 'blue');
    
    // Migrar
    const results = migrateSKUArray(skus);
    
    // Guardar resultados
    const output = results.details
      .map(d => `${d.old},${d.new},${d.status},${d.message}`)
      .join('\n');
    
    const header = 'old_sku,new_sku,status,message\n';
    fs.writeFileSync(outputFile, header + output);
    
    log(`\n✅ Resultados guardados en: ${outputFile}`, 'green');
    log(`   Migrados:   ${results.migrated}`, 'green');
    log(`   Sin cambio: ${results.unchanged}`, 'yellow');
    log(`   Errores:    ${results.errors}`, 'red');
    
  } catch (error) {
    log(`\n❌ Error: ${error.message}`, 'red');
  }
}

// ============================================================================
// EXPORTACIONES PARA USO PROGRAMÁTICO
// ============================================================================

module.exports = {
  migrateSKU,
  validateMigratedSKU,
  migrateSKUArray,
  generateSQL,
  generateGoogleSheetsScript
};

// ============================================================================
// EJECUCIÓN
// ============================================================================

if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    // Modo interactivo
    runInteractiveMode();
  } else if (args.length === 2) {
    // Modo archivo
    const [inputFile, outputFile] = args;
    runFileMode(inputFile, outputFile);
  } else {
    log('\n📖 USO:', 'yellow');
    log('   node migration-v2.1-to-v2.2.js', 'cyan');
    log('   (modo interactivo con ejemplos)\n', 'blue');
    log('   node migration-v2.1-to-v2.2.js input.txt output.csv', 'cyan');
    log('   (procesar archivo de SKUs)\n', 'blue');
  }
}

// ============================================================================
// INSTRUCCIONES DE USO
// ============================================================================

/*

INSTRUCCIONES DE USO:

1. MODO INTERACTIVO (recomendado para probar):
   node migration-v2.1-to-v2.2.js
   
   Esto generará:
   - Ejemplo de migraciones
   - Archivo migration.sql
   - Archivo migration-google-sheets.js

2. MODO ARCHIVO (para procesar lote de SKUs):
   
   a) Crear archivo input.txt con un SKU por línea:
      EL8-2100
      EF9-5507
      EA1-0234
   
   b) Ejecutar:
      node migration-v2.1-to-v2.2.js input.txt output.csv
   
   c) Revisar output.csv con los resultados

3. MIGRACIÓN EN BASE DE DATOS:
   
   a) Ejecutar el script en modo interactivo o archivo
   b) Revisar el archivo migration.sql generado
   c) Aplicar en tu base de datos:
      mysql -u user -p database < migration.sql
      # o
      psql -U user -d database -f migration.sql

4. MIGRACIÓN EN GOOGLE SHEETS:
   
   a) Ejecutar el script
   b) Abrir el archivo migration-google-sheets.js generado
   c) Copiar el contenido
   d) En Google Sheets: Extensiones → Apps Script
   e) Pegar el código
   f) Ejecutar la función migrateSkus()

5. USO PROGRAMÁTICO:
   
   const { migrateSKU } = require('./migration-v2.1-to-v2.2');
   
   const oldSKU = 'EL8-2100';
   const newSKU = migrateSKU(oldSKU);
   console.log(newSKU); // "EL82100"

NOTAS:
- El script NO modifica datos directamente, solo genera scripts
- Siempre haz backup antes de aplicar cambios
- Prueba primero en ambiente de desarrollo
- Los SKUs ya en formato v2.2.0 no se modifican

*/
