// googleSheetsIntegration.js
// Ejemplo de cómo conectar el procesamiento local con Google Sheets

const { google } = require('googleapis');

class GoogleSheetsDB {
  constructor() {
    this.sheets = null;
    this.spreadsheetId = process.env.GOOGLE_SHEETS_ID;
    this.initialized = false;
  }

  /**
   * Inicializar conexión con Google Sheets
   */
  async initialize() {
    try {
      // Opción 1: Usar Service Account (Recomendado para Railway)
      const credentials = JSON.parse(process.env.GOOGLE_CREDENTIALS);
      
      const auth = new google.auth.GoogleAuth({
        credentials,
        scopes: ['https://www.googleapis.com/auth/spreadsheets.readonly'],
      });

      this.sheets = google.sheets({ version: 'v4', auth });
      this.initialized = true;
      
      console.log('✅ Google Sheets conectado exitosamente');
      return true;

    } catch (error) {
      console.error('❌ Error inicializando Google Sheets:', error);
      this.initialized = false;
      return false;
    }
  }

  /**
   * Buscar un filtro por código OEM en Google Sheets
   * @param {string} code - Código OEM a buscar
   * @returns {Object|null} - Datos del filtro o null si no se encuentra
   */
  async searchByCode(code) {
    if (!this.initialized) {
      await this.initialize();
    }

    try {
      const normalizedCode = String(code).toUpperCase().trim();
      console.log(`[Google Sheets] Buscando código: ${normalizedCode}`);

      // Leer datos de la hoja
      const response = await this.sheets.spreadsheets.values.get({
        spreadsheetId: this.spreadsheetId,
        range: 'FILTROS!A2:Z', // Ajusta según tu estructura
      });

      const rows = response.data.values;
      
      if (!rows || rows.length === 0) {
        console.log('[Google Sheets] No se encontraron datos');
        return null;
      }

      // Buscar el código en las filas
      // Asumiendo estructura:
      // [0]=SKU, [1]=FAMILY, [2]=DUTY_LEVEL, [3]=SPECS, [4]=OEM_CODES, [5]=CROSS_REFERENCE
      const foundRow = rows.find(row => {
        const oemCodes = row[4] ? String(row[4]).toUpperCase() : '';
        const crossRef = row[5] ? String(row[5]).toUpperCase() : '';
        
        return oemCodes.includes(normalizedCode) || 
               crossRef.includes(normalizedCode) ||
               (row[0] && String(row[0]).toUpperCase() === normalizedCode);
      });

      if (!foundRow) {
        console.log(`[Google Sheets] Código ${normalizedCode} no encontrado`);
        return null;
      }

      // Parsear los códigos OEM y cross-reference (separados por comas)
      const oemCodesArray = foundRow[4] 
        ? String(foundRow[4]).split(',').map(c => c.trim()) 
        : [];
      
      const crossReferenceArray = foundRow[5] 
        ? String(foundRow[5]).split(',').map(c => c.trim()) 
        : [];

      // Retornar en el formato esperado
      const filterData = {
        sku: foundRow[0] || '',
        family: foundRow[1] || '',
        duty_level: foundRow[2] || '',
        specs: foundRow[3] || '',
        oemCodes: oemCodesArray,
        crossReference: crossReferenceArray,
        source: 'google_sheets',
        timestamp: new Date().toISOString()
      };

      console.log(`[Google Sheets] ✅ Filtro encontrado: ${filterData.sku}`);
      return filterData;

    } catch (error) {
      console.error('[Google Sheets] Error en búsqueda:', error);
      throw error;
    }
  }

  /**
   * Buscar múltiples códigos en batch (más eficiente)
   */
  async searchBatch(codes) {
    if (!this.initialized) {
      await this.initialize();
    }

    try {
      const normalizedCodes = codes.map(c => String(c).toUpperCase().trim());
      console.log(`[Google Sheets] Búsqueda en batch: ${normalizedCodes.length} códigos`);

      const response = await this.sheets.spreadsheets.values.get({
        spreadsheetId: this.spreadsheetId,
        range: 'FILTROS!A2:Z',
      });

      const rows = response.data.values;
      const results = [];

      for (const code of normalizedCodes) {
        const foundRow = rows.find(row => {
          const oemCodes = row[4] ? String(row[4]).toUpperCase() : '';
          const crossRef = row[5] ? String(row[5]).toUpperCase() : '';
          
          return oemCodes.includes(code) || 
                 crossRef.includes(code) ||
                 (row[0] && String(row[0]).toUpperCase() === code);
        });

        if (foundRow) {
          results.push({
            code,
            found: true,
            data: {
              sku: foundRow[0] || '',
              family: foundRow[1] || '',
              duty_level: foundRow[2] || '',
              specs: foundRow[3] || '',
              oemCodes: foundRow[4] ? String(foundRow[4]).split(',').map(c => c.trim()) : [],
              crossReference: foundRow[5] ? String(foundRow[5]).split(',').map(c => c.trim()) : []
            }
          });
        } else {
          results.push({
            code,
            found: false,
            data: null
          });
        }
      }

      return results;

    } catch (error) {
      console.error('[Google Sheets] Error en búsqueda batch:', error);
      throw error;
    }
  }

  /**
   * Cache simple para reducir llamadas a Google Sheets
   */
  createCache() {
    const cache = new Map();
    const CACHE_TTL = 5 * 60 * 1000; // 5 minutos

    return {
      get: (key) => {
        const item = cache.get(key);
        if (!item) return null;
        
        if (Date.now() - item.timestamp > CACHE_TTL) {
          cache.delete(key);
          return null;
        }
        
        return item.data;
      },
      set: (key, data) => {
        cache.set(key, {
          data,
          timestamp: Date.now()
        });
      },
      clear: () => cache.clear(),
      size: () => cache.size
    };
  }
}

// ============================================================================
// FUNCIÓN HELPER PARA USAR EN server.js
// ============================================================================

// Instancia única con cache
const sheetsDB = new GoogleSheetsDB();
const cache = sheetsDB.createCache();

/**
 * Búsqueda con cache automático
 */
async function searchWithCache(code) {
  // Revisar cache primero
  const cached = cache.get(code);
  if (cached) {
    console.log(`[Cache] HIT para código: ${code}`);
    return cached;
  }

  // Si no está en cache, buscar en Google Sheets
  console.log(`[Cache] MISS para código: ${code}`);
  const result = await sheetsDB.searchByCode(code);
  
  // Guardar en cache
  if (result) {
    cache.set(code, result);
  }

  return result;
}

/**
 * Función para usar directamente en server.js
 */
async function searchInDatabase(code) {
  try {
    return await searchWithCache(code);
  } catch (error) {
    console.error('[Database] Error:', error);
    return null;
  }
}

// ============================================================================
// EJEMPLO DE USO EN server.js
// ============================================================================

/*

// En server.js, reemplazar la función searchInDatabase con:

const googleSheets = require('./googleSheetsIntegration');

async function processFilterLocally(queryCode) {
  // ...código existente...

  // 2. Buscar en Google Sheets (reemplaza el mock)
  const filterData = await googleSheets.searchInDatabase(queryCode);
  
  if (!filterData) {
    return {
      success: false,
      message: 'Código no encontrado',
      code: queryCode
    };
  }

  // 3. Continuar con el procesamiento...
  const processedData = businessLogic.processFilterData(
    filterData.family,
    filterData.specs,
    filterData.oemCodes || [],
    filterData.crossReference || [],
    filterData
  );
  
  // ...resto del código...
}

*/

// ============================================================================
// CONFIGURACIÓN DE VARIABLES DE ENTORNO
// ============================================================================

/*

En Railway, configurar:

GOOGLE_SHEETS_ID=tu_spreadsheet_id_aqui
GOOGLE_CREDENTIALS={
  "type": "service_account",
  "project_id": "tu-project",
  "private_key_id": "...",
  "private_key": "-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n",
  "client_email": "tu-service-account@tu-project.iam.gserviceaccount.com",
  "client_id": "...",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs"
}

*/

// ============================================================================
// EXPORTACIONES
// ============================================================================

module.exports = {
  GoogleSheetsDB,
  searchInDatabase,
  searchWithCache,
  sheetsDB
};
