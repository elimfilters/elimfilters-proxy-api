# 🔧 ELIMFILTERS API v2.2.1

Sistema de generación automática de SKUs para catálogo de filtros con **Reglas v2.2.0** y **Tecnologías ELIMFILTERS** (ELIMTEK™, MAXFLOW™, MICROKAPPA™).

[![Node.js](https://img.shields.io/badge/node-%3E%3D18.0.0-brightgreen)](https://nodejs.org/)
[![Express](https://img.shields.io/badge/express-4.18.2-blue)](https://expressjs.com/)
[![Google Sheets](https://img.shields.io/badge/google--sheets-API-green)](https://developers.google.com/sheets/api)

---

## 📋 Tabla de Contenido

- [Características](#-características)
- [Tecnologías ELIMFILTERS](#-tecnologías-elimfilters)
- [Requisitos](#-requisitos)
- [Instalación](#-instalación)
- [Configuración](#-configuración)
- [Uso](#-uso)
- [API Endpoints](#-api-endpoints)
- [Estructura del Proyecto](#-estructura-del-proyecto)
- [Google Sheet](#-google-sheet)
- [Scripts Disponibles](#-scripts-disponibles)
- [Reglas de Generación](#-reglas-de-generación)
- [Testing](#-testing)
- [Deployment](#-deployment)
- [Documentación](#-documentación)

---

## ✨ Características

- ✅ **Generación automática de SKUs** según reglas v2.2.0
- ✅ **32 columnas** con especificaciones técnicas completas
- ✅ **Tecnologías ELIMFILTERS**: ELIMTEK™, MAXFLOW™, MICROKAPPA™
- ✅ **Validación de tecnologías** y auto-asignación por familia
- ✅ **Integración Google Sheets** con caché inteligente
- ✅ **API REST** con búsqueda de filtros por código OEM
- ✅ **Scripts de migración** y configuración automatizada
- ✅ **Detección de marcas de competidores**
- ✅ **Sistema modular** y escalable

---

## 🔬 Tecnologías ELIMFILTERS

### ELIMTEK™
**Para filtros de líquidos** (OIL, FUEL, HIDRAULIC, FUEL SEPARATOR)
- Eficiencia: 99.99% en condiciones extremas
- Medio filtrante líquido avanzado
- Protección superior para motores y sistemas hidráulicos

### MAXFLOW™
**Para filtros de aire motor** (AIRE, AIR DRYER)
- Protección: Hasta 10,000 km en carretera
- Alta capacidad de retención de polvo
- Flujo de aire optimizado

### MICROKAPPA™
**Para filtros de cabina** (CABIN)
- Tecnología multicapa con carbón activado
- Captura partículas ultra-finas, polen y gases nocivos
- Aire más limpio y seguro en cabina

Más información: https://elimfilters.com/technology/

---

## 📦 Requisitos

- Node.js >= 18.0.0
- npm >= 9.0.0
- Cuenta Google Cloud con Sheets API habilitada
- Google Sheet con ID: `1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U`

---

## 🚀 Instalación

### 1. Clonar repositorio

```bash
git clone https://github.com/tu-usuario/elimfilters-api.git
cd elimfilters-api
```

### 2. Instalar dependencias

```bash
npm install
```

### 3. Configurar variables de entorno

```bash
cp .env.example .env
```

Editar `.env` y agregar tus credenciales de Google Cloud (ver [Configuración](#-configuración)).

---

## ⚙️ Configuración

### 1. Obtener Credenciales de Google Cloud

Sigue la guía paso a paso:
```bash
docs/PASO_A_PASO_GOOGLE_CREDENTIALS.md
```

Pasos resumidos:
1. Crear proyecto en Google Cloud Console
2. Habilitar Google Sheets API
3. Crear Service Account
4. Generar clave JSON
5. Copiar JSON completo a `.env`

### 2. Configurar Google Sheet

**Opción A: Sheet nuevo (automático)**
```bash
npm run setup:sheet -- --samples
```

**Opción B: Sheet existente (migración)**
```bash
npm run migrate:sheet -- --backup
```

**Opción C: Manual con TSV**
```bash
# Ver guía: docs/GUIA_COPIAR_TSV.md
# Usar: examples/EJEMPLOS_FILTROS.tsv
```

### 3. Probar conexión

```bash
npm run test:sheet
npm run test:sheet P552100
```

---

## 💻 Uso

### Iniciar servidor

**Modo producción:**
```bash
npm start
```

**Modo desarrollo:**
```bash
npm run dev
```

Servidor corriendo en: http://localhost:3000

---

## 📡 API Endpoints

### GET /api/v1/filters/lookup

Buscar filtro por código OEM

**Request:**
```bash
curl "http://localhost:3000/api/v1/filters/lookup?code=P552100"
```

**Response:**
```json
{
  "success": true,
  "data": {
    "sku": "EL82100",
    "oem_code": "P552100",
    "family": "OIL",
    "duty": "HD",
    "specs_summary": "Oil Filter Heavy Duty with ELIMTEK™ Technology",
    "filter_media": "ELIMTEK",
    "filter_type": "Spin-on",
    "micron_rating": 10,
    "primary_application": "CAT 3406E",
    "cross_reference": ["P550949", "DBL7900"]
  }
}
```

### GET /health

Health check del servidor

**Response:**
```json
{
  "status": "ok",
  "version": "2.2.1",
  "uptime": 12345
}
```

---

## 📁 Estructura del Proyecto

```
elimfilters-api/
├── server.js                       # Servidor Express principal
├── businessLogic.js                # Reglas v2.2.0 de generación SKU
├── googleSheetsIntegration.js      # Integración con Google Sheets
├── elimfiltersTechnology.js        # Validador de tecnologías ELIMFILTERS
├── package.json                    # Dependencias y scripts
├── .env.example                    # Plantilla de configuración
├── .gitignore                      # Archivos ignorados por Git
├── README.md                       # Este archivo
│
├── config/
│   └── REGLAS_MAESTRAS.json        # Reglas oficiales v2.2.0
│
├── scripts/
│   ├── setup-google-sheet.js       # Configurar Sheet desde cero
│   ├── migrate-add-columns.js      # Agregar columnas a Sheet existente
│   ├── test-google-sheet.js        # Probar conexión con Sheet
│   └── migration-v2.1-to-v2.2.js   # Migrar SKUs v2.1 → v2.2
│
├── tests/
│   └── test.js                     # Suite de tests
│
├── examples/
│   ├── HEADERS_GOOGLE_SHEET.tsv    # Headers para Google Sheet
│   └── EJEMPLOS_FILTROS.tsv        # 6 filtros de ejemplo
│
└── docs/
    ├── PASO_A_PASO_GOOGLE_CREDENTIALS.md
    ├── COLUMNAS_ELIMFILTERS_ACTUALIZADO.md
    ├── GUIA_COPIAR_TSV.md
    ├── EJEMPLOS_VISUALES_v2.2.0.md
    └── ARCHIVOS_AJUSTADOS_RESUMEN.md
```

---

## 📊 Google Sheet

### Sheet ID
```
1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U
```

### Estructura: 32 Columnas (A-AF)

**Básicas (A-F)**
- SKU, OEM_Code, Family, Duty, Specs_Summary, Cross_Reference

**Técnicas (G-AF)**
- Dimensiones, Rosca, Filtración, Capacidad, Aplicaciones, Referencias, Metadata

Ver documentación completa: `docs/COLUMNAS_ELIMFILTERS_ACTUALIZADO.md`

### Columna R: Filter_Media (Tecnologías)

Valores permitidos:
- `ELIMTEK` - Filtros de líquidos
- `MAXFLOW` - Filtros de aire motor
- `MICROKAPPA` - Filtros de cabina
- `Standard` - Genéricos

❌ **NO usar**: Powercore, Synteq, Ultra-Web, NanoNet, Cellulose, Synthetic

---

## 🛠️ Scripts Disponibles

```bash
# Iniciar servidor
npm start

# Modo desarrollo con auto-reload
npm run dev

# Ejecutar tests
npm test

# Probar conexión con Google Sheet
npm run test:sheet
npm run test:sheet P552100

# Configurar Google Sheet desde cero
npm run setup:sheet
npm run setup:sheet -- --samples

# Migrar Sheet existente (agregar columnas)
npm run migrate:sheet
npm run migrate:sheet -- --backup

# Migrar SKUs v2.1 → v2.2
npm run migrate:v2
```

---

## 📐 Reglas de Generación v2.2.0

### Regla 1: OIL + HD → EL8
```
P552100 → últimos 4 dígitos → 2100 → EL82100
```

### Regla 2: FUEL + LD → EF9
```
CA10234 → últimos 4 dígitos → 0234 → EF90234
```

### Regla 3: AIRE + HD → EA1
```
P181080 → últimos 4 dígitos → 1080 → EA11080
```

### Regla 4: CABIN + LD → EC1
```
87139-07010 → últimos 4 dígitos → 7010 → EC17010
```

### Regla 5: FUEL SEPARATOR + HD → ES9
```
P551313 → últimos 4 dígitos → 1313 → ES91313
```

Ver todas las reglas: `config/REGLAS_MAESTRAS.json`

Ver ejemplos visuales: `docs/EJEMPLOS_VISUALES_v2.2.0.md`

---

## 🧪 Testing

### Ejecutar todos los tests
```bash
npm test
```

### Probar búsqueda específica
```bash
npm run test:sheet P552100
npm run test:sheet CA10234
npm run test:sheet P181080
```

### Validar tecnologías
```javascript
const tech = require('./elimfiltersTechnology');

// ¿Es válida?
tech.isValidTechnology('ELIMTEK');  // true ✅

// Recomendar por familia
tech.getRecommendedTechnology('OIL');  // 'ELIMTEK'

// Validar filtro completo
const validation = tech.validateFilterTechnology(filterData);
console.log(validation.valid);  // true/false
console.log(validation.errors);  // []
```

---

## 🚀 Deployment

### Railway (Recomendado)

1. Crear cuenta en [Railway.app](https://railway.app)
2. Conectar repositorio de GitHub
3. Agregar variables de entorno:
   - `GOOGLE_SHEETS_ID`
   - `GOOGLE_CREDENTIALS`
   - `PORT`
4. Deploy automático desde `main` branch

### Render

1. Crear cuenta en [Render.com](https://render.com)
2. Nuevo Web Service desde GitHub
3. Build: `npm install`
4. Start: `npm start`
5. Agregar variables de entorno

### Vercel

1. Instalar Vercel CLI: `npm i -g vercel`
2. Ejecutar: `vercel`
3. Seguir instrucciones
4. Agregar secrets: `vercel env add`

---

## 📚 Documentación

### Guías paso a paso
- [Obtener credenciales Google](docs/PASO_A_PASO_GOOGLE_CREDENTIALS.md)
- [Estructura de 32 columnas](docs/COLUMNAS_ELIMFILTERS_ACTUALIZADO.md)
- [Copiar TSV a Google Sheets](docs/GUIA_COPIAR_TSV.md)
- [Ejemplos visuales de reglas](docs/EJEMPLOS_VISUALES_v2.2.0.md)
- [Archivos ajustados](docs/ARCHIVOS_AJUSTADOS_RESUMEN.md)

### Archivos de ejemplo
- [Headers TSV](examples/HEADERS_GOOGLE_SHEET.tsv)
- [6 filtros de ejemplo](examples/EJEMPLOS_FILTROS.tsv)
- [Reglas oficiales](config/REGLAS_MAESTRAS.json)

---

## 🔐 Seguridad

- ✅ Nunca subir `.env` con credenciales reales
- ✅ Usar `.env.example` como plantilla
- ✅ Nunca subir `credentials.json` o `service-account.json`
- ✅ Agregar archivos sensibles a `.gitignore`
- ✅ Usar variables de entorno en producción

---

## 📞 Soporte

- **Documentación técnica**: Ver carpeta `docs/`
- **Ejemplos**: Ver carpeta `examples/`
- **Issues**: GitHub Issues
- **Tecnologías ELIMFILTERS**: https://elimfilters.com/technology/

---

## 📄 Licencia

Proprietary - ELIMFILTERS © 2025

---

## 🎯 Quick Start

```bash
# 1. Clonar
git clone https://github.com/tu-usuario/elimfilters-api.git
cd elimfilters-api

# 2. Instalar
npm install

# 3. Configurar
cp .env.example .env
# Editar .env con tus credenciales

# 4. Configurar Sheet
npm run setup:sheet -- --samples

# 5. Probar
npm run test:sheet

# 6. Iniciar
npm start

# ¡Listo! API corriendo en http://localhost:3000 🚀
```

---

## 📊 Estado del Proyecto

- ✅ Reglas v2.2.0 implementadas
- ✅ Tecnologías ELIMFILTERS integradas
- ✅ 32 columnas con especificaciones técnicas
- ✅ Validador de tecnologías activo
- ✅ Scripts de migración y configuración
- ✅ Integración Google Sheets con caché
- ✅ API REST funcional
- ✅ Tests automatizados
- ✅ Documentación completa

**Versión:** 2.2.1  
**Última actualización:** Octubre 2025

---

**ELIMFILTERS - Tecnología Alemana en Filtración**
