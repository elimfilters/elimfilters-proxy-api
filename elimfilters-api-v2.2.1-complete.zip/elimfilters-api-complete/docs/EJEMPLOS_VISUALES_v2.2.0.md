# 📊 EJEMPLOS VISUALES: Generación de SKU v2.2.0

## 🎯 Formato Oficial v2.2.0

```
SKU = PREFIXNNNN (sin guiones)
```

---

## 📝 Caso 1: Oil Filter HD con Donaldson

### Datos de Entrada
```json
{
  "family": "OIL",
  "duty_level": "HD",
  "crossReference": ["P552100", "LF3620", "1R0739"],
  "oemCodes": ["51515"]
}
```

### Proceso Paso a Paso

```
┌─────────────────────────────────────────────────────────────┐
│ PASO 1: Determinar Prefix (Regla 1)                        │
├─────────────────────────────────────────────────────────────┤
│ Input:  family="OIL", duty="HD"                            │
│ Buscar: prefixes.mapping["OIL"]                            │
│ Result: prefix="EL8"                                        │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 2: Buscar Base Code (Regla 2 - HD)                   │
├─────────────────────────────────────────────────────────────┤
│ Step 1: Buscar DONALDSON (P\d{5,6}) en cross_reference    │
│         → ["P552100", "LF3620", "1R0739"]                  │
│         → ✓ P552100 encontrado!                            │
│                                                             │
│ Selected: "P552100"                                        │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 3: Extraer Números                                    │
├─────────────────────────────────────────────────────────────┤
│ Input:  "P552100"                                          │
│ Proceso: Remover letras → "552100"                         │
│ Result: "552100"                                            │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 4: Tomar Últimos 4 Dígitos                           │
├─────────────────────────────────────────────────────────────┤
│ Input:  "552100"                                           │
│ Proceso: Obtener últimos 4 → "2100"                       │
│ Result: "2100"                                              │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 5: Generar SKU (Regla 4)                             │
├─────────────────────────────────────────────────────────────┤
│ Prefix:    "EL8"                                           │
│ BaseCode:  "2100"                                          │
│ Formula:   PREFIX + BASECODE (sin guiones)                 │
│                                                             │
│ SKU FINAL: "EL82100" ✅                                     │
└─────────────────────────────────────────────────────────────┘
```

### Validación (Regla 5)
```
✅ Prefix "EL8" está en lista válida
✅ BaseCode "2100" tiene 4 dígitos numéricos
✅ SKU "EL82100" tiene formato PREFIXNNNN
✅ Duty "HD" es válido
✅ Tipo "OIL" es válido
```

### Resultado Final
```json
{
  "sku": "EL82100",
  "sku_generated": true,
  "base_code_used": "P552100",
  "prefix_used": "EL8",
  "last_4_digits": "2100"
}
```

---

## 📝 Caso 2: Fuel Filter LD con FRAM

### Datos de Entrada
```json
{
  "family": "FUEL",
  "duty_level": "LD",
  "crossReference": ["CA10234", "LF3000"],
  "oemCodes": ["88922"]
}
```

### Proceso Paso a Paso

```
┌─────────────────────────────────────────────────────────────┐
│ PASO 1: Determinar Prefix (Regla 1)                        │
├─────────────────────────────────────────────────────────────┤
│ Input:  family="FUEL", duty="LD"                           │
│ Buscar: prefixes.mapping["FUEL"]                           │
│ Result: prefix="EF9"                                        │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 2: Buscar Base Code (Regla 3 - LD)                   │
├─────────────────────────────────────────────────────────────┤
│ Step 1: Buscar FRAM ((PH|CA|CF|CH)\d{3,6}) en cross_ref   │
│         → ["CA10234", "LF3000"]                            │
│         → ✓ CA10234 encontrado!                            │
│                                                             │
│ Selected: "CA10234"                                        │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 3: Extraer Números                                    │
├─────────────────────────────────────────────────────────────┤
│ Input:  "CA10234"                                          │
│ Proceso: Remover letras → "10234"                         │
│ Result: "10234"                                             │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 4: Tomar Últimos 4 Dígitos                           │
├─────────────────────────────────────────────────────────────┤
│ Input:  "10234"                                            │
│ Proceso: Obtener últimos 4 → "0234"                       │
│ Result: "0234"                                              │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 5: Generar SKU (Regla 4)                             │
├─────────────────────────────────────────────────────────────┤
│ Prefix:    "EF9"                                           │
│ BaseCode:  "0234"                                          │
│ Formula:   PREFIX + BASECODE (sin guiones)                 │
│                                                             │
│ SKU FINAL: "EF90234" ✅                                     │
└─────────────────────────────────────────────────────────────┘
```

### Resultado Final
```json
{
  "sku": "EF90234",
  "sku_generated": true,
  "base_code_used": "CA10234",
  "prefix_used": "EF9",
  "last_4_digits": "0234"
}
```

---

## 📝 Caso 3: Oil Filter HD sin Donaldson (OEM más comercial)

### Datos de Entrada
```json
{
  "family": "OIL",
  "duty_level": "HD",
  "crossReference": ["1R0739", "LF3620", "51515"],
  "oemCodes": ["12345"]
}
```

### Proceso Paso a Paso

```
┌─────────────────────────────────────────────────────────────┐
│ PASO 1: Determinar Prefix (Regla 1)                        │
├─────────────────────────────────────────────────────────────┤
│ Input:  family="OIL", duty="HD"                            │
│ Result: prefix="EL8"                                        │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 2: Buscar Base Code (Regla 2 - HD)                   │
├─────────────────────────────────────────────────────────────┤
│ Step 1: Buscar DONALDSON (P\d{5,6}) en cross_reference    │
│         → ["1R0739", "LF3620", "51515"]                    │
│         → ✗ No encontrado Donaldson                        │
│                                                             │
│ Step 2: Buscar DONALDSON en oem_codes                     │
│         → ["12345"]                                        │
│         → ✗ No encontrado Donaldson                        │
│                                                             │
│ Step 3: Usar primer cross_reference (OEM más comercial)   │
│         → "1R0739" ✓                                       │
│                                                             │
│ Selected: "1R0739"                                         │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 3: Extraer Números                                    │
├─────────────────────────────────────────────────────────────┤
│ Input:  "1R0739"                                           │
│ Proceso: Remover letras → "10739"                         │
│ Result: "10739"                                             │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 4: Tomar Últimos 4 Dígitos                           │
├─────────────────────────────────────────────────────────────┤
│ Input:  "10739"                                            │
│ Proceso: Obtener últimos 4 → "0739"                       │
│ Result: "0739"                                              │
└─────────────────────────────────────────────────────────────┘
                          ↓
┌─────────────────────────────────────────────────────────────┐
│ PASO 5: Generar SKU (Regla 4)                             │
├─────────────────────────────────────────────────────────────┤
│ Prefix:    "EL8"                                           │
│ BaseCode:  "0739"                                          │
│                                                             │
│ SKU FINAL: "EL80739" ✅                                     │
└─────────────────────────────────────────────────────────────┘
```

### Resultado Final
```json
{
  "sku": "EL80739",
  "sku_generated": true,
  "base_code_used": "1R0739",
  "prefix_used": "EL8",
  "last_4_digits": "0739",
  "note": "Donaldson no encontrado, usado OEM más comercial"
}
```

---

## 📝 Caso 4: Air Filter HD

### Datos de Entrada
```json
{
  "family": "AIRE",
  "duty_level": "HD",
  "crossReference": ["P181080", "AF25667"],
  "oemCodes": ["555507"]
}
```

### Proceso Resumido

```
AIRE + HD → EA1
↓
Buscar Donaldson → P181080 ✓
↓
Extraer números → 181080
↓
Últimos 4 → 1080
↓
SKU = EA11080 ✅
```

### Resultado Final
```json
{
  "sku": "EA11080",
  "prefix_used": "EA1",
  "base_code_used": "P181080",
  "last_4_digits": "1080"
}
```

---

## 📝 Caso 5: Kit HD

### Datos de Entrada
```json
{
  "family": "KITS SERIES HD",
  "duty_level": "HD",
  "crossReference": ["P551329", "FF5052"],
  "oemCodes": ["12345"]
}
```

### Proceso Resumido

```
KITS SERIES HD + HD → EK5
↓
Buscar Donaldson → P551329 ✓
↓
Extraer números → 551329
↓
Últimos 4 → 1329
↓
SKU = EK51329 ✅
```

### Resultado Final
```json
{
  "sku": "EK51329",
  "prefix_used": "EK5",
  "base_code_used": "P551329",
  "last_4_digits": "1329"
}
```

---

## 📝 Caso 6: Fuel Separator HD (tipo especial)

### Datos de Entrada
```json
{
  "family": "FUEL SEPARATOR",
  "duty_level": "HD",
  "crossReference": ["P551313", "FS19551"],
  "oemCodes": ["98765"]
}
```

### Proceso Resumido

```
FUEL SEPARATOR + HD → ES9
↓
Buscar Donaldson → P551313 ✓
↓
Extraer números → 551313
↓
Últimos 4 → 1313
↓
SKU = ES91313 ✅
```

### Resultado Final
```json
{
  "sku": "ES91313",
  "prefix_used": "ES9",
  "base_code_used": "P551313",
  "last_4_digits": "1313"
}
```

---

## 📊 Tabla Comparativa de Casos

| Caso | Family | Duty | Base Code | Prefix | Last 4 | SKU Final |
|------|--------|------|-----------|--------|--------|-----------|
| 1 | OIL | HD | P552100 (Donaldson) | EL8 | 2100 | `EL82100` |
| 2 | FUEL | LD | CA10234 (FRAM) | EF9 | 0234 | `EF90234` |
| 3 | OIL | HD | 1R0739 (OEM) | EL8 | 0739 | `EL80739` |
| 4 | AIRE | HD | P181080 (Donaldson) | EA1 | 1080 | `EA11080` |
| 5 | KITS SERIES HD | HD | P551329 (Donaldson) | EK5 | 1329 | `EK51329` |
| 6 | FUEL SEPARATOR | HD | P551313 (Donaldson) | ES9 | 1313 | `ES91313` |

---

## 🔍 Patrones Observados

### Para HD (Heavy Duty):
1. **Prioridad 1**: Buscar código DONALDSON (P + números)
2. **Prioridad 2**: Si no hay Donaldson → usar primer cross_reference (OEM más comercial)
3. **Prioridad 3**: Si no hay cross_reference → usar primer oem_code

### Para LD (Light Duty):
1. **Prioridad 1**: Buscar código FRAM (PH, CA, CF, CH + números)
2. **Prioridad 2**: Si no hay FRAM → usar primer cross_reference (OEM más comercial)
3. **Prioridad 3**: Si no hay cross_reference → usar primer oem_code

### Formato Final:
- **SIEMPRE**: `PREFIXNNNN` (sin guiones ni espacios)
- **Prefix**: 3 caracteres (EL8, EF9, EA1, etc)
- **BaseCode**: 4 dígitos numéricos (con padding de ceros si es necesario)

---

## ✅ Validaciones Automáticas

Todas las generaciones de SKU pasan por estas validaciones:

```javascript
// Validación Regla 5
function validateSKU(sku, prefix, basecode, duty) {
  ✅ SKU es string válido
  ✅ SKU comienza con el prefix correcto
  ✅ BaseCode tiene exactamente 4 dígitos
  ✅ BaseCode es numérico
  ✅ Duty es HD o LD
  ✅ Longitud de SKU está en rango esperado (6-9 chars)
}
```

---

## 🎯 Casos Edge

### Código con menos de 4 dígitos
```
Input: "P55"
Números: "55"
Padding: "0055"
Result: Últimos 4 = "0055" ✅
```

### Código con solo letras (error)
```
Input: "ABCD"
Números: ""
Result: ❌ Error - No se encontraron dígitos
```

### Código muy largo
```
Input: "P55210012345"
Números: "55210012345"
Result: Últimos 4 = "2345" ✅
```

---

## 📝 Resumen de Reglas v2.2.0

```
REGLA 1: TIPO + DUTY → PREFIX
REGLA 2 (HD): Donaldson primero → OEM comercial
REGLA 3 (LD): FRAM primero → OEM comercial
REGLA 4: PREFIX + LAST4 = SKU (sin guiones)
REGLA 5: Validar formato y contenido
```

---

## 🚀 Testing Recomendado

Para validar tu implementación, prueba estos casos:

```bash
# Caso 1: HD con Donaldson
curl -X POST http://localhost:3000/api/v1/filters/lookup \
  -d '{"code": "P552100"}'
# Esperado: EL82100

# Caso 2: LD con FRAM
curl -X POST http://localhost:3000/api/v1/filters/lookup \
  -d '{"code": "CA10234"}'
# Esperado: EF90234 (o EL80234 si es OIL)

# Caso 3: HD sin Donaldson
curl -X POST http://localhost:3000/api/v1/filters/lookup \
  -d '{"code": "1R0739"}'
# Esperado: EL80739
```

---

**Estos ejemplos visuales te ayudarán a entender exactamente cómo funcionan las reglas v2.2.0 en cada escenario.**

**¡Todo está documentado y listo para implementar! 🎉**
