# 🔐 PASO A PASO: Obtener Credenciales de Google Cloud

## 📋 Tu Google Sheet
**ID**: `1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U`  
**URL**: https://docs.google.com/spreadsheets/d/1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U/edit

---

## ⏱️ Tiempo Total: 10-15 minutos

---

## 🎯 Paso 1: Ir a Google Cloud Console (2 min)

### 1.1 Abrir Google Cloud
```
🌐 Ir a: https://console.cloud.google.com
```

### 1.2 Iniciar Sesión
- Usa la misma cuenta de Google de tu Google Sheet
- Si es la primera vez, acepta los términos

---

## 🆕 Paso 2: Crear Proyecto (2 min)

### 2.1 Crear Nuevo Proyecto

**Opción A: Si NO tienes proyectos**
1. Verás un botón "Crear proyecto"
2. Click en "Crear proyecto"

**Opción B: Si ya tienes proyectos**
1. Click en el nombre del proyecto (arriba a la izquierda)
2. Click en "Nuevo proyecto"

### 2.2 Configurar Proyecto
```
Nombre del proyecto: ELIMFILTERS-API
ID del proyecto:     elimfilters-api-[número]
Organización:        Sin organización
```

### 2.3 Crear
- Click en "Crear"
- Espera 10-20 segundos
- Asegúrate de que el proyecto esté seleccionado (arriba a la izquierda)

---

## 🔌 Paso 3: Habilitar Google Sheets API (2 min)

### 3.1 Ir a Biblioteca de APIs
```
1. En el menú lateral (☰), buscar: "APIs y servicios"
2. Click en "Biblioteca"
```

O ir directamente:
```
https://console.cloud.google.com/apis/library
```

### 3.2 Buscar Google Sheets API
```
1. En el buscador, escribir: "Google Sheets API"
2. Click en "Google Sheets API" (el primer resultado)
3. Click en botón azul "HABILITAR"
4. Esperar 5-10 segundos
```

✅ Verás: "API habilitada"

---

## 👤 Paso 4: Crear Service Account (3 min)

### 4.1 Ir a Credenciales
```
1. Menú lateral (☰) → "APIs y servicios" → "Credenciales"
```

O directamente:
```
https://console.cloud.google.com/apis/credentials
```

### 4.2 Crear Service Account
```
1. Click en "+ CREAR CREDENCIALES" (arriba)
2. Seleccionar "Cuenta de servicio"
```

### 4.3 Detalles de la Cuenta

**Paso 1 de 3:**
```
Nombre de cuenta:    elimfilters-api-service
ID de cuenta:        elimfilters-api-service (se genera solo)
Descripción:         Service Account para ELIMFILTERS API
```
- Click "CREAR Y CONTINUAR"

**Paso 2 de 3: Conceder acceso**
```
Función: Editor
```
- Buscar "Editor" en el dropdown
- Seleccionar "Editor"
- Click "CONTINUAR"

**Paso 3 de 3: Acceso de usuarios**
- Dejar vacío
- Click "LISTO"

---

## 🔑 Paso 5: Descargar Credenciales JSON (2 min)

### 5.1 Encontrar tu Service Account
```
1. En la página de Credenciales
2. Buscar sección "Cuentas de servicio"
3. Verás: elimfilters-api-service@...
```

### 5.2 Crear Clave
```
1. Click en el email de la cuenta (elimfilters-api-service@...)
2. Ir a la pestaña "CLAVES" (arriba)
3. Click en "AGREGAR CLAVE"
4. Seleccionar "Crear clave nueva"
```

### 5.3 Descargar
```
1. Tipo de clave: JSON (seleccionado por defecto)
2. Click "CREAR"
3. Se descarga automáticamente un archivo .json
```

**Nombre del archivo descargado:**
```
elimfilters-api-xxxxx-xxxxxxxxx.json
```

⚠️ **IMPORTANTE**: Guarda este archivo en lugar seguro. No lo compartas.

---

## 📧 Paso 6: Copiar Email del Service Account (1 min)

### 6.1 Obtener el Email
```
El email se ve así:
elimfilters-api-service@elimfilters-api-xxxxx.iam.gserviceaccount.com
```

### 6.2 Copiarlo
```
1. Seleccionar todo el email
2. Copiar (Ctrl+C o Cmd+C)
```

**Lo necesitarás en el siguiente paso.**

---

## 🔗 Paso 7: Compartir Google Sheet (2 min)

### 7.1 Abrir tu Google Sheet
```
🌐 https://docs.google.com/spreadsheets/d/1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U/edit
```

### 7.2 Compartir
```
1. Click en botón "Compartir" (arriba derecha)
2. En "Agregar personas y grupos"
3. Pegar el email del Service Account:
   elimfilters-api-service@elimfilters-api-xxxxx.iam.gserviceaccount.com
4. Rol: "Editor"
5. DESMARCAR "Notificar a las personas"
6. Click "Compartir" o "Enviar"
```

✅ Ahora el Service Account puede leer/escribir tu Sheet

---

## 📝 Paso 8: Preparar Credenciales para Railway (3 min)

### 8.1 Abrir el Archivo JSON

**En Windows:**
```
1. Buscar el archivo descargado en Descargas
2. Click derecho → Abrir con → Bloc de notas
```

**En Mac:**
```
1. Buscar el archivo en Descargas
2. Click derecho → Abrir con → TextEdit
```

### 8.2 Ver el Contenido

El archivo se ve así:
```json
{
  "type": "service_account",
  "project_id": "elimfilters-api-xxxxx",
  "private_key_id": "abc123...",
  "private_key": "-----BEGIN PRIVATE KEY-----\nXXXXX\n-----END PRIVATE KEY-----\n",
  "client_email": "elimfilters-api-service@elimfilters-api-xxxxx.iam.gserviceaccount.com",
  "client_id": "123456789",
  "auth_uri": "https://accounts.google.com/o/oauth2/auth",
  "token_uri": "https://oauth2.googleapis.com/token",
  "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
  "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/..."
}
```

### 8.3 Convertir a Una Línea

**⚠️ IMPORTANTE**: Railway necesita todo en UNA SOLA LÍNEA

**Opción A: Usando herramienta online (más fácil)**
```
1. Ir a: https://www.text-utils.com/json-formatter/
2. Pegar el contenido de tu JSON
3. Click en "Remove formatting" o "Minify"
4. Copiar el resultado (será una sola línea)
```

**Opción B: Manual**
```
1. Copiar TODO el contenido del JSON
2. Remover TODOS los saltos de línea
3. Debe quedar: {"type":"service_account","project_id":"..."}
```

### 8.4 Resultado Final

Debes tener algo así (TODO EN UNA LÍNEA):
```
{"type":"service_account","project_id":"elimfilters-api-xxxxx","private_key_id":"abc123...","private_key":"-----BEGIN PRIVATE KEY-----\nXXXXX\n-----END PRIVATE KEY-----\n","client_email":"elimfilters-api-service@...","client_id":"123456789","auth_uri":"https://accounts.google.com/o/oauth2/auth","token_uri":"https://oauth2.googleapis.com/token","auth_provider_x509_cert_url":"https://www.googleapis.com/oauth2/v1/certs","client_x509_cert_url":"https://www.googleapis.com/robot/v1/metadata/x509/..."}
```

---

## 🚂 Paso 9: Configurar en Railway (2 min)

### 9.1 Ir a tu Proyecto en Railway
```
🌐 https://railway.app
→ Tu proyecto elimfilters-api
```

### 9.2 Ir a Variables
```
1. Click en tu servicio
2. Click en pestaña "Variables"
3. Click en "+ New Variable"
```

### 9.3 Agregar Variables

**Variable 1:**
```
Name:  GOOGLE_SHEETS_ID
Value: 1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U
```
- Click "Add"

**Variable 2:**
```
Name:  GOOGLE_CREDENTIALS
Value: [Pegar aquí el JSON en UNA LÍNEA del paso 8.4]
```
- Click "Add"

### 9.4 Guardar
- Railway guardará automáticamente
- El servicio se reiniciará (toma ~1 min)

---

## ✅ Paso 10: Probar la Conexión (2 min)

### 10.1 Esperar Despliegue
```
En Railway, esperar a que el servicio muestre:
● Active (verde)
```

### 10.2 Obtener URL
```
1. En Railway, click en tu servicio
2. Pestaña "Settings"
3. Sección "Domains"
4. Copiar la URL: https://tu-app.up.railway.app
```

### 10.3 Probar Health
```bash
# En navegador o terminal
https://tu-app.up.railway.app/health
```

**Respuesta esperada:**
```json
{
  "status": "ok",
  "service": "ELIMFILTERS Local API",
  "version": "3.0.0-v2.2.0",
  "rules_version": "2.2.0"
}
```

### 10.4 Probar Búsqueda Real

**Usando curl (terminal):**
```bash
curl -X POST https://tu-app.up.railway.app/api/v1/filters/lookup \
  -H "Content-Type: application/json" \
  -d '{"code": "P552100"}'
```

**O usando navegador:**
```
https://tu-app.up.railway.app/api/v1/filters/search?code=P552100
```

---

## 🎉 ¡Listo! Tu API Está Conectada

Si todo funcionó, verás:
```json
{
  "success": true,
  "filter": {
    "sku": "EL82100",
    "family": "OIL",
    "duty_level": "HD"
  }
}
```

---

## 🆘 Solución de Problemas

### ❌ Error: "Error loading credentials"
```
Causa: Credenciales mal formateadas
Solución:
1. Verificar que GOOGLE_CREDENTIALS sea UNA línea
2. Verificar que tenga comillas correctas
3. Volver a copiar del JSON original
```

### ❌ Error: "The caller does not have permission"
```
Causa: No compartiste el Sheet con el Service Account
Solución:
1. Ir al Google Sheet
2. Click "Compartir"
3. Agregar el email del Service Account
4. Dar permisos de "Editor"
```

### ❌ Error: "404 Requested entity was not found"
```
Causa: ID del Sheet incorrecto
Solución:
1. Verificar GOOGLE_SHEETS_ID en Railway
2. Debe ser: 1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U
```

### ❌ Error: "API has not been used in project"
```
Causa: Google Sheets API no habilitada
Solución:
1. Ir a Google Cloud Console
2. Buscar "Google Sheets API"
3. Click "Habilitar"
```

---

## 📋 Checklist Final

- [ ] Proyecto creado en Google Cloud
- [ ] Google Sheets API habilitada
- [ ] Service Account creado
- [ ] Archivo JSON descargado
- [ ] Email del Service Account copiado
- [ ] Google Sheet compartido con Service Account
- [ ] JSON convertido a una línea
- [ ] Variables agregadas en Railway
- [ ] Servicio desplegado
- [ ] Health check funcionando
- [ ] Búsqueda de prueba exitosa

---

## 💾 Guardar para Referencia

**Tu información importante:**

```
Google Sheet ID:
1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U

Service Account Email:
elimfilters-api-service@elimfilters-api-xxxxx.iam.gserviceaccount.com
(El que creaste)

Railway URL:
https://tu-app.up.railway.app
(La que te dio Railway)

Archivo JSON:
[Guardado en tu computadora]
```

---

## 📞 ¿Necesitas Ayuda?

Si algo no funciona:
1. Revisa esta guía paso a paso
2. Verifica el checklist
3. Revisa la sección de problemas comunes
4. Verifica logs en Railway

---

**¡Felicidades! Tu API está conectada a tu Google Sheet! 🎉**
