# 📋 GUÍA: Copiar TSV a Google Sheets

## 🎯 Tu Google Sheet
**ID**: `1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U`  
**URL**: https://docs.google.com/spreadsheets/d/1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U/edit

---

## 📥 ARCHIVOS TSV DISPONIBLES

### 1. HEADERS_GOOGLE_SHEET.tsv
**Contiene**: Solo los headers (fila 1) con 32 columnas

### 2. EJEMPLOS_FILTROS.tsv  
**Contiene**: Headers + 6 filtros de ejemplo
- 2 Oil Filters HD (ELIMTEK™)
- 1 Fuel Filter LD (ELIMTEK™)
- 1 Air Filter HD (MAXFLOW™)
- 1 Cabin Filter LD (MICROKAPPA™)
- 1 Fuel Separator HD (ELIMTEK™)

---

## 🚀 OPCIÓN 1: Sheet Vacío (Copiar Todo)

### Paso 1: Abrir archivos TSV

**En Windows:**
```
1. Click derecho en EJEMPLOS_FILTROS.tsv
2. Abrir con → Bloc de notas
3. Ctrl+A (seleccionar todo)
4. Ctrl+C (copiar)
```

**En Mac:**
```
1. Click derecho en EJEMPLOS_FILTROS.tsv
2. Abrir con → TextEdit
3. Cmd+A (seleccionar todo)
4. Cmd+C (copiar)
```

### Paso 2: Pegar en Google Sheets

```
1. Ir a tu Google Sheet
2. Click en celda A1
3. Ctrl+V (Windows) o Cmd+V (Mac)
4. ¡Listo! 32 columnas + 6 filtros agregados
```

---

## 🔄 OPCIÓN 2: Ya Tienes Datos (Solo Headers)

Si ya tienes datos en tu Sheet y solo quieres agregar los headers:

### Paso 1: Abrir HEADERS_GOOGLE_SHEET.tsv

```
1. Abrir con editor de texto
2. Copiar todo (Ctrl+A, Ctrl+C)
```

### Paso 2: Insertar en Sheet

```
1. Ir a tu Google Sheet
2. Click derecho en fila 1
3. "Insertar 1 fila arriba"
4. Click en celda A1
5. Pegar (Ctrl+V)
6. Mover tus datos una fila abajo si es necesario
```

---

## 🎨 FORMATO DEL TSV

### ¿Qué es TSV?
```
TSV = Tab-Separated Values
Cada columna está separada por un TAB (tabulador)

Ejemplo:
SKU[TAB]OEM_Code[TAB]Family[TAB]Duty...
```

### ¿Por qué TSV y no CSV?
```
✅ TSV: Google Sheets detecta automáticamente las columnas
❌ CSV: A veces genera problemas con comas en los datos
```

---

## 🔍 VERIFICAR QUE SE COPIÓ CORRECTAMENTE

Después de pegar, verifica:

### ✅ Debería verse así:
```
Columna A: SKU
Columna B: OEM_Code
Columna C: Family
...
Columna AF: Updated_At

Cada dato en su propia columna ✅
```

### ❌ Si se ve así (ERROR):
```
Toda la fila en columna A:
"SKU    OEM_Code    Family    Duty..."

Todo en una sola columna ❌
```

**Solución:**
```
1. Deshacer (Ctrl+Z)
2. Datos → Dividir texto en columnas
3. Separador: Tabulador
```

---

## 📊 ESTRUCTURA DESPUÉS DE PEGAR

### Con EJEMPLOS_FILTROS.tsv
```
Fila 1:  Headers (32 columnas)
Fila 2:  EL89000 - Oil HD con ELIMTEK™
Fila 3:  EL80949 - Oil HD Compact con ELIMTEK™
Fila 4:  EF90234 - Fuel LD con ELIMTEK™
Fila 5:  EA11080 - Air HD con MAXFLOW™
Fila 6:  EC10456 - Cabin LD con MICROKAPPA™
Fila 7:  ES91313 - Fuel Separator HD con ELIMTEK™
```

---

## 🎯 TECNOLOGÍAS ELIMFILTERS EN LOS EJEMPLOS

### Columna R (Filter_Media) - Valores Usados:

```
ELIMTEK     - 4 filtros (OIL, FUEL, FUEL SEPARATOR)
              "99.99% efficiency in extreme conditions"

MAXFLOW     - 1 filtro (AIRE)
              "up to 10,000 km on-road protection"

MICROKAPPA  - 1 filtro (CABIN)
              "captures ultra-fine particles and harmful gases"
```

### Columna E (Specs_Summary) - Incluye Tecnología:

```
"Oil Filter Heavy Duty Spin-on with ELIMTEK™ Technology"
"Air Filter Heavy Duty Panel with MAXFLOW™ Technology"
"Cabin Air Filter with MICROKAPPA™ Multilayer Technology"
```

### Columna AC (Notes) - Describe Beneficios:

```
"ELIMTEK™ technology ensures 99.99% efficiency in extreme conditions"
"MAXFLOW™ technology provides up to 10,000 km on-road protection"
"MICROKAPPA™ with activated carbon captures ultra-fine particles..."
```

---

## 🔧 DESPUÉS DE COPIAR

### 1. Formatear Headers (Opcional)
```
1. Seleccionar fila 1
2. Formato → Texto en negrita
3. Formato → Color de fondo → Gris claro
4. Vista → Inmovilizar → 1 fila
```

### 2. Ajustar Anchos (Opcional)
```
1. Seleccionar todas las columnas (A-AF)
2. Click derecho → Cambiar tamaño de columnas
3. Ajustar al contenido
```

### 3. Agregar Más Filtros
```
Ahora puedes agregar tus propios filtros:
- Fila 8 en adelante
- Copiar formato de ejemplos
- Usar tecnologías: ELIMTEK, MAXFLOW, MICROKAPPA
```

---

## ✅ CHECKLIST

Después de copiar, verifica:

- [ ] 32 columnas visibles (A hasta AF)
- [ ] Headers en fila 1
- [ ] Datos en columnas separadas (no todo en columna A)
- [ ] 6 filtros de ejemplo (si usaste EJEMPLOS_FILTROS.tsv)
- [ ] Columna R muestra: ELIMTEK, MAXFLOW, o MICROKAPPA
- [ ] Columna E incluye nombre de tecnología
- [ ] Todos los campos con datos se ven correctamente

---

## 🆘 PROBLEMAS COMUNES

### Problema 1: Todo en una columna
```
Causa: Google Sheets no detectó el tabulador
Solución:
1. Ctrl+Z para deshacer
2. Datos → Dividir texto en columnas
3. Separador: Tabulador
```

### Problema 2: Caracteres raros
```
Causa: Encoding del archivo
Solución:
1. Abrir TSV con Notepad++ o VSCode
2. Encoding → UTF-8
3. Guardar
4. Copiar de nuevo
```

### Problema 3: Fechas mal formateadas
```
Causa: Google Sheets autoformatea fechas
Solución:
1. Seleccionar columnas AE y AF
2. Formato → Número → Texto sin formato
3. Pegar de nuevo
```

---

## 🎉 LISTO!

Ahora tienes:
- ✅ 32 columnas configuradas
- ✅ 6 filtros de ejemplo con las 3 tecnologías
- ✅ Estructura lista para agregar más filtros
- ✅ Nombres correctos (ELIMTEK™, MAXFLOW™, MICROKAPPA™)

---

## 📝 SIGUIENTE PASO

Después de tener el Sheet configurado:

1. **Revisar ejemplos** - Ver cómo están estructurados los 6 filtros
2. **Agregar tus filtros** - Usar misma estructura
3. **Usar tecnologías correctas**:
   - OIL/FUEL/HIDRAULIC → ELIMTEK
   - AIRE → MAXFLOW
   - CABIN → MICROKAPPA
4. **Probar API** - Ejecutar scripts de conexión

---

**Sheet ID**: `1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U`

**Archivos TSV listos para copiar/pegar** ✅
