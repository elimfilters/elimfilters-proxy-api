# 📊 COLUMNAS GOOGLE SHEET - ELIMFILTERS (Actualizado con Tecnologías Propias)

## 🎯 Tu Google Sheet
**ID**: `1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U`  
**URL**: https://docs.google.com/spreadsheets/d/1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U/edit

---

## 📋 32 COLUMNAS ACTUALIZADAS

### ✅ Grupo A: IDENTIFICACIÓN (A-F)
```
A: SKU                 - Generado automático (reglas v2.2.0)
B: OEM_Code            - Código OEM principal
C: Family              - OIL, FUEL, AIRE, CABIN, etc.
D: Duty                - HD o LD
E: Specs_Summary       - Descripción breve del filtro
F: Cross_Reference     - Códigos compatibles (separados por coma)
```

### ➕ Grupo B: DIMENSIONES FÍSICAS (G-L)
```
G: Height_Inches          - Altura en pulgadas
H: Height_MM              - Altura en mm (auto-calculado)
I: Outer_Diameter_Inches  - Diámetro exterior pulgadas
J: Outer_Diameter_MM      - Diámetro exterior mm (auto)
K: Inner_Diameter_Inches  - Diámetro interior pulgadas (si aplica)
L: Inner_Diameter_MM      - Diámetro interior mm (auto)
```

### ➕ Grupo C: ROSCA Y SELLO (M-P)
```
M: Thread_Size            - 3/4-16, M20x1.5, etc.
N: Thread_Type            - UNF, Metric, NPT, BSPT, None
O: Gasket_OD_Inches       - Diámetro empaque (pulgadas)
P: Gasket_Type            - Nitrile, Viton, HNBR, Silicone, None
```

### ➕ Grupo D: FILTRACIÓN (Q-S) ⚠️ ACTUALIZADO
```
Q: Micron_Rating          - 5, 10, 15, 25, 40, etc.
R: Filter_Media           - ELIMTEK, MAXFLOW, MICROKAPPA, Standard
S: Filter_Type            - Spin-on, Cartridge, Element, Panel, Canister
```

**VALORES PERMITIDOS para R (Filter_Media):**
- `ELIMTEK` - Para filtros de líquidos (OIL, FUEL, HIDRAULIC)
- `MAXFLOW` - Para filtros de aire motor (AIRE)
- `MICROKAPPA` - Para filtros de cabina (CABIN)
- `Standard` - Para filtros sin tecnología específica o genéricos

### ➕ Grupo E: CAPACIDAD Y FLUJO (T-W)
```
T: Flow_Rate_GPM          - Flujo en galones/minuto
U: Flow_Rate_LPM          - Flujo en litros/minuto (auto)
V: Dirt_Capacity_Grams    - Capacidad retención suciedad
W: Collapse_PSI           - Presión de colapso
```

### ➕ Grupo F: APLICACIONES (X-Z)
```
X: Primary_Application      - CAT 3406E, Cummins ISX15, etc.
Y: Compatible_Applications  - Aplicaciones compatibles (separadas por coma)
Z: OEM_Brands              - CATERPILLAR, CUMMINS, etc. (separadas por coma)
```

### ➕ Grupo G: REFERENCIAS (AA-AB)
```
AA: Replaces              - Códigos que este filtro reemplaza
AB: Superseded_By         - Si fue reemplazado por otro código
```

### ➕ Grupo H: METADATA (AC-AF)
```
AC: Notes                 - Notas especiales, advertencias
AD: Stock_Status          - In Stock, Low Stock, Backorder, Discontinued
AE: Created_At            - Timestamp creación (auto)
AF: Updated_At            - Timestamp actualización (auto)
```

---

## 🔬 MAPEO: Tecnologías por Familia de Filtro

```
Family OIL:
- Filter_Media: ELIMTEK (tecnología líquida)
- Ejemplo: Oil Filter con ELIMTEK™ - 99.99% eficiencia

Family FUEL:
- Filter_Media: ELIMTEK (tecnología líquida)
- Ejemplo: Fuel Filter con ELIMTEK™

Family AIRE:
- Filter_Media: MAXFLOW (tecnología aire)
- Ejemplo: Air Filter con MAXFLOW™ - 10,000 km

Family CABIN:
- Filter_Media: MICROKAPPA (tecnología cabina)
- Ejemplo: Cabin Filter con MICROKAPPA™ - carbón activado

Family HIDRAULIC:
- Filter_Media: ELIMTEK (tecnología líquida)

Family FUEL SEPARATOR:
- Filter_Media: ELIMTEK (tecnología líquida)

Family COOLANT:
- Filter_Media: ELIMTEK o Standard

Otros:
- Filter_Media: Standard (genérico)
```

---

## 📊 VALORES PERMITIDOS POR COLUMNA

### C: Family (Valores Permitidos)
```
- OIL
- FUEL
- AIRE
- CABIN
- FUEL SEPARATOR
- AIR DRYER
- HIDRAULIC
- COOLANT
- CARCAZA AIR FILTER
- TURBINE SERIES
- KITS SERIES HD
- KITS SERIES LD
```

### D: Duty (Valores Permitidos)
```
- HD (Heavy Duty)
- LD (Light Duty)
```

### N: Thread_Type (Valores Comunes)
```
- UNF
- UNC
- Metric
- NPT
- BSPT
- None
```

### P: Gasket_Type (Valores Comunes)
```
- Nitrile
- Viton
- HNBR
- Silicone
- Rubber
- None
```

### R: Filter_Media (Valores Permitidos) ⭐
```
- ELIMTEK     (para líquidos: OIL, FUEL, HIDRAULIC)
- MAXFLOW     (para aire motor: AIRE)
- MICROKAPPA  (para cabina: CABIN)
- Standard    (genérico o sin tecnología específica)
```

### S: Filter_Type (Valores Comunes)
```
- Spin-on
- Cartridge
- Element
- Panel
- Canister
- Insert
```

### AD: Stock_Status (Valores Permitidos)
```
- In Stock
- Low Stock
- Backorder
- Discontinued
- Special Order
```

---

## 📝 EJEMPLO DE FILA COMPLETA

### Filtro de Aceite HD con ELIMTEK™
```
A: EL89000
B: P559000
C: OIL
D: HD
E: Oil Filter Heavy Duty Spin-on with ELIMTEK™ Technology
F: P550949, DBL7900, LF3620, 1R0739
G: 5.0
H: 127.0
I: 3.75
J: 95.25
K: 1.5
L: 38.1
M: 3/4-16
N: UNF
O: 2.5
P: Nitrile
Q: 10
R: ELIMTEK
S: Spin-on
T: 8.5
U: 32.2
V: 45
W: 40
X: CAT 3406E
Y: CAT 3406B, CAT 3406C, CAT C15
Z: CATERPILLAR, DONALDSON, BALDWIN
AA: P551315, P550148
AB: 
AC: ELIMTEK™ technology ensures 99.99% efficiency in extreme conditions
AD: In Stock
AE: 2025-10-28T10:30:00Z
AF: 2025-10-28T10:30:00Z
```

### Filtro de Aire HD con MAXFLOW™
```
A: EA11080
B: P181080
C: AIRE
D: HD
E: Air Filter Heavy Duty with MAXFLOW™ Technology
F: AF25667, 555507
G: 14.5
H: 368.3
I: 5.25
J: 133.35
K: 
L: 
M: 
N: None
O: 
P: 
Q: 10
R: MAXFLOW
S: Panel
T: 
U: 
V: 750
W: 
X: CAT 3406E
Y: CAT C15, CAT C15 ACERT
Z: CATERPILLAR, DONALDSON
AA: P606119, CA256
AB: 
AC: MAXFLOW™ technology provides up to 10,000 km on-road protection
AD: In Stock
AE: 2025-10-28T10:30:00Z
AF: 2025-10-28T10:30:00Z
```

### Filtro de Cabina con MICROKAPPA™
```
A: EC10456
B: 87139-07010
C: CABIN
D: LD
E: Cabin Air Filter with MICROKAPPA™ Multilayer Technology
F: CF10456
G: 1.5
H: 38.1
I: 8.5
J: 215.9
K: 
L: 
M: 
N: None
O: 
P: 
Q: 5
R: MICROKAPPA
S: Panel
T: 
U: 
V: 
W: 
X: Toyota Hilux 2015-2020
Y: Toyota Fortuner 2015-2020
Z: TOYOTA
AA: 
AB: 
AC: MICROKAPPA™ with activated carbon captures ultra-fine particles and harmful gases
AD: In Stock
AE: 2025-10-28T10:30:00Z
AF: 2025-10-28T10:30:00Z
```

---

## ⚠️ NOTAS IMPORTANTES

### NO Usar Marcas Registradas de Otros
```
❌ NO usar: Powercore, Synteq, Ultra-Web, NanoNet, etc.
✅ SÍ usar: ELIMTEK, MAXFLOW, MICROKAPPA, Standard
```

### Especificaciones en Descriptions
```
Incluir tecnología en Specs_Summary:
- "Oil Filter with ELIMTEK™ Technology"
- "Air Filter with MAXFLOW™ Technology"
- "Cabin Filter with MICROKAPPA™ Technology"
```

### Consistencia
```
Family OIL/FUEL/HIDRAULIC    → Filter_Media: ELIMTEK
Family AIRE                   → Filter_Media: MAXFLOW
Family CABIN                  → Filter_Media: MICROKAPPA
Otros/genéricos              → Filter_Media: Standard
```

---

Ver archivo TSV adjunto para copiar/pegar directo en Google Sheets.
