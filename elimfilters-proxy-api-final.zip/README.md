# elimfilters-proxy-api

Proxy seguro entre WordPress y n8n.

Flujo:
WordPress → /api/filter-lookup (Express en Railway) → n8n → Express → WordPress.

## Endpoints

GET /health  
POST /api/filter-lookup  
POST /chat   (diagnóstico opcional)

## Env vars en Railway

PORT=3000  
N8N_WEBHOOK_URL=...  
INTERNAL_API_KEY=...  
NODE_ENV=production

