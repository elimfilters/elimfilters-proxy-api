const path = require('path');
const fs = require('fs');
const { google } = require('googleapis');

class GoogleSheetsService {
  constructor() {
    this.sheets = null;
    this.auth = null;
    this.spreadsheetId = '1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U';
  }

  async initialize() {
    try {
      if (!this.auth) {
        // Leer credenciales locales
        const keyFilePath = path.join(__dirname, 'credentials.json');
        const rawCreds = fs.readFileSync(keyFilePath, 'utf8');
        const credentials = JSON.parse(rawCreds);

        this.auth = new google.auth.GoogleAuth({
          credentials,
          scopes: [
            'https://www.googleapis.com/auth/spreadsheets',
            'https://www.googleapis.com/auth/drive'
          ],
        });
      }

      this.sheets = google.sheets({
        version: 'v4',
        auth: await this.auth.getClient(),
      });

      return true;
    } catch (error) {
      console.error('Error initializing Google Sheets:', error);
      throw error;
    }
  }

  async getProductByQuery(queryNorm) {
    try {
      if (!this.sheets) {
        await this.initialize();
      }

      const response = await this.sheets.spreadsheets.values.get({
        spreadsheetId: this.spreadsheetId,
        range: 'Master!A:Z',
      });

      const rows = response.data.values || [];

      if (!rows || rows.length === 0) {
        return { found: false };
      }

      const headers = rows[0];
      const normalizedQuery = queryNorm.toLowerCase().trim();

      // Buscar en query_norm (columna A) y SKU (columna B)
      const foundRow = rows.slice(1).find(row => {
        const queryNormValue = (row[0] || '').toLowerCase().trim();
        const skuValue = (row[1] || '').toLowerCase().trim();
        return queryNormValue === normalizedQuery || skuValue === normalizedQuery;
      });

      if (!foundRow) {
        return { found: false };
      }

      const product = {};
      headers.forEach((header, index) => {
        product[header] = foundRow[index] || '';
      });

      return { found: true, data: product };
    } catch (error) {
      console.error('Error searching in Master:', error);
      throw error;
    }
  }

  async getFamilyRules() {
    try {
      if (!this.sheets) {
        await this.initialize();
      }

      const response = await this.sheets.spreadsheets.values.get({
        spreadsheetId: this.spreadsheetId,
        range: 'FAMILY_RULES!A:G',
      });

      const rows = response.data.values || [];
      if (!rows || rows.length < 2) {
        console.warn('⚠️ FAMILY_RULES vacío o incompleto');
        return [];
      }

      // Convertir a objetos legibles
      const rules = rows.slice(1).map(row => ({
        duty: row[1] || '',
        family: row[2] || '',
        match_type: row[3] || '',
        min: row[4] ? parseInt(row[4]) : null,
        max: row[5] ? parseInt(row[5]) : null,
        priority: row[6] ? parseInt(row[6]) : 0
      }));

      // Ordenar por prioridad (mayor a menor)
      rules.sort((a, b) => b.priority - a.priority);

      console.log(`✅ Loaded ${rules.length} FAMILY_RULES`);
      return rules;
    } catch (error) {
      console.error('⚠️ Error loading FAMILY_RULES:', error);
      throw error;
    }
  }

  async saveToMaster(productData) {
    try {
      if (!this.sheets) {
        await this.initialize();
      }

      // Preparar los datos en el orden correcto de las columnas
      const row = [
        productData.query_norm || '',
        productData.sku || '',
        productData.oem_codes || '',
        productData.cross_reference || '',
        productData.filter_type || '',
        productData.duty || '',
        productData.engine_applications || '',
        productData.equipment_applications || '',
        productData.notes || '',
        new Date().toISOString()
      ];

      const response = await this.sheets.spreadsheets.values.append({
        spreadsheetId: this.spreadsheetId,
        range: 'Master!A:Z',
        valueInputOption: 'RAW',
        insertDataOption: 'INSERT_ROWS',
        requestBody: {
          values: [row]
        }
      });

      console.log('✅ Row appended to Master:', response.status);
      return true;
    } catch (error) {
      console.error('Error saving to Master:', error);
      throw error;
    }
  }

  async searchProductsLoose(query) {
    try {
      if (!this.sheets) {
        await this.initialize();
      }

      const response = await this.sheets.spreadsheets.values.get({
        spreadsheetId: this.spreadsheetId,
        range: 'Master!A:Z',
      });

      const rows = response.data.values || [];
      if (!rows || rows.length === 0) {
        return [];
      }

      const headers = rows[0];
      const products = rows.slice(1).map(row => {
        const product = {};
        headers.forEach((header, idx) => {
          product[header] = row[idx] || '';
        });
        return product;
      });

      if (!query) {
        return products;
      }

      const normalizedQuery = query.toLowerCase().trim();

      return products.filter(product => {
        return (
          (product.SKU && product.SKU.toLowerCase().includes(normalizedQuery)) ||
          (product['OEM Codes'] && product['OEM Codes'].toLowerCase().includes(normalizedQuery)) ||
          (product['Cross Reference'] && product['Cross Reference'].toLowerCase().includes(normalizedQuery)) ||
          (product['Filter Type'] && product['Filter Type'].toLowerCase().includes(normalizedQuery)) ||
          (product['Engine Applications'] && product['Engine Applications'].toLowerCase().includes(normalizedQuery)) ||
          (product['Equipment Applications'] && product['Equipment Applications'].toLowerCase().includes(normalizedQuery))
        );
      });
    } catch (error) {
      console.error('Error searching products:', error);
      throw error;
    }
  }
}

module.exports = GoogleSheetsService;
