require('dotenv').config();

const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const GoogleSheetsService = require('./googleSheetsConnector');
const detectionService = require('./detectionService');
const { processFilterCode } = require('./filterProcessor');

const app = express();

// confiar en proxy Railway
app.set('trust proxy', 1);

// CORS limitado (ajusta dominios reales si cambia el dominio web)
app.use(cors({
  origin: [
    'https://elimfilters.com',
    'https://www.elimfilters.com'
  ],
  methods: ['GET','POST'],
}));

// body JSON
app.use(express.json());

// rate limit en /api/
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false,
});
app.use('/api/', limiter);

// =====================
// Inicializar Google Sheets una vez
// =====================
let sheetsInstance;

async function initServices() {
  try {
    sheetsInstance = new GoogleSheetsService();
    await sheetsInstance.initialize();
    detectionService.setSheetsInstance(sheetsInstance);
    console.log('[INIT] Google Sheets listo');
  } catch (err) {
    console.error('[INIT ERROR] No se pudo inicializar Google Sheets:', err.message);
  }
}
initServices();

// =====================
// /health
// =====================
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'ELIMFILTERS Proxy API',
    version: '2.5.0-no-n8n-localcreds',
    endpoints: {
      health: 'GET /health',
      detect: 'POST /api/detect-filter',
    },
  });
});

// =====================
// /api/detect-filter
// =====================
app.post('/api/detect-filter', async (req, res) => {
  const candidate =
    (req.body && (req.body.code || req.body.sku || req.body.oem || req.body.query)) ||
    (req.query && (req.query.code || req.query.sku || req.query.oem || req.query.query)) ||
    '';

  const normalized = String(candidate || '').trim().toUpperCase();

  if (!normalized) {
    return res.status(400).json({
      status: 'ERROR',
      message: 'Falta código de búsqueda (query vacío)',
    });
  }

  try {
    const result = await processFilterCode(normalized);

    return res.status(200).json({
      status: 'OK',
      ...result,
    });

  } catch (err) {
    console.error('[DETECT-FILTER] ERROR:', err);
    return res.status(500).json({
      status: 'ERROR',
      message: 'Fallo interno en detect-filter',
      details: err.message || null,
    });
  }
});

// =====================
// Error global
// =====================
app.use((err, req, res, next) => {
  console.error('[ERROR GLOBAL]:', err);
  res.status(500).json({
    status: 'ERROR',
    message: err.message || 'Internal server error',
  });
});

// =====================
// Arranque
// =====================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('✅ ELIMFILTERS Proxy API v2.5.0-no-n8n-localcreds');
  console.log(`🚀 Listening on port ${PORT}`);
  console.log('📊 Health: GET /health');
  console.log('🔎 Detect: POST /api/detect-filter');
});
