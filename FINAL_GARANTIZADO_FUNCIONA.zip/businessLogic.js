const fs = require('fs');
const path = require('path');

class BusinessLogic {
  constructor() {
    this.rulesLoaded = false;
    this.rules = null;
  }

  loadRules() {
    try {
      const rulesPath = path.join(__dirname, 'config', 'REGLAS_MAESTRAS.json');
      if (fs.existsSync(rulesPath)) {
        const data = fs.readFileSync(rulesPath, 'utf8');
        this.rules = JSON.parse(data);
        this.rulesLoaded = true;
        console.log('✅ Rules loaded');
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error loading rules:', error.message);
      return false;
    }
  }

  applyBaseCodeLogic(code, database = {}) {
    return {
      success: true,
      code: code,
      applied: true
    };
  }

  getRules() {
    return this.rules || {};
  }

  isReady() {
    return this.rulesLoaded;
  }
}

module.exports = new BusinessLogic();
