const express = require('express');
const businessLogic = require('./businessLogic');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

businessLogic.loadRules();

app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    version: '1.0.0',
    rulesLoaded: businessLogic.isReady()
  });
});

app.get('/status', (req, res) => {
  res.json({
    service: 'elimfilters-proxy-api',
    status: 'running',
    uptime: process.uptime()
  });
});

app.get('/', (req, res) => {
  res.json({
    message: 'Elimfilters Proxy API',
    version: '1.0.0'
  });
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({
    error: err.message
  });
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

module.exports = app;
