# ELIMFILTERS Proxy API v3.0.0

## ✅ Sin n8n + Reglas v2.2.3 Corregidas

### Versión
```json
{
  "version": "3.0.0",
  "reglas": "v2.2.3 (17 combinaciones)",
  "n8n": "No requerido",
  "proteccion": "Inmutable"
}
```

### Deployment
```bash
# 1. Push a GitHub
git add .
git commit -m "Deploy v3.0.0"
git push origin main

# 2. Railway auto-deploys

# 3. Verificar
curl https://tu-url.railway.app/health
# Debe mostrar: "version": "3.0.0"
```

### Variables de Entorno Requeridas
```
GOOGLE_SHEETS_ID=1ZYI5c0enkuvWAveu8HMaCUk1cek_VDrX8GtgKW7VP6U
GOOGLE_CREDENTIALS=<json>
PORT=3000
```

### Endpoints
```
GET  /health
POST /api/detect-filter
```

### Cambios en v3.0.0
- ✅ Reglas v2.2.3 (10 prefijos corregidos)
- ✅ Sin dependencia de n8n
- ✅ Sistema de protección inmutable
- ✅ 17 combinaciones correctas
- ✅ Google Sheets directo
```

### Arquitectura
```
WordPress → Proxy v3.0.0 → Google Sheets → WordPress
```
